﻿Imports libreria
Imports DevExpress.XtraEditors
Imports System.Data.SqlClient
Imports System.IO
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraGrid.Views.Base
Imports DevExpress.XtraEditors.Repository
Imports DevExpress.XtraPrinting
Imports DevExpress.XtraGrid.Columns


Public Class frmAnulaciones
    Dim dt As DataTable = New DataTable
    Dim max_compania As Integer
    Dim masivo As Integer


    Sub Tabla()
        dt.Columns.Add("cc_compania", GetType(Integer))
        dt.Columns.Add("cc_numero", GetType(Integer))
        dt.Columns.Add("cc_fecha", GetType(Date))
        dt.Columns.Add("cc_tipo_cxc", GetType(String))
        dt.Columns.Add("cc_ctasxcbr", GetType(Integer))
        dt.Columns.Add("cc_valor", GetType(Decimal))
        dt.Columns.Add("cc_decripcion", GetType(String))
        dt.Columns.Add("cc_tdes_cxc", GetType(String))
        dt.Columns.Add("cc_ncuotas", GetType(Integer))
        dt.Columns.Add("cc_num_reg", GetType(Integer))
        dt.Columns.Add("cc_estado", GetType(String))
        dt.Columns.Add("cc_usuario", GetType(String))
        dt.Columns.Add("cc_maquina", GetType(String))
        dt.Columns.Add("cc_fecha_reg", GetType(Date))
        dt.Columns.Add("tipo_cxc", GetType(String))
        dt.Columns.Add("descripcion", GetType(String))


        GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
        GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
        CabGridControl.DataSource = Nothing
        GridView1.OptionsView.ShowGroupPanel = False
        CabGridControl.DataSource = dt

        GridView1.OptionsBehavior.Editable = False



        GridView1.Columns("cc_tipo_cxc").Visible = False
        GridView1.Columns("cc_ctasxcbr").Visible = False
        GridView1.Columns("cc_tdes_cxc").Visible = False
        GridView1.Columns("cc_valor").Visible = False
        GridView1.Columns("cc_maquina").Visible = False



        
    End Sub

    Private Sub frmAnulaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Tabla()
        llenar_compania()
        sgMaquina = My.Computer.Name

        If max_compania > 0 Then
            cmbCompania.EditValue = cmbCompania.Properties.GetKeyValue(0)
            sgCompaniaForm = sgCompania
        End If
        CheckEdit1.Checked = False
        DateTimePicker1.Enabled = False
        DateTimePicker2.Enabled = False
    End Sub


    Private Sub llenar_compania()

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim dtc As New DataSet
        Dim dtadap As SqlDataAdapter

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                '.CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Compania"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "query_empresa")
            End With


            dtadap = New SqlDataAdapter(oComand)
            dtadap.Fill(dtc)
            max_compania = dtc.Tables(0).Rows.Count
            ' max_compania = max_compania - 1
            ' llenacompania = False
            cmbCompania.Properties.DataSource = dtc.Tables(0)
            cmbCompania.Properties.DisplayMember = "Nombre"
            cmbCompania.Properties.ValueMember = "Codigo"
            ' llenacompania = True
            oComand = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub CabGridControl_Click(sender As Object, e As EventArgs) Handles CabGridControl.Click

        Dim ocon As SqlConnection
        Dim ocomand As SqlCommand
        Dim ors As SqlDataReader
        Dim gconextion As gConnectionSql.gConnection

        Dim selectedRow As DataRowView = CType(GridView1.GetRow(GridView1.FocusedRowHandle), DataRowView)

        gconextion = New gConnectionSql.gConnection
        ocon = Nothing

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub


            If selectedRow IsNot Nothing Then
                Dim cc_numero As Integer = Convert.ToInt32(selectedRow("cc_numero"))
                masivo = cc_numero
                Console.WriteLine(masivo)

                ocomand = New SqlCommand
                With ocomand
                    .CommandText = "ROLSp_Cuentas_Cobrar_Masivas_Validacion_Anulacion"
                    .Connection = ocon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "CARDET")
                    .Parameters.AddWithValue("@cc_numero", cc_numero)
                End With

                Dim adapter As New SqlDataAdapter(ocomand)
                ' Llena el conjunto de datos con los resultados del procedimiento almacenado
                Dim dataSet As New DataSet()
                adapter.Fill(dataSet)

                ' Enlaza los datos al gridControl2
                DetGridControl.DataSource = dataSet.Tables(0)
                GridView2.OptionsBehavior.Editable = False

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default






                ' Aquí ejecuta tu consulta SQL en gridControl2 utilizando el valor de cc_numero
                ' Asegúrate de definir y configurar tu conexión a la base de datos y el adaptador de datos correspondientes

                'Dim sql As String = "SELECT * FROM ROL_Det_CtasxCbr AS t1 WHERE t1.dc_numero IN (SELECT t2.cc_numero FROM ROL_Cab_CtasxCbr AS t2 WHERE t2.cc_masivo = @es and t1.dc_estado = 'A');"

                '' Crea un adaptador de datos y un conjunto de datos para llenar los datos en gridControl2
                ''Dim adapter As New SqlDataAdapter(sql, ocon)
                'adapter.SelectCommand.Parameters.AddWithValue("@es", cc_numero)
                ''  Dim dataSet As New DataSet()

                '' Llena el conjunto de datos con los resultados de la consulta
                'adapter.Fill(dataSet)

                '' Enlaza los datos al gridControl2
                'DetGridControl.DataSource = dataSet.Tables(0)
                'GridView2.OptionsBehavior.Editable = False

            End If

        Catch ex As Exception
            Throw ex
        Finally
            If ocon.State = ConnectionState.Open Then
                ocon.Close()
            End If
            ors = Nothing
            ocon = Nothing
            ocomand = Nothing
        End Try


    End Sub

    Private Sub SimpleButton1_Click_1(sender As Object, e As EventArgs) Handles SimpleButton1.Click

        Dim ocon As SqlConnection
        Dim ocomand As SqlCommand
        Dim ors As SqlDataReader
        Dim gconextion As gConnectionSql.gConnection

        gconextion = New gConnectionSql.gConnection
        ocon = Nothing

        DetGridControl.DataSource = Nothing
        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            dt.Rows.Clear()
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub

            ocomand = New SqlCommand
            With ocomand
                .CommandText = "ROLSp_Cuentas_Cobrar_Masivas_Validacion_Anulacion"
                .Connection = ocon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "CARCAB")
                .Parameters.AddWithValue("@i_usuario", sgUsuario)
                .Parameters.AddWithValue("@i_maquina", sgMaquina)
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
            End With
            ors = ocomand.ExecuteReader()
            If ors.HasRows Then
                While ors.Read

                    'Console.WriteLine("cc_compania: " & ors("cc_compania"))
                    'Console.WriteLine("cc_numero: " & ors("cc_numero"))
                    'Console.WriteLine("cc_fecha: " & ors("cc_fecha"))
                    'Console.WriteLine("cc_tipo_cxc: " & ors("cc_tipo_cxc"))
                    'Console.WriteLine("cc_ctasxcbr: " & ors("cc_ctasxcbr"))
                    'Console.WriteLine("cc_valor: " & ors("cc_valor"))
                    'Console.WriteLine("cc_decripcion: " & ors("cc_decripcion"))
                    'Console.WriteLine("cc_tdes_cxc: " & ors("cc_tdes_cxc"))
                    'Console.WriteLine("cc_ncuotas: " & ors("cc_ncuotas"))
                    'Console.WriteLine("cc_num_reg: " & ors("cc_num_reg"))
                    'Console.WriteLine("cc_estado: " & ors("cc_estado"))
                    'Console.WriteLine("cc_usuario: " & ors("cc_usuario"))
                    'Console.WriteLine("cc_maquina: " & ors("cc_maquina"))
                    'Console.WriteLine("cc_fecha_reg: " & ors("cc_fecha_reg"))
                    'Console.WriteLine("tipo_cxc: " & ors("tipo_cxc"))
                    'Console.WriteLine("descripcion: " & ors("descripcion"))
                    'Console.WriteLine() ' Agrega una línea en blanco entre cada conjunto de datos

                    dt.Rows.Add(ors.Item("cc_compania"), ors.Item("cc_numero"), ors.Item("cc_fecha"), ors.Item("cc_tipo_cxc"), ors.Item("cc_ctasxcbr"), ors.Item("cc_valor"), ors.Item("cc_decripcion"), ors.Item("cc_tdes_cxc"),
                                ors.Item("cc_ncuotas"), ors.Item("cc_num_reg"), ors.Item("cc_estado"), ors.Item("cc_usuario"), ors.Item("cc_maquina"), ors.Item("cc_fecha_reg"), ors.Item("tipo_cxc"), ors.Item("descripcion"))


                End While
            End If

            ors.Close()
            ' Enlaza el GridView con el DataTable
            CabGridControl.DataSource = dt
            ' CabGridControl.DataBind()

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Catch ex As Exception
            Throw ex
        Finally
            If ocon.State = ConnectionState.Open Then
                ocon.Close()
            End If
            ors = Nothing
            ocon = Nothing
            ocomand = Nothing
        End Try
    End Sub

    Private Sub CheckEdit1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckEdit1.CheckedChanged
        If (CheckEdit1.Checked) Then
            DateTimePicker1.Enabled = True
            DateTimePicker2.Enabled = True
            NoTextEdit.Enabled = False
            NoTextEdit.Text = ""
        Else
            DateTimePicker1.Enabled = False
            DateTimePicker2.Enabled = False
            NoTextEdit.Enabled = True
        End If
    End Sub

    Private Sub DateTimePicker1_ValueChanged_1(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        ' Obtén la fecha seleccionada en el DateTimePicker "Desde"
        Dim fechaDesde As DateTime = DateTimePicker1.Value

        ' Obtén la fecha seleccionada en el DateTimePicker "Hasta"
        Dim fechaHasta As DateTime = DateTimePicker2.Value

        ' Comprueba si la fecha seleccionada en "Desde" es mayor que la fecha en "Hasta"
        If fechaDesde > fechaHasta Then
            ' Si es mayor, establece la fecha en "Hasta" igual a la fecha en "Desde"
            DateTimePicker2.Value = fechaDesde
        End If
    End Sub

    Private Sub DateTimePicker2_ValueChanged_1(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged
        ' Obtén la fecha seleccionada en el DateTimePicker "Hasta"
        Dim fechaHasta As DateTime = DateTimePicker2.Value

        ' Obtén la fecha seleccionada en el DateTimePicker "Desde"
        Dim fechaDesde As DateTime = DateTimePicker1.Value

        ' Comprueba si la fecha seleccionada en "Hasta" es menor que la fecha en "Desde"
        If fechaHasta < fechaDesde Then
            ' Si es menor, establece la fecha en "Desde" igual a la fecha en "Hasta"
            DateTimePicker1.Value = fechaHasta
        End If
    End Sub

    Private Sub SimpleButton3_Click(sender As Object, e As EventArgs) Handles SimpleButton3.Click
        Dim ocon As SqlConnection
        Dim ocomand As SqlCommand
        Dim ors As SqlDataReader
        Dim gconextion As gConnectionSql.gConnection

        gconextion = New gConnectionSql.gConnection
        ocon = Nothing

        DetGridControl.DataSource = Nothing

        If CheckEdit1.Checked Then
            Try
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                dt.Rows.Clear()
                If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub

                ocomand = New SqlCommand
                With ocomand
                    .CommandText = "ROLSp_Cuentas_Cobrar_Masivas_Validacion_Anulacion"
                    .Connection = ocon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "CARCABFILFEC")
                    .Parameters.AddWithValue("@i_usuario", sgUsuario)
                    .Parameters.AddWithValue("@i_maquina", sgMaquina)
                    .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                    .Parameters.AddWithValue("@fecha_desde", Convert.ToDateTime(DateTimePicker1.Value))
                    .Parameters.AddWithValue("@fecha_hasta", Convert.ToDateTime(DateTimePicker2.Value))
                End With
                ors = ocomand.ExecuteReader()
                If ors.HasRows Then
                    While ors.Read

                        dt.Rows.Add(ors.Item("cc_compania"), ors.Item("cc_numero"), ors.Item("cc_fecha"), ors.Item("cc_tipo_cxc"), ors.Item("cc_ctasxcbr"), ors.Item("cc_valor"), ors.Item("cc_decripcion"), ors.Item("cc_tdes_cxc"),
                                    ors.Item("cc_ncuotas"), ors.Item("cc_num_reg"), ors.Item("cc_estado"), ors.Item("cc_usuario"), ors.Item("cc_maquina"), ors.Item("cc_fecha_reg"), ors.Item("tipo_cxc"), ors.Item("descripcion"))
                    End While
                End If

                ors.Close()
                ' Enlaza el GridView con el DataTable
                CabGridControl.DataSource = dt
                ' CabGridControl.DataBind()

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Catch ex As Exception
                Throw ex
            Finally
                If ocon.State = ConnectionState.Open Then
                    ocon.Close()
                End If
                ors = Nothing
                ocon = Nothing
                ocomand = Nothing
            End Try
        Else
            Try
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                dt.Rows.Clear()
                If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub
                If NoTextEdit.Text = "" Then
                    XtraMessageBox.Show("Ingrese numero de lote a buscar...", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If


                ocomand = New SqlCommand
                With ocomand
                    .CommandText = "ROLSp_Cuentas_Cobrar_Masivas_Validacion_Anulacion"
                    .Connection = ocon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "CARCABFIL")
                    .Parameters.AddWithValue("@i_usuario", sgUsuario)
                    .Parameters.AddWithValue("@i_maquina", sgMaquina)
                    .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                    .Parameters.AddWithValue("@cc_numero", NoTextEdit.Text)
                End With
                ors = ocomand.ExecuteReader()
                If ors.HasRows Then
                    While ors.Read

                        dt.Rows.Add(ors.Item("cc_compania"), ors.Item("cc_numero"), ors.Item("cc_fecha"), ors.Item("cc_tipo_cxc"), ors.Item("cc_ctasxcbr"), ors.Item("cc_valor"), ors.Item("cc_decripcion"), ors.Item("cc_tdes_cxc"),
                                    ors.Item("cc_ncuotas"), ors.Item("cc_num_reg"), ors.Item("cc_estado"), ors.Item("cc_usuario"), ors.Item("cc_maquina"), ors.Item("cc_fecha_reg"), ors.Item("tipo_cxc"), ors.Item("descripcion"))
                    End While
                End If

                ors.Close()
                ' Enlaza el GridView con el DataTable
                CabGridControl.DataSource = dt
                ' CabGridControl.DataBind()

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Catch ex As Exception
                Throw ex
            Finally
                If ocon.State = ConnectionState.Open Then
                    ocon.Close()
                End If
                ors = Nothing
                ocon = Nothing
                ocomand = Nothing
            End Try
        End If
       
    End Sub

    Private Sub cmbCompania_EditValueChanged(sender As Object, e As EventArgs) Handles cmbCompania.EditValueChanged
        sgCompaniaForm = cmbCompania.EditValue
        Console.WriteLine(sgCompaniaForm)
    End Sub

    Private Sub SimpleButton2_Click_1(sender As Object, e As EventArgs) Handles SimpleButton2.Click
        If Not (masivo <= 0) Then

            If XtraMessageBox.Show("Esta seguro de Anular las Cuentas por cobrar Masivas", NOMBRE_SISTEMA, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) = DialogResult.Cancel Then Exit Sub
            Dim ocon As SqlConnection
            Dim ocomand As SqlCommand
            Dim ors As SqlDataReader
            Dim gconextion As gConnectionSql.gConnection

            gconextion = New gConnectionSql.gConnection
            ocon = Nothing

            Try
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                dt.Rows.Clear()
                If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub

                ocomand = New SqlCommand
                With ocomand
                    .CommandText = "ROLSp_Cuentas_Cobrar_Masivas_Validacion_Anulacion"
                    .Connection = ocon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "UPDDET")
                    .Parameters.AddWithValue("@i_usuario", sgUsuario)
                    .Parameters.AddWithValue("@i_maquina", sgMaquina)
                    .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                    .Parameters.AddWithValue("@cc_numero", masivo)
                End With
                ors = ocomand.ExecuteReader()

                ors.Close()
                ' Enlaza el GridView con el DataTable
                CabGridControl.DataSource = dt
                ' CabGridControl.DataBind()

                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            Catch ex As Exception
                Throw ex
            Finally
                If ocon.State = ConnectionState.Open Then
                    ocon.Close()
                End If
                ors = Nothing
                ocon = Nothing
                ocomand = Nothing
                DetGridControl.DataSource = Nothing
                XtraMessageBox.Show("Registros anulados correctamente...", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

            End Try
        Else
            XtraMessageBox.Show("Selecione carga a anular...", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If
    End Sub
End Class