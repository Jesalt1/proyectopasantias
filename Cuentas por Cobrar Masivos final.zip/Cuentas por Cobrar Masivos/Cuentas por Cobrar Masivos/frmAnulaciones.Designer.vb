﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAnulaciones
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAnulaciones))
        Me.PanelTop = New DevExpress.XtraEditors.PanelControl()
        Me.GroupControl1 = New DevExpress.XtraEditors.GroupControl()
        Me.cmbCompania = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.NoTextEdit = New DevExpress.XtraEditors.TextEdit()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.CheckEdit1 = New DevExpress.XtraEditors.CheckEdit()
        Me.SimpleButton3 = New DevExpress.XtraEditors.SimpleButton()
        Me.SimpleButton2 = New DevExpress.XtraEditors.SimpleButton()
        Me.SimpleButton1 = New DevExpress.XtraEditors.SimpleButton()
        Me.DgvPanel1 = New DevExpress.XtraEditors.PanelControl()
        Me.CabGridControl = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.BotPanel = New DevExpress.XtraEditors.PanelControl()
        Me.DetGridControl = New DevExpress.XtraGrid.GridControl()
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.lblcompania = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.PanelTop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTop.SuspendLayout()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl1.SuspendLayout()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NoTextEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CheckEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DgvPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DgvPanel1.SuspendLayout()
        CType(Me.CabGridControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BotPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BotPanel.SuspendLayout()
        CType(Me.DetGridControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelTop
        '
        Me.PanelTop.Controls.Add(Me.GroupControl1)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Location = New System.Drawing.Point(0, 0)
        Me.PanelTop.Name = "PanelTop"
        Me.PanelTop.Size = New System.Drawing.Size(958, 113)
        Me.PanelTop.TabIndex = 0
        '
        'GroupControl1
        '
        Me.GroupControl1.Controls.Add(Me.Label3)
        Me.GroupControl1.Controls.Add(Me.Label2)
        Me.GroupControl1.Controls.Add(Me.Label1)
        Me.GroupControl1.Controls.Add(Me.lblcompania)
        Me.GroupControl1.Controls.Add(Me.cmbCompania)
        Me.GroupControl1.Controls.Add(Me.NoTextEdit)
        Me.GroupControl1.Controls.Add(Me.DateTimePicker2)
        Me.GroupControl1.Controls.Add(Me.DateTimePicker1)
        Me.GroupControl1.Controls.Add(Me.CheckEdit1)
        Me.GroupControl1.Controls.Add(Me.SimpleButton3)
        Me.GroupControl1.Controls.Add(Me.SimpleButton2)
        Me.GroupControl1.Controls.Add(Me.SimpleButton1)
        Me.GroupControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupControl1.Location = New System.Drawing.Point(2, 2)
        Me.GroupControl1.Name = "GroupControl1"
        Me.GroupControl1.Size = New System.Drawing.Size(954, 109)
        Me.GroupControl1.TabIndex = 0
        Me.GroupControl1.Text = "Parametros"
        '
        'cmbCompania
        '
        Me.cmbCompania.Location = New System.Drawing.Point(88, 27)
        Me.cmbCompania.Name = "cmbCompania"
        Me.cmbCompania.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cmbCompania.Properties.View = Me.GridLookUpEdit1View
        Me.cmbCompania.Size = New System.Drawing.Size(446, 20)
        Me.cmbCompania.TabIndex = 24
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'NoTextEdit
        '
        Me.NoTextEdit.Location = New System.Drawing.Point(398, 79)
        Me.NoTextEdit.Name = "NoTextEdit"
        Me.NoTextEdit.Properties.Mask.EditMask = "f0"
        Me.NoTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.NoTextEdit.Size = New System.Drawing.Size(136, 20)
        Me.NoTextEdit.TabIndex = 21
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker2.Location = New System.Drawing.Point(160, 77)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(94, 21)
        Me.DateTimePicker2.TabIndex = 18
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(31, 77)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(94, 21)
        Me.DateTimePicker1.TabIndex = 17
        '
        'CheckEdit1
        '
        Me.CheckEdit1.Location = New System.Drawing.Point(263, 79)
        Me.CheckEdit1.Name = "CheckEdit1"
        Me.CheckEdit1.Properties.Caption = "Filtrar por fechas"
        Me.CheckEdit1.Size = New System.Drawing.Size(115, 19)
        Me.CheckEdit1.TabIndex = 16
        '
        'SimpleButton3
        '
        Me.SimpleButton3.Image = CType(resources.GetObject("SimpleButton3.Image"), System.Drawing.Image)
        Me.SimpleButton3.Location = New System.Drawing.Point(718, 37)
        Me.SimpleButton3.Name = "SimpleButton3"
        Me.SimpleButton3.Size = New System.Drawing.Size(99, 61)
        Me.SimpleButton3.TabIndex = 15
        Me.SimpleButton3.Text = "Buscar"
        '
        'SimpleButton2
        '
        Me.SimpleButton2.Image = CType(resources.GetObject("SimpleButton2.Image"), System.Drawing.Image)
        Me.SimpleButton2.Location = New System.Drawing.Point(603, 37)
        Me.SimpleButton2.Name = "SimpleButton2"
        Me.SimpleButton2.Size = New System.Drawing.Size(109, 61)
        Me.SimpleButton2.TabIndex = 14
        Me.SimpleButton2.Text = "Anular"
        '
        'SimpleButton1
        '
        Me.SimpleButton1.Image = CType(resources.GetObject("SimpleButton1.Image"), System.Drawing.Image)
        Me.SimpleButton1.Location = New System.Drawing.Point(823, 37)
        Me.SimpleButton1.Name = "SimpleButton1"
        Me.SimpleButton1.Size = New System.Drawing.Size(99, 61)
        Me.SimpleButton1.TabIndex = 13
        Me.SimpleButton1.Text = "Cargar"
        '
        'DgvPanel1
        '
        Me.DgvPanel1.Controls.Add(Me.CabGridControl)
        Me.DgvPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DgvPanel1.Location = New System.Drawing.Point(0, 113)
        Me.DgvPanel1.Name = "DgvPanel1"
        Me.DgvPanel1.Size = New System.Drawing.Size(958, 182)
        Me.DgvPanel1.TabIndex = 1
        '
        'CabGridControl
        '
        Me.CabGridControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CabGridControl.Location = New System.Drawing.Point(2, 2)
        Me.CabGridControl.MainView = Me.GridView1
        Me.CabGridControl.Name = "CabGridControl"
        Me.CabGridControl.Size = New System.Drawing.Size(954, 178)
        Me.CabGridControl.TabIndex = 0
        Me.CabGridControl.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.CabGridControl
        Me.GridView1.Name = "GridView1"
        '
        'BotPanel
        '
        Me.BotPanel.Controls.Add(Me.DetGridControl)
        Me.BotPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BotPanel.Location = New System.Drawing.Point(0, 295)
        Me.BotPanel.Name = "BotPanel"
        Me.BotPanel.Size = New System.Drawing.Size(958, 222)
        Me.BotPanel.TabIndex = 2
        '
        'DetGridControl
        '
        Me.DetGridControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DetGridControl.Location = New System.Drawing.Point(2, 2)
        Me.DetGridControl.MainView = Me.GridView2
        Me.DetGridControl.Name = "DetGridControl"
        Me.DetGridControl.Size = New System.Drawing.Size(954, 218)
        Me.DetGridControl.TabIndex = 0
        Me.DetGridControl.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView2})
        '
        'GridView2
        '
        Me.GridView2.GridControl = Me.DetGridControl
        Me.GridView2.Name = "GridView2"
        '
        'lblcompania
        '
        Me.lblcompania.AutoSize = True
        Me.lblcompania.Location = New System.Drawing.Point(28, 30)
        Me.lblcompania.Name = "lblcompania"
        Me.lblcompania.Size = New System.Drawing.Size(54, 13)
        Me.lblcompania.TabIndex = 25
        Me.lblcompania.Text = "Compañia"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Desde"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(157, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Hasta"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(400, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "No."
        '
        'frmAnulaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(958, 517)
        Me.Controls.Add(Me.BotPanel)
        Me.Controls.Add(Me.DgvPanel1)
        Me.Controls.Add(Me.PanelTop)
        Me.Name = "frmAnulaciones"
        Me.Text = "ANULACIONES"
        CType(Me.PanelTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTop.ResumeLayout(False)
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl1.ResumeLayout(False)
        Me.GroupControl1.PerformLayout()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NoTextEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CheckEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DgvPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DgvPanel1.ResumeLayout(False)
        CType(Me.CabGridControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BotPanel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BotPanel.ResumeLayout(False)
        CType(Me.DetGridControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelTop As DevExpress.XtraEditors.PanelControl
    Friend WithEvents DgvPanel1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents CabGridControl As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents BotPanel As DevExpress.XtraEditors.PanelControl
    Friend WithEvents DetGridControl As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GroupControl1 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents cmbCompania As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents NoTextEdit As DevExpress.XtraEditors.TextEdit
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents CheckEdit1 As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents SimpleButton3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton1 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblcompania As System.Windows.Forms.Label
End Class
