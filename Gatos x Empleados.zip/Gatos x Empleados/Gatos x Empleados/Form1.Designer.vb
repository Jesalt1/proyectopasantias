﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits DevExpress.XtraEditors.XtraForm

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cmbempleado = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.cmbCompania = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.lblcompania = New DevExpress.XtraEditors.LabelControl()
        Me.GroupControl1 = New DevExpress.XtraEditors.GroupControl()
        Me.botubica = New System.Windows.Forms.Button()
        Me.txtubicaempleado = New System.Windows.Forms.TextBox()
        Me.lblcodigo = New DevExpress.XtraEditors.LabelControl()
        Me.dtpfecha = New DevExpress.XtraEditors.DateEdit()
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl()
        Me.nudanio = New System.Windows.Forms.NumericUpDown()
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.btngrabar = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btneliminar = New System.Windows.Forms.Button()
        Me.btnmodificar = New System.Windows.Forms.Button()
        Me.btnuevo = New System.Windows.Forms.Button()
        Me.DefaultLookAndFeel1 = New DevExpress.LookAndFeel.DefaultLookAndFeel(Me.components)
        Me.FormAssistant1 = New DevExpress.XtraBars.FormAssistant()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.GroupControl2 = New DevExpress.XtraEditors.GroupControl()
        Me.chkcatastrofica = New System.Windows.Forms.CheckBox()
        Me.txtcarga = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.txtimp_otro = New DevExpress.XtraEditors.TextEdit()
        Me.txtgasto_Otro = New DevExpress.XtraEditors.TextEdit()
        Me.txtmesesproy = New DevExpress.XtraEditors.TextEdit()
        Me.txtaporteiess = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl14 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl13 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl12 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl11 = New DevExpress.XtraEditors.LabelControl()
        Me.dtpFechaIng = New DevExpress.XtraEditors.DateEdit()
        Me.txtrebajas_otras = New DevExpress.XtraEditors.TextEdit()
        Me.txtingreso_otro = New DevExpress.XtraEditors.TextEdit()
        Me.txtdsctoir = New DevExpress.XtraEditors.TextEdit()
        Me.txtingreanual = New DevExpress.XtraEditors.TextEdit()
        Me.txtmesesIGA = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl10 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl9 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl8 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl7 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl()
        Me.GroupControl3 = New DevExpress.XtraEditors.GroupControl()
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl()
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.RepositoryItemToggleSwitch1 = New DevExpress.XtraEditors.Repository.RepositoryItemToggleSwitch()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        CType(Me.cmbempleado.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl1.SuspendLayout()
        CType(Me.dtpfecha.Properties.CalendarTimeProperties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpfecha.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudanio, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.GroupControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl2.SuspendLayout()
        CType(Me.txtcarga.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtimp_otro.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtgasto_Otro.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmesesproy.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtaporteiess.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpFechaIng.Properties.CalendarTimeProperties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpFechaIng.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtrebajas_otras.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtingreso_otro.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtdsctoir.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtingreanual.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtmesesIGA.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GroupControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl3.SuspendLayout()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemToggleSwitch1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbempleado
        '
        Me.cmbempleado.Location = New System.Drawing.Point(78, 47)
        Me.cmbempleado.Name = "cmbempleado"
        Me.cmbempleado.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cmbempleado.Properties.View = Me.GridView1
        Me.cmbempleado.Size = New System.Drawing.Size(294, 20)
        Me.cmbempleado.TabIndex = 8
        '
        'GridView1
        '
        Me.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'cmbCompania
        '
        Me.cmbCompania.Location = New System.Drawing.Point(78, 21)
        Me.cmbCompania.Name = "cmbCompania"
        Me.cmbCompania.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cmbCompania.Properties.View = Me.GridLookUpEdit1View
        Me.cmbCompania.Size = New System.Drawing.Size(227, 20)
        Me.cmbCompania.TabIndex = 7
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'LabelControl2
        '
        Me.LabelControl2.Location = New System.Drawing.Point(23, 50)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(46, 13)
        Me.LabelControl2.TabIndex = 6
        Me.LabelControl2.Text = "Empleado"
        '
        'lblcompania
        '
        Me.lblcompania.Location = New System.Drawing.Point(23, 24)
        Me.lblcompania.Name = "lblcompania"
        Me.lblcompania.Size = New System.Drawing.Size(47, 13)
        Me.lblcompania.TabIndex = 5
        Me.lblcompania.Text = "Compania"
        '
        'GroupControl1
        '
        Me.GroupControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupControl1.Controls.Add(Me.botubica)
        Me.GroupControl1.Controls.Add(Me.txtubicaempleado)
        Me.GroupControl1.Controls.Add(Me.lblcodigo)
        Me.GroupControl1.Controls.Add(Me.dtpfecha)
        Me.GroupControl1.Controls.Add(Me.LabelControl4)
        Me.GroupControl1.Controls.Add(Me.nudanio)
        Me.GroupControl1.Controls.Add(Me.LabelControl3)
        Me.GroupControl1.Controls.Add(Me.cmbCompania)
        Me.GroupControl1.Controls.Add(Me.cmbempleado)
        Me.GroupControl1.Controls.Add(Me.lblcompania)
        Me.GroupControl1.Controls.Add(Me.LabelControl2)
        Me.GroupControl1.Location = New System.Drawing.Point(4, 12)
        Me.GroupControl1.Name = "GroupControl1"
        Me.GroupControl1.Size = New System.Drawing.Size(573, 100)
        Me.GroupControl1.TabIndex = 9
        Me.GroupControl1.Text = "Fitros"
        '
        'botubica
        '
        Me.botubica.Image = Global.Gatos_x_Empleados.My.Resources.Resources.dialog_apply
        Me.botubica.Location = New System.Drawing.Point(425, 44)
        Me.botubica.Name = "botubica"
        Me.botubica.Size = New System.Drawing.Size(29, 25)
        Me.botubica.TabIndex = 16
        Me.botubica.UseVisualStyleBackColor = True
        '
        'txtubicaempleado
        '
        Me.txtubicaempleado.Location = New System.Drawing.Point(376, 46)
        Me.txtubicaempleado.Name = "txtubicaempleado"
        Me.txtubicaempleado.Size = New System.Drawing.Size(46, 21)
        Me.txtubicaempleado.TabIndex = 15
        '
        'lblcodigo
        '
        Me.lblcodigo.Location = New System.Drawing.Point(399, 80)
        Me.lblcodigo.Name = "lblcodigo"
        Me.lblcodigo.Size = New System.Drawing.Size(0, 13)
        Me.lblcodigo.TabIndex = 14
        '
        'dtpfecha
        '
        Me.dtpfecha.EditValue = Nothing
        Me.dtpfecha.Location = New System.Drawing.Point(78, 73)
        Me.dtpfecha.Name = "dtpfecha"
        Me.dtpfecha.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.dtpfecha.Properties.CalendarTimeProperties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.dtpfecha.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista
        Me.dtpfecha.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.[True]
        Me.dtpfecha.Size = New System.Drawing.Size(127, 20)
        Me.dtpfecha.TabIndex = 12
        '
        'LabelControl4
        '
        Me.LabelControl4.Location = New System.Drawing.Point(23, 76)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(33, 13)
        Me.LabelControl4.TabIndex = 11
        Me.LabelControl4.Text = "Fecha:"
        '
        'nudanio
        '
        Me.nudanio.Location = New System.Drawing.Point(489, 48)
        Me.nudanio.Maximum = New Decimal(New Integer() {2999, 0, 0, 0})
        Me.nudanio.Minimum = New Decimal(New Integer() {1980, 0, 0, 0})
        Me.nudanio.Name = "nudanio"
        Me.nudanio.Size = New System.Drawing.Size(61, 21)
        Me.nudanio.TabIndex = 10
        Me.nudanio.Value = New Decimal(New Integer() {1980, 0, 0, 0})
        '
        'LabelControl3
        '
        Me.LabelControl3.Location = New System.Drawing.Point(460, 50)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(23, 13)
        Me.LabelControl3.TabIndex = 9
        Me.LabelControl3.Text = "Año:"
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Panel2.Controls.Add(Me.btnCancelar)
        Me.Panel2.Controls.Add(Me.btngrabar)
        Me.Panel2.Location = New System.Drawing.Point(578, 244)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(81, 116)
        Me.Panel2.TabIndex = 18
        '
        'btnCancelar
        '
        Me.btnCancelar.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btnCancelar.Image = Global.Gatos_x_Empleados.My.Resources.Resources.undo
        Me.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancelar.Location = New System.Drawing.Point(6, 66)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(72, 28)
        Me.btnCancelar.TabIndex = 13
        Me.btnCancelar.Text = "&Cancelar"
        Me.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btngrabar
        '
        Me.btngrabar.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btngrabar.Image = Global.Gatos_x_Empleados.My.Resources.Resources.disk
        Me.btngrabar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btngrabar.Location = New System.Drawing.Point(6, 27)
        Me.btngrabar.Name = "btngrabar"
        Me.btngrabar.Size = New System.Drawing.Size(72, 28)
        Me.btngrabar.TabIndex = 10
        Me.btngrabar.Text = "&Grabar"
        Me.btngrabar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btngrabar.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.btneliminar)
        Me.Panel1.Controls.Add(Me.btnmodificar)
        Me.Panel1.Controls.Add(Me.btnuevo)
        Me.Panel1.Location = New System.Drawing.Point(578, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(81, 137)
        Me.Panel1.TabIndex = 17
        '
        'btneliminar
        '
        Me.btneliminar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btneliminar.Image = Global.Gatos_x_Empleados.My.Resources.Resources.toolbar_delete
        Me.btneliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btneliminar.Location = New System.Drawing.Point(5, 82)
        Me.btneliminar.Name = "btneliminar"
        Me.btneliminar.Size = New System.Drawing.Size(72, 28)
        Me.btneliminar.TabIndex = 11
        Me.btneliminar.Text = "&Eliminar"
        Me.btneliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btneliminar.UseVisualStyleBackColor = True
        '
        'btnmodificar
        '
        Me.btnmodificar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnmodificar.Enabled = False
        Me.btnmodificar.Image = Global.Gatos_x_Empleados.My.Resources.Resources.toolbar_edit
        Me.btnmodificar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnmodificar.Location = New System.Drawing.Point(5, 47)
        Me.btnmodificar.Name = "btnmodificar"
        Me.btnmodificar.Size = New System.Drawing.Size(72, 28)
        Me.btnmodificar.TabIndex = 9
        Me.btnmodificar.Text = "&Modificar"
        Me.btnmodificar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnmodificar.UseVisualStyleBackColor = True
        '
        'btnuevo
        '
        Me.btnuevo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnuevo.Image = Global.Gatos_x_Empleados.My.Resources.Resources.toolbar_add
        Me.btnuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnuevo.Location = New System.Drawing.Point(5, 13)
        Me.btnuevo.Name = "btnuevo"
        Me.btnuevo.Size = New System.Drawing.Size(72, 28)
        Me.btnuevo.TabIndex = 8
        Me.btnuevo.Text = "&Nuevo"
        Me.btnuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnuevo.UseVisualStyleBackColor = True
        '
        'DefaultLookAndFeel1
        '
        Me.DefaultLookAndFeel1.LookAndFeel.SkinName = "Office 2013 Light Gray"
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.Image = Global.Gatos_x_Empleados.My.Resources.Resources.door_out
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.Location = New System.Drawing.Point(584, 505)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(72, 28)
        Me.Button6.TabIndex = 16
        Me.Button6.Text = "&Salir"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.UseVisualStyleBackColor = True
        '
        'GroupControl2
        '
        Me.GroupControl2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupControl2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.GroupControl2.Controls.Add(Me.chkcatastrofica)
        Me.GroupControl2.Controls.Add(Me.txtcarga)
        Me.GroupControl2.Controls.Add(Me.LabelControl1)
        Me.GroupControl2.Controls.Add(Me.txtimp_otro)
        Me.GroupControl2.Controls.Add(Me.txtgasto_Otro)
        Me.GroupControl2.Controls.Add(Me.txtmesesproy)
        Me.GroupControl2.Controls.Add(Me.txtaporteiess)
        Me.GroupControl2.Controls.Add(Me.LabelControl14)
        Me.GroupControl2.Controls.Add(Me.LabelControl13)
        Me.GroupControl2.Controls.Add(Me.LabelControl12)
        Me.GroupControl2.Controls.Add(Me.LabelControl11)
        Me.GroupControl2.Controls.Add(Me.dtpFechaIng)
        Me.GroupControl2.Controls.Add(Me.txtrebajas_otras)
        Me.GroupControl2.Controls.Add(Me.txtingreso_otro)
        Me.GroupControl2.Controls.Add(Me.txtdsctoir)
        Me.GroupControl2.Controls.Add(Me.txtingreanual)
        Me.GroupControl2.Controls.Add(Me.txtmesesIGA)
        Me.GroupControl2.Controls.Add(Me.LabelControl10)
        Me.GroupControl2.Controls.Add(Me.LabelControl9)
        Me.GroupControl2.Controls.Add(Me.LabelControl8)
        Me.GroupControl2.Controls.Add(Me.LabelControl7)
        Me.GroupControl2.Controls.Add(Me.LabelControl6)
        Me.GroupControl2.Controls.Add(Me.LabelControl5)
        Me.GroupControl2.Location = New System.Drawing.Point(4, 131)
        Me.GroupControl2.Name = "GroupControl2"
        Me.GroupControl2.Size = New System.Drawing.Size(573, 133)
        Me.GroupControl2.TabIndex = 19
        Me.GroupControl2.Text = "Datos"
        '
        'chkcatastrofica
        '
        Me.chkcatastrofica.AutoSize = True
        Me.chkcatastrofica.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkcatastrofica.Location = New System.Drawing.Point(451, 43)
        Me.chkcatastrofica.Name = "chkcatastrofica"
        Me.chkcatastrofica.Size = New System.Drawing.Size(106, 17)
        Me.chkcatastrofica.TabIndex = 29
        Me.chkcatastrofica.Text = "Emf Catastrofica"
        Me.chkcatastrofica.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.chkcatastrofica.UseVisualStyleBackColor = True
        '
        'txtcarga
        '
        Me.txtcarga.Location = New System.Drawing.Point(498, 18)
        Me.txtcarga.Name = "txtcarga"
        Me.txtcarga.Properties.Mask.EditMask = "d"
        Me.txtcarga.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtcarga.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtcarga.Size = New System.Drawing.Size(72, 20)
        Me.txtcarga.TabIndex = 28
        '
        'LabelControl1
        '
        Me.LabelControl1.Location = New System.Drawing.Point(451, 21)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(43, 13)
        Me.LabelControl1.TabIndex = 27
        Me.LabelControl1.Text = "N Carga:"
        '
        'txtimp_otro
        '
        Me.txtimp_otro.Location = New System.Drawing.Point(355, 110)
        Me.txtimp_otro.Name = "txtimp_otro"
        Me.txtimp_otro.Properties.Mask.EditMask = "c"
        Me.txtimp_otro.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtimp_otro.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtimp_otro.Size = New System.Drawing.Size(95, 20)
        Me.txtimp_otro.TabIndex = 25
        '
        'txtgasto_Otro
        '
        Me.txtgasto_Otro.Location = New System.Drawing.Point(355, 87)
        Me.txtgasto_Otro.Name = "txtgasto_Otro"
        Me.txtgasto_Otro.Properties.Mask.EditMask = "c"
        Me.txtgasto_Otro.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtgasto_Otro.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtgasto_Otro.Size = New System.Drawing.Size(95, 20)
        Me.txtgasto_Otro.TabIndex = 24
        '
        'txtmesesproy
        '
        Me.txtmesesproy.Location = New System.Drawing.Point(355, 64)
        Me.txtmesesproy.Name = "txtmesesproy"
        Me.txtmesesproy.Properties.Mask.EditMask = "f0"
        Me.txtmesesproy.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtmesesproy.Properties.MaxLength = 2
        Me.txtmesesproy.Size = New System.Drawing.Size(95, 20)
        Me.txtmesesproy.TabIndex = 23
        '
        'txtaporteiess
        '
        Me.txtaporteiess.Location = New System.Drawing.Point(355, 41)
        Me.txtaporteiess.Name = "txtaporteiess"
        Me.txtaporteiess.Properties.Mask.EditMask = "c"
        Me.txtaporteiess.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtaporteiess.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtaporteiess.Size = New System.Drawing.Size(95, 20)
        Me.txtaporteiess.TabIndex = 22
        '
        'LabelControl14
        '
        Me.LabelControl14.Location = New System.Drawing.Point(237, 113)
        Me.LabelControl14.Name = "LabelControl14"
        Me.LabelControl14.Size = New System.Drawing.Size(104, 13)
        Me.LabelControl14.TabIndex = 21
        Me.LabelControl14.Text = "Imp. Otro Empleador:"
        '
        'LabelControl13
        '
        Me.LabelControl13.Location = New System.Drawing.Point(237, 90)
        Me.LabelControl13.Name = "LabelControl13"
        Me.LabelControl13.Size = New System.Drawing.Size(115, 13)
        Me.LabelControl13.TabIndex = 20
        Me.LabelControl13.Text = "Gastos Otro Empleador:"
        '
        'LabelControl12
        '
        Me.LabelControl12.Location = New System.Drawing.Point(237, 67)
        Me.LabelControl12.Name = "LabelControl12"
        Me.LabelControl12.Size = New System.Drawing.Size(97, 13)
        Me.LabelControl12.TabIndex = 19
        Me.LabelControl12.Text = "Meses Proyectados:"
        '
        'LabelControl11
        '
        Me.LabelControl11.Location = New System.Drawing.Point(237, 44)
        Me.LabelControl11.Name = "LabelControl11"
        Me.LabelControl11.Size = New System.Drawing.Size(62, 13)
        Me.LabelControl11.TabIndex = 18
        Me.LabelControl11.Text = "Aporte IESS:"
        '
        'dtpFechaIng
        '
        Me.dtpFechaIng.EditValue = Nothing
        Me.dtpFechaIng.Location = New System.Drawing.Point(355, 18)
        Me.dtpFechaIng.Name = "dtpFechaIng"
        Me.dtpFechaIng.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.dtpFechaIng.Properties.CalendarTimeProperties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.dtpFechaIng.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Vista
        Me.dtpFechaIng.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.[True]
        Me.dtpFechaIng.Size = New System.Drawing.Size(95, 20)
        Me.dtpFechaIng.TabIndex = 17
        '
        'txtrebajas_otras
        '
        Me.txtrebajas_otras.Location = New System.Drawing.Point(138, 110)
        Me.txtrebajas_otras.Name = "txtrebajas_otras"
        Me.txtrebajas_otras.Properties.Mask.EditMask = "c"
        Me.txtrebajas_otras.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtrebajas_otras.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtrebajas_otras.Size = New System.Drawing.Size(94, 20)
        Me.txtrebajas_otras.TabIndex = 16
        '
        'txtingreso_otro
        '
        Me.txtingreso_otro.Location = New System.Drawing.Point(138, 87)
        Me.txtingreso_otro.Name = "txtingreso_otro"
        Me.txtingreso_otro.Properties.Mask.EditMask = "c"
        Me.txtingreso_otro.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtingreso_otro.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtingreso_otro.Size = New System.Drawing.Size(94, 20)
        Me.txtingreso_otro.TabIndex = 15
        '
        'txtdsctoir
        '
        Me.txtdsctoir.Location = New System.Drawing.Point(138, 64)
        Me.txtdsctoir.Name = "txtdsctoir"
        Me.txtdsctoir.Properties.Mask.EditMask = "c"
        Me.txtdsctoir.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtdsctoir.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtdsctoir.Size = New System.Drawing.Size(94, 20)
        Me.txtdsctoir.TabIndex = 14
        '
        'txtingreanual
        '
        Me.txtingreanual.Location = New System.Drawing.Point(138, 41)
        Me.txtingreanual.Name = "txtingreanual"
        Me.txtingreanual.Properties.DisplayFormat.FormatString = "c"
        Me.txtingreanual.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtingreanual.Properties.EditFormat.FormatString = "c"
        Me.txtingreanual.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.txtingreanual.Properties.Mask.EditMask = "c"
        Me.txtingreanual.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtingreanual.Properties.Mask.UseMaskAsDisplayFormat = True
        Me.txtingreanual.Size = New System.Drawing.Size(94, 20)
        Me.txtingreanual.TabIndex = 13
        '
        'txtmesesIGA
        '
        Me.txtmesesIGA.Location = New System.Drawing.Point(138, 18)
        Me.txtmesesIGA.Name = "txtmesesIGA"
        Me.txtmesesIGA.Properties.Mask.EditMask = "f0"
        Me.txtmesesIGA.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtmesesIGA.Size = New System.Drawing.Size(94, 20)
        Me.txtmesesIGA.TabIndex = 12
        '
        'LabelControl10
        '
        Me.LabelControl10.Location = New System.Drawing.Point(237, 21)
        Me.LabelControl10.Name = "LabelControl10"
        Me.LabelControl10.Size = New System.Drawing.Size(50, 13)
        Me.LabelControl10.TabIndex = 11
        Me.LabelControl10.Text = "F Ingreso:"
        '
        'LabelControl9
        '
        Me.LabelControl9.Location = New System.Drawing.Point(6, 113)
        Me.LabelControl9.Name = "LabelControl9"
        Me.LabelControl9.Size = New System.Drawing.Size(121, 13)
        Me.LabelControl9.TabIndex = 10
        Me.LabelControl9.Text = "Otras Rebajas Otro Emp:"
        '
        'LabelControl8
        '
        Me.LabelControl8.Location = New System.Drawing.Point(6, 90)
        Me.LabelControl8.Name = "LabelControl8"
        Me.LabelControl8.Size = New System.Drawing.Size(106, 13)
        Me.LabelControl8.TabIndex = 9
        Me.LabelControl8.Text = "Ingr. Otro Empleador:"
        '
        'LabelControl7
        '
        Me.LabelControl7.Location = New System.Drawing.Point(6, 67)
        Me.LabelControl7.Name = "LabelControl7"
        Me.LabelControl7.Size = New System.Drawing.Size(59, 13)
        Me.LabelControl7.TabIndex = 8
        Me.LabelControl7.Text = "IR Cobrado:"
        '
        'LabelControl6
        '
        Me.LabelControl6.Location = New System.Drawing.Point(6, 44)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(115, 13)
        Me.LabelControl6.TabIndex = 7
        Me.LabelControl6.Text = "Ingreso Gravado Anual:"
        '
        'LabelControl5
        '
        Me.LabelControl5.Location = New System.Drawing.Point(6, 21)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(129, 13)
        Me.LabelControl5.TabIndex = 6
        Me.LabelControl5.Text = "Meses (Ingr. Grav. Anual):"
        '
        'GroupControl3
        '
        Me.GroupControl3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupControl3.Controls.Add(Me.GridControl1)
        Me.GroupControl3.Location = New System.Drawing.Point(5, 271)
        Me.GroupControl3.Name = "GroupControl3"
        Me.GroupControl3.Size = New System.Drawing.Size(573, 272)
        Me.GroupControl3.TabIndex = 20
        Me.GroupControl3.Text = "Rubros"
        '
        'GridControl1
        '
        Me.GridControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridControl1.Location = New System.Drawing.Point(2, 21)
        Me.GridControl1.MainView = Me.GridView2
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemToggleSwitch1})
        Me.GridControl1.Size = New System.Drawing.Size(569, 249)
        Me.GridControl1.TabIndex = 0
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView2})
        '
        'GridView2
        '
        Me.GridView2.GridControl = Me.GridControl1
        Me.GridView2.Name = "GridView2"
        Me.GridView2.OptionsCustomization.AllowSort = False
        Me.GridView2.OptionsView.ShowFooter = True
        Me.GridView2.OptionsView.ShowGroupPanel = False
        '
        'RepositoryItemToggleSwitch1
        '
        Me.RepositoryItemToggleSwitch1.AutoHeight = False
        Me.RepositoryItemToggleSwitch1.Name = "RepositoryItemToggleSwitch1"
        Me.RepositoryItemToggleSwitch1.OffText = "Off"
        Me.RepositoryItemToggleSwitch1.OnText = "On"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(662, 545)
        Me.Controls.Add(Me.GroupControl3)
        Me.Controls.Add(Me.GroupControl2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.GroupControl1)
        Me.MinimumSize = New System.Drawing.Size(678, 557)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rubros X Empleado"
        CType(Me.cmbempleado.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl1.ResumeLayout(False)
        Me.GroupControl1.PerformLayout()
        CType(Me.dtpfecha.Properties.CalendarTimeProperties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpfecha.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudanio, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.GroupControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl2.ResumeLayout(False)
        Me.GroupControl2.PerformLayout()
        CType(Me.txtcarga.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtimp_otro.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtgasto_Otro.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmesesproy.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtaporteiess.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpFechaIng.Properties.CalendarTimeProperties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpFechaIng.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtrebajas_otras.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtingreso_otro.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtdsctoir.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtingreanual.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtmesesIGA.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GroupControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl3.ResumeLayout(False)
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemToggleSwitch1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmbempleado As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents cmbCompania As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents lblcompania As DevExpress.XtraEditors.LabelControl
    Friend WithEvents GroupControl1 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents nudanio As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btngrabar As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btneliminar As System.Windows.Forms.Button
    Friend WithEvents btnmodificar As System.Windows.Forms.Button
    Friend WithEvents btnuevo As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents DefaultLookAndFeel1 As DevExpress.LookAndFeel.DefaultLookAndFeel
    Friend WithEvents FormAssistant1 As DevExpress.XtraBars.FormAssistant
    Friend WithEvents dtpfecha As DevExpress.XtraEditors.DateEdit
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents GroupControl2 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents txtimp_otro As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtgasto_Otro As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtmesesproy As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtaporteiess As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl14 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl13 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl12 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl11 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents dtpFechaIng As DevExpress.XtraEditors.DateEdit
    Friend WithEvents txtrebajas_otras As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtingreso_otro As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtdsctoir As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtingreanual As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtmesesIGA As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl10 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl9 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl8 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl7 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents GroupControl3 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents RepositoryItemToggleSwitch1 As DevExpress.XtraEditors.Repository.RepositoryItemToggleSwitch
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents lblcodigo As DevExpress.XtraEditors.LabelControl
    Friend WithEvents botubica As System.Windows.Forms.Button
    Friend WithEvents txtubicaempleado As System.Windows.Forms.TextBox
    Friend WithEvents chkcatastrofica As System.Windows.Forms.CheckBox
    Friend WithEvents txtcarga As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl

End Class
