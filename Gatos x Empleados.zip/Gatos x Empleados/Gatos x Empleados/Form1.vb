﻿Imports System.Data
Imports System.Data.SqlClient
Imports libreria
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraEditors

Public Class Form1
    Enum estado
        Nuevo
        eliminar
        modificar
        cancelar
    End Enum
    Dim tipoestado As estado
    Dim scommand As String
    Dim llenacompania As Boolean = False

    Dim llenoEmpleado As Boolean = False
    Dim dats As New DataSet

    Dim tbgridrubros As New DataTable
    Dim tbgridtope As New DataTable
    Dim max_empleado As Integer
    Dim max_compania As Integer
    Dim bload As Boolean
    Dim Count_General As Integer = 0, valor_total1 As Double = 0, Valor_General As Double = 0, tope_individual As Double = 0, Valor_sin_salud As Double = 0
    Dim mensaje As String = ""
    Dim tipo_carga As Integer = 0
    Private Sub headergrid()

        tbgridtope.Columns.Add("Tipo", GetType(Integer))
        tbgridtope.Columns.Add("Tope", GetType(Double))

        tbgridrubros.Columns.Add("Compania", GetType(Integer))
        tbgridrubros.Columns.Add("Codigo", GetType(Integer))
        tbgridrubros.Columns.Add("Rubro", GetType(String))
        tbgridrubros.Columns.Add("S", GetType(Boolean))
        tbgridrubros.Columns.Add("Valor", GetType(Double))
        tbgridrubros.Columns.Add("Tipo", GetType(Integer))
        tbgridrubros.Columns.Add("Tope", GetType(Double))

        GridControl1.DataSource = Nothing
        GridView2.Columns.Clear()
        GridView2.OptionsView.ColumnAutoWidth = False
        GridView2.OptionsPrint.AutoWidth = False
        GridView2.BestFitColumns()

        Dim chek As New DevExpress.XtraEditors.Repository.RepositoryItemToggleSwitch

        GridControl1.DataSource = tbgridrubros
        GridView2.Columns("S").ColumnEdit = chek
        GridView2.Columns("Compania").Visible = False
        GridView2.Columns("Tipo").Visible = False
        GridView2.Columns("Codigo").Width = 50
        GridView2.Columns("Rubro").Width = 200
        GridView2.Columns("S").Width = 80
        GridView2.Columns("Valor").Width = 120
        GridView2.Columns("Tope").Visible = False
        GridView2.Columns("Codigo").OptionsColumn.ReadOnly = True
        GridView2.Columns("Rubro").OptionsColumn.ReadOnly = True
        GridView2.Columns("Valor").DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        GridView2.Columns("Valor").DisplayFormat.FormatString = "c2"

        'GridView2.Columns("Rubro").OptionsColumn.



    End Sub

    Sub New()
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        scommand = Microsoft.VisualBasic.Interaction.Command()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub
    Sub New(ByVal iscommand As String)
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        scommand = iscommand
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub
    Private Sub accionestado()
        Select Case tipoestado
            Case estado.cancelar
                btnuevo.Enabled = True
                btnmodificar.Enabled = True
                btneliminar.Enabled = True
                btngrabar.Enabled = False
                btnCancelar.Enabled = False
                cmbCompania.Enabled = True
                cmbempleado.Enabled = True
                dtpfecha.Enabled = True
                nudanio.Enabled = True
                GroupControl2.Enabled = False
                GroupControl3.Enabled = False
            Case estado.modificar, estado.eliminar, estado.Nuevo
                GroupControl2.Enabled = True
                GroupControl3.Enabled = True
                btnuevo.Enabled = False
                btnmodificar.Enabled = False
                btneliminar.Enabled = False
                btngrabar.Enabled = True
                btnCancelar.Enabled = True
                cmbCompania.Enabled = False
                cmbempleado.Enabled = False
                dtpfecha.Enabled = False
                nudanio.Enabled = False
                ' GridView5.OptionsBehavior.ReadOnly = False
        End Select
    End Sub
  

    Private Sub cmbCompania_EditValueChanged(sender As Object, e As EventArgs) Handles cmbCompania.EditValueChanged
        ' llenarempleado(cmbCompania.EditValue)

        sgCompaniaForm = cmbCompania.EditValue
        llenar_empleado(sgCompaniaForm)
        cmbempleado.EditValue = cmbempleado.Properties.GetKeyValue(-1)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Me.Dispose()
    End Sub
    Private Function verificar_empleado(codemp As Integer) As Boolean
        Dim op As Boolean = True

        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim ors As SqlDataReader
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Function
            ocomd.Connection = oCon
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "CE3"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm
            ocomd.Parameters.Add("@i_anio", SqlDbType.Int).Value = nudanio.Value
            ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = codemp
            ors = ocomd.ExecuteReader
            If ors.HasRows = True Then
                While ors.Read
                    op = True
                End While
            Else
                op = False
            End If
            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
        Return op
    End Function
    Private Function Obtener_Meses_Emp(comp As Integer, emp As Integer) As Double
        Dim op As Double = 0
        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim ors As SqlDataReader
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        Dim feccha As Date


        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Function
            ocomd.Connection = oCon
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "CFECING"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = comp
            ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = emp
            ors = ocomd.ExecuteReader
            If ors.HasRows = True Then
                While ors.Read
                    feccha = ors("TM01FECING")
                    dtpFechaIng.EditValue = feccha
                    If feccha.Year < Now.Year Then
                        op = 12
                    Else
                        op = CDbl(DateDiff("m", feccha, CDate("31/12/" & feccha.Year)))
                        If feccha.Day > 1 Then
                            op = (op - 1) + 0.5
                        End If
                    End If
                End While
            End If
            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
        Return op
    End Function

    Private Function Obtener_IngresoGravadoAnual(comp As Integer, emp As Integer, meses As Double) As Double
        Dim op As Double = 0
        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim ors As SqlDataReader
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        Dim sueldo As Double
        Dim alim As Double

        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Function
            ocomd.Connection = oCon
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "CING"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = comp
            ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = emp
            ors = ocomd.ExecuteReader
            If ors.HasRows = True Then
                While ors.Read
                    sueldo = IIf(IsDBNull(ors("NM01SDOBAS")) = True, 0, ors("NM01SDOBAS"))
                    alim = IIf(IsDBNull(ors("ROL_ALIMENTACION")) = True, 0, ors("ROL_ALIMENTACION"))
                    op = (sueldo + alim) * meses
                End While
            End If
            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
        Return op
    End Function
    Private Sub ObtenerCodigoRubro(compania As Integer, emp As Integer, anio As Integer)

        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim ors As SqlDataReader
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        Dim max As Integer

        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            ocomd.Connection = oCon
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "QN"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = compania
            ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = emp
            ocomd.Parameters.Add("@i_anio", SqlDbType.Int).Value = anio
            ors = ocomd.ExecuteReader
            If ors.HasRows = True Then
                While ors.Read
                    max = IIf(IsDBNull(ors(0)) = True, 0, ors(0))
                End While
            End If
            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try

    End Sub
    Private Sub llenarrubros(comp As Integer)
        'Dim oCon As SqlConnection
        'Dim ocomd As New SqlCommand
        'Dim ors As SqlDataReader
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oArray() As String
        Dim oDts As New DataSet

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        tbgridrubros.Rows.Clear()
        tbgridtope.Rows.Clear()
        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                .CommandText = "sp_Registrar_Rubros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "C2")
                .Parameters.AddWithValue("@i_compania", comp)
                .Parameters.AddWithValue("@i_anio", nudanio.Value)
            End With
            Dim oDar As New SqlDataAdapter(oComand)
            oDar.Fill(oDts)
            If oDts.Tables.Count > 1 Then
                If oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(0).ToString() = "collection" Then
                    oArray = Split(oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(1).ToString(), ";")
                    For i = 0 To oDts.Tables.Count - 2
                        oDts.Tables(i).TableName = oArray(i).ToString()
                    Next
                End If
            End If
            For Each oTabla As DataTable In oDts.Tables
                Select Case oTabla.TableName
                    Case "detalle"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            tbgridrubros.Rows.Add(comp, oReg("ir_codigo"), oReg("ir_descripcion"), False, oReg("valor"), oReg("Tipo"), oReg("tope_rubro"))
                        Next
                    Case "resumen"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            tbgridtope.Rows.Add(oReg("md_tipo"), oReg("md_valor"))
                        Next
                    Case "no"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            Count_General = oReg("count1")
                        Next
                End Select
            Next
            oComand = Nothing
            oCon.Close()
            oCon = Nothing

            'ocomd.Connection = oCon
            'ocomd.CommandType = CommandType.StoredProcedure
            'ocomd.CommandText = "sp_Registrar_Rubros"
            'ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "C2"
            'ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = comp
            'ors = ocomd.ExecuteReader
            'If ors.HasRows = True Then
            '    While ors.Read
            '        tbgridrubros.Rows.Add(comp, ors("ir_codigo"), ors("ir_descripcion"), False, ors("valor"), ors("Tipo"))
            '    End While
            'End If
            'ors.Close()
            'oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
    End Sub
    Private Sub btnuevo_Click(sender As Object, e As EventArgs) Handles btnuevo.Click
        If cmbempleado.EditValue > 0 Then
            tipoestado = estado.Nuevo
            accionestado()

            If verificar_empleado(cmbempleado.EditValue) = True Then
                If MessageBox.Show("Existen registros ingresados para este empleado, desea ingresar uno nuevo? , Se desactivaran los registros anteriores..." _
                                   , "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    txtmesesIGA.Text = Obtener_Meses_Emp(cmbCompania.EditValue, cmbempleado.EditValue)
                    txtingreanual.Text = Obtener_IngresoGravadoAnual(cmbCompania.EditValue, cmbempleado.EditValue, CDbl(txtmesesIGA.Text))
                    'ObtenerCodigoRubro(cmbCompania.EditValue, cmbempleado.EditValue, nudanio.Value)
                    llenarrubros(cmbCompania.EditValue)
                Else
                    btnCancelar.PerformClick()
                End If
            Else
                txtmesesIGA.Text = Obtener_Meses_Emp(cmbCompania.EditValue, cmbempleado.EditValue)
                txtingreanual.Text = Obtener_IngresoGravadoAnual(cmbCompania.EditValue, cmbempleado.EditValue, CDbl(txtmesesIGA.Text))
                'ObtenerCodigoRubro(cmbCompania.EditValue, cmbempleado.EditValue, nudanio.Value)
                llenarrubros(sgCompaniaForm)
            End If
            txtmesesproy.Text = txtmesesIGA.Text
        Else
            MessageBox.Show("Debe seleccionar un empleado", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btnmodificar_Click(sender As Object, e As EventArgs) Handles btnmodificar.Click
        tipoestado = estado.modificar
        accionestado()
    End Sub

    Private Sub btneliminar_Click(sender As Object, e As EventArgs) Handles btneliminar.Click
        tipoestado = estado.eliminar
        accionestado()
        Dim ssl As String = ""
        If MessageBox.Show("Esta seguro que desea eliminar el registro de este empleado: " & cmbempleado.Text, "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Dim oCon As SqlConnection
            Dim ocomd As New SqlCommand
            Dim ors As SqlDataReader
            Dim oconexion As gConnectionSql.gConnection
            oconexion = New gConnectionSql.gConnection
            tbgridrubros.Rows.Clear()
            Try
                oCon = Nothing
                If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
                ocomd.Connection = oCon
                ocomd.CommandType = CommandType.StoredProcedure
                ocomd.CommandText = "sp_Registrar_Rubros"
                ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "D"
                ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm
                ocomd.Parameters.Add("@i_codigo", SqlDbType.Int).Value = lblcodigo.Text
                ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = cmbempleado.EditValue
                ocomd.Parameters.Add("@i_anio", SqlDbType.Int).Value = nudanio.Value
                ocomd.ExecuteNonQuery()
                oCon.Close()
            Catch ex As Exception
                MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
            End Try
            btnCancelar_Click(sender, e)
        Else

        End If
    End Sub
    Private Sub limpiar_formasDEV(cont As Control)
        For Each contt As Control In cont.Controls
            If TypeOf contt Is DevExpress.XtraEditors.TextEdit Then
                contt.Text = 0
            End If
        Next
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        tipoestado = estado.cancelar
        accionestado()
        limpiar_info(Me)
        lblcodigo.Text = ""
    End Sub

    Private Sub cmbempleado_EditValueChanged(sender As Object, e As EventArgs) Handles cmbempleado.EditValueChanged
        If nudanio.Value > 1900 Then
            If cmbempleado.EditValue > 0 Then
                llenarinformacion(cmbCompania.EditValue, cmbempleado.EditValue, nudanio.Value)
            End If
        End If
    End Sub
    Private Function validar() As Boolean
        Dim op As Boolean = True
        Dim Count1 As Integer = 0
        Dim Salud As Double = 0
        ErrorProvider1.Clear()

        If txtingreanual.Text <> "" And txtingreanual.Text <> "0.00" Then
            If txtingreanual.EditValue = 0 Then
                ErrorProvider1.SetError(txtingreanual, "No se ha ingresado Valor de Ingreso Anuales")
                op = False
            End If
        Else
            ErrorProvider1.SetError(txtingreanual, "No se ha ingresado Valor de Ingreso Anuales")
            op = False
        End If

        If txtaporteiess.Text <> "" And txtaporteiess.Text <> "0.00" Then
            If txtaporteiess.EditValue = 0 Then
                ErrorProvider1.SetError(txtaporteiess, "Falta valor de Aporte al IESS")
                op = False
            End If
        Else
            ErrorProvider1.SetError(txtaporteiess, "Falta valor de Aporte al IESS")
            op = False
        End If

        If txtmesesIGA.Text <> "" And txtmesesIGA.Text <> "0.00" Then
            If txtmesesIGA.EditValue = 0 Then
                ErrorProvider1.SetError(txtmesesIGA, "No ha ingresado el numero de Meses para el calculo del ingreso Gravado Anual")
                op = False
            End If
        Else
            ErrorProvider1.SetError(txtmesesIGA, "No ha ingresado el numero de Meses para el calculo del ingreso Gravado Anual")
            op = False
        End If

        If txtmesesproy.Text <> "" And txtmesesproy.Text <> "0.00" Then
            If txtmesesproy.EditValue = 0 Then
                ErrorProvider1.SetError(txtmesesproy, "No ha ingresado el numero de Meses Proyectado")
                op = False
            End If
        Else
            ErrorProvider1.SetError(txtmesesproy, "No ha ingresado el numero de Meses Proyectado")
            op = False
        End If
        For Each roww As DataRow In tbgridrubros.Rows
            If roww("S") = True Then
                If CDbl(roww("Valor")) = 0 Then
                    op = False
                    MessageBox.Show("Hay filas activas que no tiene valor ")
                End If
            End If
        Next

        '  2023


        ''*** Preguntar si todos los rubros generales estan ingresados
        'Valor_General = Extraer_Datos_DateTable(tbgridtope, "Tipo", "Tope", 1)
        'Count1 = 0
        'For Each oRow As DataRow In tbgridrubros.Rows
        '    If oRow("S") = True Then
        '        If CDbl(oRow("Valor")) > 0 And oRow("Tipo") = 1 Then
        '            Count1 += 1
        '        End If
        '    End If
        'Next
        'valor_total1 = 0
        'tope_individual = Valor_General / Count_General
        'mensaje = ""
        ''If Count1 = Count_General Then
        ''    For Each oRow As DataRow In tbgridrubros.Rows
        ''        If oRow("S") = True Then
        ''            If CDbl(oRow("Valor")) > 0 And oRow("Tipo") = 1 Then
        ''                If oRow("Valor") > tope_individual Then
        ''                    mensaje = mensaje & oRow("Rubro") & ", "
        ''                End If
        ''                valor_total1 = valor_total1 + oRow("Valor")
        ''            End If
        ''        End If
        ''    Next
        ''    If mensaje.Trim.Length > 0 Then
        ''        mensaje = mensaje & " Los rubros sobrepasan al valor de " & Format(tope_individual, "###,###,##0.00")
        ''        MsgBox(mensaje)
        ''        op = False
        ''    End If
        ''    If Valor_General <> valor_total1 Then
        ''        MessageBox.Show("El total de los ingresos General declarados sobrepasa el valor permitido", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ''        op = False
        ''    End If
        ''Else
        'mensaje = ""
        'For Each oRow As DataRow In tbgridrubros.Rows
        '    If oRow("S") = True Then
        '        If CDbl(oRow("Valor")) > 0 And oRow("Codigo") <> 2 And oRow("Tipo") = 1 Then
        '            If oRow("Valor") > oRow("Tope") Then
        '                mensaje = mensaje & oRow("Rubro") & " es mayor a " & Format(oRow("Tope"), "###,###,##0.00") & ", "
        '            End If
        '            'If oRow("Valor") > oRow("Tope") Then
        '            '    MessageBox.Show("El valor de Salud Sobrepasa al permitido a " & Format(oRow("Tope"), "###,###,##0.00"), "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information)
        '            '    op = False
        '            '    Exit For
        '            'End If
        '        End If
        '    End If
        'Next
        'If mensaje.Trim.Length > 0 Then
        '    MsgBox(mensaje)
        '    op = False
        '    GoTo seguir
        'End If
        'Salud = 0
        'Valor_sin_salud = 0
        'mensaje = ""
        'For Each oRow As DataRow In tbgridrubros.Rows
        '    If oRow("S") = True Then
        '        If CDbl(oRow("Valor")) > 0 And oRow("Codigo") <> 2 And oRow("Tipo") = 1 Then
        '            Valor_sin_salud = Valor_sin_salud + oRow("Valor")
        '        End If
        '    End If
        'Next
        'For Each oRow As DataRow In tbgridrubros.Rows
        '    If oRow("S") = True Then
        '        If CDbl(oRow("Valor")) > 0 And oRow("Codigo") = 2 And oRow("Tipo") = 1 Then
        '            Salud = oRow("Valor")
        '        End If
        '    End If
        'Next
        'If Salud > 0 Then
        '    'Count1 -1
        '    If Salud > (Valor_General - Valor_sin_salud) Then
        '        MessageBox.Show("El Ingreso sobre salud sobrepasa el valor permitido de " & Format((Valor_General - Valor_sin_salud), "###,###,##0.00"), "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information)

        '    End If
        'End If
        '' End If

seguir:
        Return op
    End Function
    Private Function guardar() As Boolean
        Dim op As Boolean = True, ierror As Integer = 0, smensaje As String = "", idnumero As Double = 0, opcion As String, codigo As Double = 0
        'If validar() = False Then
        '    MessageBox.Show("ingrese la informacion requerida", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information)
        '    op = False
        '    Return op
        '    Exit Function
        'End If
        If GridView2.Columns("Valor").SummaryItem.SummaryValue = 0 Then
            MessageBox.Show("La suma del grid no debe ser igual a cero", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information)
            op = False
            Return op
            Exit Function
        End If
        Dim oCon As SqlConnection
        Dim oComand As New SqlCommand
        Dim audxml As New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        'Dim o_cod As SqlParameter
        'Dim o_error As SqlParameter
        'Dim o_mensaje As SqlParameter
        'Dim tempcod As Integer
        'Dim temperro As Integer

        ' MsgBox(tipoestado)

        'Dim max_deduccion As Double


        Try
            If lblcodigo.Text.Trim.Length = 0 Then
                codigo = 0
            Else
                codigo = CDbl(lblcodigo.Text)
            End If

            '-------------------------GENERANDO EL XML CON LOS DATOS DE GV Y GASTOA PARA USAR EN EL SP DE RUBROS------------------------
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Function

            Dim dxmla As New XElement("AUDITORIA")
            Dim cxmla As New XElement("PARAMETROS")
            cxmla.Add(New XAttribute("compania", sgCompania))
            cxmla.Add(New XAttribute("ejecutable", My.Application.Info.AssemblyName))
            cxmla.Add(New XAttribute("usuario", sgUsuario))
            cxmla.Add(New XAttribute("maquina", sgMaquina))
            dxmla.Add(cxmla)
            audxml.Add(dxmla)


            Dim xml As New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
            Dim dxml As New XElement("GTOPER")
            Dim cabxml As New XElement("CAB")
            'Dim detxml As New XElement("DET")
            xml.Add(dxml)
            dxml.Add(cabxml)
            cabxml.Add(New XAttribute("compania", sgCompania))
            cabxml.Add(New XAttribute("usuario", sgUsuario))
            cabxml.Add(New XAttribute("maquina", sgMaquina))
            cabxml.Add(New XAttribute("empleado", cmbempleado.EditValue))
            cabxml.Add(New XAttribute("codigo", codigo.ToString("###########0.00")))
            cabxml.Add(New XAttribute("anio", nudanio.Value))
            cabxml.Add(New XAttribute("fecha", Format(dtpfecha.DateTime.Date, "yyyyMMdd")))
            cabxml.Add(New XAttribute("estado", "A"))
            cabxml.Add(New XAttribute("ing_anual", CDbl(txtingreanual.Text).ToString("###########0.00")))
            cabxml.Add(New XAttribute("iess_anual", CDbl(txtaporteiess.Text).ToString("###########0.00")))
            cabxml.Add(New XAttribute("ir_cobrado", CDbl(txtdsctoir.Text).ToString("###########0.00")))
            cabxml.Add(New XAttribute("mes_proy", CInt(txtmesesproy.Text)))
            cabxml.Add(New XAttribute("ing_otro_emple", CDbl(txtingreso_otro.Text).ToString("###########0.00")))
            cabxml.Add(New XAttribute("gas_otro_emple", CDbl(txtgasto_Otro.Text).ToString("###########0.00")))
            cabxml.Add(New XAttribute("otras_reba_otro_emple", CDbl(txtrebajas_otras.Text).ToString("###########0.00")))
            cabxml.Add(New XAttribute("ir_otro_emple", CDbl(txtimp_otro.Text).ToString("###########0.00")))
            '------------------------------------------------------------------------------------------------------
            cabxml.Add(New XAttribute("cargas", CDbl(txtcarga.Text).ToString("###########0")))
            cabxml.Add(New XAttribute("emf_catastrofica", IIf(chkcatastrofica.Checked = True, "S", "N")))

            Dim i As Integer = 0
            For Each oRws As DataRow In tbgridrubros.Rows
                i += 1
                If oRws("S") = True Then
                    Dim detxml As New XElement("DET")
                    'detxml = New XElement("DET")
                    detxml.Add(New XAttribute("secuencia", i))
                    detxml.Add(New XAttribute("gasto_personal", oRws("Codigo")))
                    detxml.Add(New XAttribute("valor", oRws("Valor")))
                    ' detxml.Add(New XAttribute("gasto_personal", oRws("Valor")))
                    cabxml.Add(detxml)
                End If
            Next
            opcion = IIf(tipoestado = 2, "update", "insert")
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .CommandText = "sp_Registrar_Rubros"
                .Parameters.AddWithValue("@i_operacion", opcion)
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                .Parameters.AddWithValue("@i_usuario", sgUsuario)
                .Parameters.AddWithValue("@i_maquina", sgMaquina)
                .Parameters.AddWithValue("@i_anio", nudanio.Value)
                .Parameters.AddWithValue("@i_empleado", cmbempleado.EditValue)
                .Parameters.AddWithValue("@i_codigo", codigo)
                .Parameters.AddWithValue("@i_xml", xml.ToString)
                .Parameters.AddWithValue("@i_xml_aud", audxml.ToString)
                .Parameters.Add("@o_idnumero", SqlDbType.Float)
                .Parameters.Add("@o_error", SqlDbType.Int)
                .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 8000)
                .Parameters("@o_idnumero").Direction = ParameterDirection.Output
                .Parameters("@o_error").Direction = ParameterDirection.Output
                .Parameters("@o_mensaje").Direction = ParameterDirection.Output
            End With
            oComand.ExecuteScalar()
            idnumero = oComand.Parameters("@o_idnumero").Value
            ierror = oComand.Parameters("@o_error").Value
            smensaje = oComand.Parameters("@o_mensaje").Value

            oComand = Nothing

            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oCon = Nothing
            'MessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
            If ierror = 1 Then
                op = False
                MessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                op = True
                MessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
        Return op
        '------------------------------------------------------------------------------------------------------
    End Function

    Private Sub btngrabar_Click(sender As Object, e As EventArgs) Handles btngrabar.Click
        If validar() = True Then
            If guardar() = True Then
                'MessageBox.Show("Transaccion ok...", "Mensaje del sistema " & NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                btnCancelar_Click(sender, e)
            End If
        End If
    End Sub
    Private Sub limpiar_info(pcont As Control)
        For Each cont As Control In GroupControl2.Controls
            If TypeOf cont Is DevExpress.XtraEditors.TextEdit Then
                cont.Text = ""
            End If
        Next
        tbgridrubros.Rows.Clear()
    End Sub
    Private Sub llenarinformacion(comp As Integer, emp As Integer, anio As Integer)
        Dim oCon As SqlConnection
        Dim oComand As New SqlCommand
        Dim oArray() As String
        'Dim oTobj As String
        'Dim oRs As SqlDataReader
        Dim oDts As New DataSet
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        limpiar_info(Me)
        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand.Connection = oCon
            oComand.CommandType = CommandType.StoredProcedure
            oComand.CommandText = "sp_Registrar_Rubros"
            oComand.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "query"
            oComand.Parameters.Add("@i_compania", SqlDbType.Int).Value = comp
            oComand.Parameters.Add("@i_empleado", SqlDbType.Int).Value = emp
            oComand.Parameters.Add("@i_anio", SqlDbType.Int).Value = anio
            ' ocomd.Parameters.Add("@i_codigo", SqlDbType.Int).Value = comp
            Dim oDar As New SqlDataAdapter(oComand)
            oDar.Fill(oDts)
            If oDts.Tables.Count > 1 Then
                If oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(0).ToString() = "collection" Then
                    oArray = Split(oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(1).ToString(), ";")
                    For i = 0 To oDts.Tables.Count - 2
                        oDts.Tables(i).TableName = oArray(i).ToString()
                    Next
                End If
            End If
            For Each oTabla As DataTable In oDts.Tables
                Select Case oTabla.TableName
                    Case "cab"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            txtmesesIGA.Text = Obtener_Meses_Emp(comp, emp)
                            txtmesesproy.Text = oReg("meses_proy")
                            txtingreanual.Text = oReg("ing_anual")
                            txtaporteiess.Text = oReg("iess_anual")
                            txtdsctoir.Text = oReg("ir_cobrado")
                            dtpfecha.EditValue = oReg("fecha")
                            txtingreso_otro.Text = oReg("ingresos_otros")
                            txtgasto_Otro.Text = oReg("gastos_otros")
                            txtrebajas_otras.Text = oReg("rebajas_otros")
                            txtimp_otro.Text = oReg("impuesto_otros")
                            lblcodigo.Text = oReg("codigo")
                            '------------------------------------------------------------------------------------------------------
                            txtcarga.Text = oReg("cargas")
                            chkcatastrofica.Checked = IIf(oReg("emf_catastrofica") = "S", True, False)
                            '------------------------------------------------------------------------------------------------------
                        Next
                    Case "det"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            tbgridrubros.Rows.Add(comp, oReg("codigo"), oReg("descripcion"), IIf(oReg("valor") > 0, True, False), oReg("valor"), oReg("tipo"), oReg("tope_rubro"))
                        Next
                    Case "res"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            tbgridtope.Rows.Add(oReg("tipo"), oReg("valor"))
                        Next
                    Case "no"
                        For Each oReg As System.Data.DataRow In oTabla.Rows
                            Count_General = oReg("count1")
                        Next
                End Select
            Next

            oComand = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
    End Sub

    Private Sub nudanio_ValueChanged(sender As Object, e As EventArgs) Handles nudanio.ValueChanged
        If nudanio.Value > 1900 Then
            If cmbempleado.EditValue > 0 Then
                llenarinformacion(cmbCompania.EditValue, cmbempleado.EditValue, nudanio.Value)
            End If
        End If
    End Sub

    Private Sub txtmesesproy_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtmesesproy.KeyPress
        'If IsNumeric(e.KeyChar) = True Then
        '    If CDbl(txtmesesproy.Text & e.KeyChar.ToString) > 12 Then
        '        e.Handled = True
        '    End If
        'End If
    End Sub

    Private Function valor_default(tipo As Integer, anio As Integer) As Double
        Dim op As Double = 0
        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand

        Dim ors As SqlDataReader

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Function
            ocomd.Connection = oCon
            ocomd.CommandText = "sp_Mantenimiento_DeduccionIR"
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "Monto_Max"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm 'cmbCompania.EditValue
            ocomd.Parameters.Add("@i_tipo", SqlDbType.Int).Value = tipo
            ocomd.Parameters.Add("@i_anio", SqlDbType.Int).Value = anio
            ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = cmbempleado.EditValue
            ors = ocomd.ExecuteReader
            If ors.HasRows = True Then
                While ors.Read
                    op = IIf(IsDBNull(ors(0)) = True, 0, ors(0))
                End While
            Else
                MessageBox.Show("No existe valores por default para el año: " & anio, "Mensaje del sistema " & NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
        Return op
    End Function



    Private Sub GridView2_CellValueChanging(sender As Object, e As DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs) Handles GridView2.CellValueChanging
        If e.Column.Name = "colS" Then
            Try
                If e.Value = False Then
                    GridView2.SetRowCellValue(GridView2.FocusedRowHandle, "Valor", 0)
                    Exit Sub
                End If


                If GridView2.GetFocusedRowCellValue("Tipo") > 1 Then
                    If e.Value = True Then
                        GridView2.SetRowCellValue(GridView2.FocusedRowHandle, "Valor", valor_default(GridView2.GetFocusedRowCellValue("Tipo"), nudanio.Value))
                    Else
                        GridView2.SetRowCellValue(GridView2.FocusedRowHandle, "Valor", 0)
                    End If
                End If

            Catch ex As Exception

            End Try
        End If
        If e.Column.Name = "colValor" Then
            If GridView2.GetFocusedRowCellValue("S") = False Then

            End If
        End If
    End Sub
    Private Sub GridView2_InvalidValueException(sender As Object, e As DevExpress.XtraEditors.Controls.InvalidValueExceptionEventArgs) Handles GridView2.InvalidValueException
        e.ExceptionMode = DevExpress.XtraEditors.Controls.ExceptionMode.Ignore
    End Sub

    Private Sub GridView2_ValidatingEditor(sender As Object, e As DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventArgs) Handles GridView2.ValidatingEditor
        Dim View As GridView = sender
        If View.FocusedColumn.FieldName = "Valor" Then
            If GridView2.GetFocusedRowCellValue("S") = False Then
                e.Valid = False
            End If
        End If

    End Sub
    Private Sub calcular_aporteIESS()

        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim sueldo As Double
        Dim ors As SqlDataReader
        Dim apiess As Double = 0
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            ocomd.Connection = oCon
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "CAPIESS"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm 'cmbCompania.EditValue
            ors = ocomd.ExecuteReader
            If ors.HasRows = False Then
                MessageBox.Show("No existe parametro para porcentaje de Aporte al IESS...", "Mensaje del sistema " & NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                oCon.Close()
                Exit Sub
            Else
                While ors.Read
                    apiess = IIf(IsDBNull(ors(0)) = True, 0, ors(0))
                End While
            End If
            ors.Close()
            ocomd = New SqlCommand
            ocomd.Connection = oCon
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "CING"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm 'cmbCompania.EditValue
            ocomd.Parameters.Add("@i_empleado", SqlDbType.Int).Value = cmbempleado.EditValue
            ors = ocomd.ExecuteReader
            If ors.HasRows = True Then
                While ors.Read
                    sueldo = IIf(IsDBNull(ors("NM01SDOBAS")) = True, 0, ors("NM01SDOBAS"))
                    sueldo = sueldo * txtmesesIGA.EditValue
                    txtaporteiess.EditValue = (sueldo * apiess) / 100
                End While
            End If
            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try

    End Sub
    Private Sub txtmesesIGA_LostFocus(sender As Object, e As EventArgs) Handles txtmesesIGA.LostFocus
        If txtmesesIGA.EditValue = Nothing Then
            txtmesesIGA.EditValue = 0
        End If
        txtingreanual.EditValue = Obtener_IngresoGravadoAnual(cmbCompania.EditValue, cmbempleado.EditValue, txtmesesIGA.EditValue)
        calcular_aporteIESS()
    End Sub

    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        bload = False
        sgMaquina = My.Computer.Name
        If Load_Siac(Me, "ROLES", scommand) = False Then Me.Dispose()
        llenar_compania()
        If max_compania > 0 Then
            cmbCompania.EditValue = cmbCompania.Properties.GetKeyValue(0)
            If mostrar_empresa() = "N" Then
                lblcompania.Enabled = False
                lblcompania.Visible = False
                cmbCompania.Enabled = False
                cmbCompania.Visible = False
            Else
                lblcompania.Enabled = True
                lblcompania.Visible = True
                cmbCompania.Enabled = True
                cmbCompania.Visible = True

            End If
        End If
        sgCompaniaForm = sgCompania
        tipoestado = estado.cancelar
        accionestado()
        headergrid()
        dtpfecha.EditValue = Now.Date
        nudanio.Value = Now.Date.Year
        GridView2.Columns("Valor").Summary.Add(DevExpress.Data.SummaryItemType.Sum, "Valor", "Total= $ {0:#.##}")
        cargar_parametro()
        If tipo_carga = 1 Then
            txtcarga.Text = "0"
            txtcarga.Enabled = False
            chkcatastrofica.Checked = False
            chkcatastrofica.Enabled = False
        Else
            txtcarga.Enabled = True
            chkcatastrofica.Enabled = True
        End If

        bload = True
    End Sub
    Private Sub cargar_parametro()

        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim sueldo As Double
        Dim ors As SqlDataReader
        Dim apiess As Double = 0
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            ocomd.Connection = oCon
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "para"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm 'cmbCompania.EditValue
            ors = ocomd.ExecuteReader
            If ors.HasRows = False Then
                MessageBox.Show("No existe parametro impuestos...", "Mensaje del sistema " & NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                oCon.Close()
                Exit Sub
            Else
                While ors.Read
                    tipo_carga = ors("carga_imp")
                End While
            End If

            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try

    End Sub

#Region "FUNCIONES Y PROCEDIMIENTOS BASICOS"
    Private Sub llenar_compania()

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim dt As New DataSet
        Dim dtadap As SqlDataAdapter

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                '.CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Compania"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "query_empresa")
            End With


            dtadap = New SqlDataAdapter(oComand)
            dtadap.Fill(dt)
            max_compania = dt.Tables(0).Rows.Count

            ' llenacompania = False
            cmbCompania.Properties.DataSource = dt.Tables(0)
            cmbCompania.Properties.DisplayMember = "Nombre"
            cmbCompania.Properties.ValueMember = "Codigo"
            ' llenacompania = True
            oComand = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub llenar_empleado(compania As Integer)

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim dt As New DataSet
        Dim dtadap As SqlDataAdapter
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            dats.Clear()
            With oComand
                .CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Personal"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "Cons_empleado")
                .Parameters.AddWithValue("@i_compania", compania)

            End With
            dtadap = New SqlDataAdapter(oComand)
            dtadap.Fill(dats)
            oCon.Close()
            cmbempleado.Properties.DataSource = dats.Tables(0)
            cmbempleado.Properties.DisplayMember = "Nombre"
            cmbempleado.Properties.ValueMember = "Codigo"
            max_empleado = dats.Tables(0).Rows.Count
            cmbempleado.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            cmbempleado.Properties.View.BestFitColumns(True)
            cmbempleado.Properties.PopupFormWidth = 800
            cmbempleado.Properties.PopupFilterMode = PopupFilterMode.StartsWith
            cmbempleado.Properties.ShowFooter = True
            ' cmbempleado.EditValue = IIf(CType(cmbempleado.Properties.DataSource, DataTable).Rows.Count > 0, cmbempleado.Properties.GetKeyValue(0), cmbempleado.Properties.GetKeyValue(-1))
            cmbempleado.EditValue = -1 'IIf(CType(cmbempleado.Properties.DataSource, DataTable).Rows.Count > 0, CType(cmbempleado.Properties.DataSource, DataTable).Rows(0).Item(0).ToString, cmbempleado.Properties.GetIndexByKeyValue(-1))
            cmbempleado.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
            cmbempleado.Properties.ImmediatePopup = True
            cmbempleado.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
            oComand = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Function mostrar_empresa() As String

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim oRs As SqlDataReader

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        mostrar_empresa = "N"
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbase, sguser, sgpw, oCon) = False Then Exit Function
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "PARMSp_Mant_Parametro_General"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "mos_emp")

            End With
            oRs = oComand.ExecuteReader()
            If oRs.HasRows = True Then
                If oRs.Read Then

                    mostrar_empresa = oRs.Item("mostrar_empresa")
                End If
            End If

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Function fecha_proceso(compania As Integer) As String
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        'Dim ierror As Integer, smensaje As String
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            fecha_proceso = ""
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Function
            oComand = New SqlCommand
            With oComand

                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "fec_proc")
                .Parameters.AddWithValue("@NT08CODCIA", compania)

            End With
            oRs = oComand.ExecuteReader()

            If oRs.HasRows = True Then
                If oRs.Read Then
                    fecha_proceso = Format(oRs.Item("fecha"), "dd/MM/yyyy")
                End If
            End If


            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)

        End Try
    End Function

#End Region

    Private Sub botubica_Click(sender As Object, e As EventArgs) Handles botubica.Click
        Try
            If txtubicaempleado.Text.Trim.Length = 0 Then
                XtraMessageBox.Show("No ha ingresado el codigo de empleado...", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtubicaempleado.Focus()
                Exit Sub
            End If
            If Extraer_Datos_DateTable(CType(cmbempleado.Properties.DataSource, DataTable), "Codigo", "Nombre", txtubicaempleado.Text.Trim).Trim.Length = 0 Then
                XtraMessageBox.Show("No existe empleado con este codigo...", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtubicaempleado.Text = ""
                txtubicaempleado.Focus()
                Exit Sub
            End If
            cmbempleado.EditValue = txtubicaempleado.Text
            '  Call cargarempleado(cmbempleado.EditValue, "Query")
        Catch ex As Exception
            XtraMessageBox.Show("Error..." & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)

        End Try
    End Sub
    Function Extraer_Datos_DateTable(table As DataTable, ColComparacion As String, ColRespuesta As String, ValEvaluacion As String) As String
        Try
            Dim ValRespuesta As String
            ValRespuesta = ""
            For Each oReg As DataRow In table.Rows
                If oReg(ColComparacion) = ValEvaluacion Then
                    ValRespuesta = oReg(ColRespuesta)
                End If
            Next
            Return ValRespuesta
        Catch ex As Exception
            MessageBox.Show("Error : " & ex.Message, "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Private Sub txtubicaempleado_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtubicaempleado.KeyPress
        Numeros(e)
        If e.KeyChar = ChrW(Keys.Enter) Then
            If txtubicaempleado.Text.Trim.Length > 0 Then
                botubica.PerformClick()
            End If
        End If
    End Sub

    Private Sub txtubicaempleado_TextChanged(sender As Object, e As EventArgs) Handles txtubicaempleado.TextChanged

    End Sub


    Private Sub GridControl1_Click(sender As Object, e As EventArgs) Handles GridControl1.Click

    End Sub


End Class
