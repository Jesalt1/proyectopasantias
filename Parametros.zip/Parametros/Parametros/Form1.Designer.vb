﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mnsForma = New System.Windows.Forms.MenuStrip()
        Me.mnunuevo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnumodificar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuconsultar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnugrabar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnucancelar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnusalir = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlfrente = New System.Windows.Forms.Panel()
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.pnlfondo = New System.Windows.Forms.Panel()
        Me.gctrlDatos = New DevExpress.XtraEditors.GroupControl()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txtporfonres = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtmaxsueldo = New System.Windows.Forms.TextBox()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.chkbbloquec = New System.Windows.Forms.CheckBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.cmbdefault = New System.Windows.Forms.ComboBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtporemb = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.cmbcontbenef = New System.Windows.Forms.ComboBox()
        Me.cmbcontsueldo = New System.Windows.Forms.ComboBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtctaiece = New System.Windows.Forms.TextBox()
        Me.txtctasecap = New System.Windows.Forms.TextBox()
        Me.txtcodBanco = New System.Windows.Forms.TextBox()
        Me.txtDiasPruebas = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.chkprovicionar = New System.Windows.Forms.CheckBox()
        Me.txtctafondo = New System.Windows.Forms.TextBox()
        Me.txtctavacaciones = New System.Windows.Forms.TextBox()
        Me.txtctaxiv = New System.Windows.Forms.TextBox()
        Me.txtctaxiii = New System.Windows.Forms.TextBox()
        Me.txtctaaporte = New System.Windows.Forms.TextBox()
        Me.GroupControl2 = New DevExpress.XtraEditors.GroupControl()
        Me.txtPorcentaje2 = New System.Windows.Forms.TextBox()
        Me.txtPorcentaje1 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.txtXIV = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.dtpFecFXIV = New System.Windows.Forms.DateTimePicker()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.dtpFecIXIV = New System.Windows.Forms.DateTimePicker()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.dtpFecFXIII = New System.Windows.Forms.DateTimePicker()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.dtpFecIXIII = New System.Windows.Forms.DateTimePicker()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.mskFecPro = New System.Windows.Forms.DateTimePicker()
        Me.chkbloqueo = New System.Windows.Forms.CheckBox()
        Me.txtCtaComponente = New System.Windows.Forms.TextBox()
        Me.txtCtaSalario = New System.Windows.Forms.TextBox()
        Me.txtImpIva = New System.Windows.Forms.TextBox()
        Me.txtImpRenta = New System.Windows.Forms.TextBox()
        Me.txtRepresentante = New System.Windows.Forms.TextBox()
        Me.txtIdentificacion = New System.Windows.Forms.TextBox()
        Me.txtIECE = New System.Windows.Forms.TextBox()
        Me.txtSECAP = New System.Windows.Forms.TextBox()
        Me.txtAportaIess = New System.Windows.Forms.TextBox()
        Me.txtIESSPT = New System.Windows.Forms.TextBox()
        Me.txtApAdIESS = New System.Windows.Forms.TextBox()
        Me.txtApIESS = New System.Windows.Forms.TextBox()
        Me.txtTransporte = New System.Windows.Forms.TextBox()
        Me.txtBonificacion = New System.Windows.Forms.TextBox()
        Me.txtComSPIA = New System.Windows.Forms.TextBox()
        Me.txtSMVG = New System.Windows.Forms.TextBox()
        Me.txtCodAct = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupControl1 = New DevExpress.XtraEditors.GroupControl()
        Me.lblcompania = New DevExpress.XtraEditors.LabelControl()
        Me.cmbcompania = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.cbotomacarga = New System.Windows.Forms.ComboBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.mnsForma.SuspendLayout()
        Me.pnlfrente.SuspendLayout()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfondo.SuspendLayout()
        CType(Me.gctrlDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gctrlDatos.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.GroupControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl2.SuspendLayout()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl1.SuspendLayout()
        CType(Me.cmbcompania.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnsForma
        '
        Me.mnsForma.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnunuevo, Me.mnumodificar, Me.mnuconsultar, Me.mnugrabar, Me.mnucancelar, Me.mnusalir})
        Me.mnsForma.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.mnsForma.Location = New System.Drawing.Point(0, 0)
        Me.mnsForma.Name = "mnsForma"
        Me.mnsForma.Size = New System.Drawing.Size(708, 24)
        Me.mnsForma.TabIndex = 1
        Me.mnsForma.Text = "MenuStrip1"
        '
        'mnunuevo
        '
        Me.mnunuevo.Image = Global.Parametros.My.Resources.Resources.application_add
        Me.mnunuevo.Name = "mnunuevo"
        Me.mnunuevo.Size = New System.Drawing.Size(77, 20)
        Me.mnunuevo.Text = "&Ingresar"
        '
        'mnumodificar
        '
        Me.mnumodificar.Image = Global.Parametros.My.Resources.Resources.application_form_edit
        Me.mnumodificar.Name = "mnumodificar"
        Me.mnumodificar.Size = New System.Drawing.Size(86, 20)
        Me.mnumodificar.Text = "&Modificar"
        '
        'mnuconsultar
        '
        Me.mnuconsultar.Image = Global.Parametros.My.Resources.Resources.application_form_magnify
        Me.mnuconsultar.Name = "mnuconsultar"
        Me.mnuconsultar.Size = New System.Drawing.Size(86, 20)
        Me.mnuconsultar.Text = "C&onsultar"
        '
        'mnugrabar
        '
        Me.mnugrabar.Enabled = False
        Me.mnugrabar.Image = Global.Parametros.My.Resources.Resources.table_save
        Me.mnugrabar.Name = "mnugrabar"
        Me.mnugrabar.Size = New System.Drawing.Size(77, 20)
        Me.mnugrabar.Text = "&Guardar"
        '
        'mnucancelar
        '
        Me.mnucancelar.Enabled = False
        Me.mnucancelar.Image = Global.Parametros.My.Resources.Resources.stock_no
        Me.mnucancelar.Name = "mnucancelar"
        Me.mnucancelar.Size = New System.Drawing.Size(81, 20)
        Me.mnucancelar.Text = "&Cancelar"
        '
        'mnusalir
        '
        Me.mnusalir.Image = Global.Parametros.My.Resources.Resources.stock_exit
        Me.mnusalir.Name = "mnusalir"
        Me.mnusalir.Size = New System.Drawing.Size(57, 20)
        Me.mnusalir.Text = "&Salir"
        '
        'pnlfrente
        '
        Me.pnlfrente.Controls.Add(Me.GridControl1)
        Me.pnlfrente.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlfrente.Location = New System.Drawing.Point(2, 2)
        Me.pnlfrente.Name = "pnlfrente"
        Me.pnlfrente.Size = New System.Drawing.Size(695, 536)
        Me.pnlfrente.TabIndex = 2
        '
        'GridControl1
        '
        Me.GridControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridControl1.Location = New System.Drawing.Point(0, 0)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(695, 536)
        Me.GridControl1.TabIndex = 1
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        '
        'pnlfondo
        '
        Me.pnlfondo.Controls.Add(Me.gctrlDatos)
        Me.pnlfondo.Location = New System.Drawing.Point(6, 45)
        Me.pnlfondo.Name = "pnlfondo"
        Me.pnlfondo.Size = New System.Drawing.Size(700, 549)
        Me.pnlfondo.TabIndex = 3
        '
        'gctrlDatos
        '
        Me.gctrlDatos.AutoSize = True
        Me.gctrlDatos.Controls.Add(Me.cbotomacarga)
        Me.gctrlDatos.Controls.Add(Me.Label43)
        Me.gctrlDatos.Controls.Add(Me.Label42)
        Me.gctrlDatos.Controls.Add(Me.txtporfonres)
        Me.gctrlDatos.Controls.Add(Me.Label41)
        Me.gctrlDatos.Controls.Add(Me.txtmaxsueldo)
        Me.gctrlDatos.Controls.Add(Me.PanelControl3)
        Me.gctrlDatos.Controls.Add(Me.Label39)
        Me.gctrlDatos.Controls.Add(Me.txtporemb)
        Me.gctrlDatos.Controls.Add(Me.Label38)
        Me.gctrlDatos.Controls.Add(Me.Label37)
        Me.gctrlDatos.Controls.Add(Me.cmbcontbenef)
        Me.gctrlDatos.Controls.Add(Me.cmbcontsueldo)
        Me.gctrlDatos.Controls.Add(Me.Label36)
        Me.gctrlDatos.Controls.Add(Me.Label35)
        Me.gctrlDatos.Controls.Add(Me.txtctaiece)
        Me.gctrlDatos.Controls.Add(Me.txtctasecap)
        Me.gctrlDatos.Controls.Add(Me.txtcodBanco)
        Me.gctrlDatos.Controls.Add(Me.txtDiasPruebas)
        Me.gctrlDatos.Controls.Add(Me.Label34)
        Me.gctrlDatos.Controls.Add(Me.Label33)
        Me.gctrlDatos.Controls.Add(Me.Label32)
        Me.gctrlDatos.Controls.Add(Me.Label31)
        Me.gctrlDatos.Controls.Add(Me.Label16)
        Me.gctrlDatos.Controls.Add(Me.chkprovicionar)
        Me.gctrlDatos.Controls.Add(Me.txtctafondo)
        Me.gctrlDatos.Controls.Add(Me.txtctavacaciones)
        Me.gctrlDatos.Controls.Add(Me.txtctaxiv)
        Me.gctrlDatos.Controls.Add(Me.txtctaxiii)
        Me.gctrlDatos.Controls.Add(Me.txtctaaporte)
        Me.gctrlDatos.Controls.Add(Me.GroupControl2)
        Me.gctrlDatos.Controls.Add(Me.Label17)
        Me.gctrlDatos.Controls.Add(Me.PanelControl1)
        Me.gctrlDatos.Controls.Add(Me.mskFecPro)
        Me.gctrlDatos.Controls.Add(Me.chkbloqueo)
        Me.gctrlDatos.Controls.Add(Me.txtCtaComponente)
        Me.gctrlDatos.Controls.Add(Me.txtCtaSalario)
        Me.gctrlDatos.Controls.Add(Me.txtImpIva)
        Me.gctrlDatos.Controls.Add(Me.txtImpRenta)
        Me.gctrlDatos.Controls.Add(Me.txtRepresentante)
        Me.gctrlDatos.Controls.Add(Me.txtIdentificacion)
        Me.gctrlDatos.Controls.Add(Me.txtIECE)
        Me.gctrlDatos.Controls.Add(Me.txtSECAP)
        Me.gctrlDatos.Controls.Add(Me.txtAportaIess)
        Me.gctrlDatos.Controls.Add(Me.txtIESSPT)
        Me.gctrlDatos.Controls.Add(Me.txtApAdIESS)
        Me.gctrlDatos.Controls.Add(Me.txtApIESS)
        Me.gctrlDatos.Controls.Add(Me.txtTransporte)
        Me.gctrlDatos.Controls.Add(Me.txtBonificacion)
        Me.gctrlDatos.Controls.Add(Me.txtComSPIA)
        Me.gctrlDatos.Controls.Add(Me.txtSMVG)
        Me.gctrlDatos.Controls.Add(Me.txtCodAct)
        Me.gctrlDatos.Controls.Add(Me.Label26)
        Me.gctrlDatos.Controls.Add(Me.Label20)
        Me.gctrlDatos.Controls.Add(Me.Label19)
        Me.gctrlDatos.Controls.Add(Me.Label18)
        Me.gctrlDatos.Controls.Add(Me.Label15)
        Me.gctrlDatos.Controls.Add(Me.Label14)
        Me.gctrlDatos.Controls.Add(Me.Label13)
        Me.gctrlDatos.Controls.Add(Me.Label12)
        Me.gctrlDatos.Controls.Add(Me.Label11)
        Me.gctrlDatos.Controls.Add(Me.Label10)
        Me.gctrlDatos.Controls.Add(Me.Label9)
        Me.gctrlDatos.Controls.Add(Me.Label8)
        Me.gctrlDatos.Controls.Add(Me.Label7)
        Me.gctrlDatos.Controls.Add(Me.Label6)
        Me.gctrlDatos.Controls.Add(Me.Label5)
        Me.gctrlDatos.Controls.Add(Me.Label4)
        Me.gctrlDatos.Controls.Add(Me.Label3)
        Me.gctrlDatos.Controls.Add(Me.Label2)
        Me.gctrlDatos.Controls.Add(Me.Label1)
        Me.gctrlDatos.Location = New System.Drawing.Point(7, 3)
        Me.gctrlDatos.Name = "gctrlDatos"
        Me.gctrlDatos.Size = New System.Drawing.Size(688, 532)
        Me.gctrlDatos.TabIndex = 0
        Me.gctrlDatos.Text = "Datos"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(346, 69)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(106, 13)
        Me.Label42.TabIndex = 90
        Me.Label42.Text = "Porcentaje Fondo R."
        '
        'txtporfonres
        '
        Me.txtporfonres.Location = New System.Drawing.Point(534, 66)
        Me.txtporfonres.Name = "txtporfonres"
        Me.txtporfonres.Size = New System.Drawing.Size(100, 21)
        Me.txtporfonres.TabIndex = 89
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(351, 509)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(170, 13)
        Me.Label41.TabIndex = 88
        Me.Label41.Text = "Valor Maximo Sueldo Envio Correo"
        '
        'txtmaxsueldo
        '
        Me.txtmaxsueldo.Location = New System.Drawing.Point(567, 506)
        Me.txtmaxsueldo.Name = "txtmaxsueldo"
        Me.txtmaxsueldo.Size = New System.Drawing.Size(100, 21)
        Me.txtmaxsueldo.TabIndex = 87
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.chkbbloquec)
        Me.PanelControl3.Controls.Add(Me.Label40)
        Me.PanelControl3.Controls.Add(Me.cmbdefault)
        Me.PanelControl3.Location = New System.Drawing.Point(328, 198)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(322, 43)
        Me.PanelControl3.TabIndex = 86
        '
        'chkbbloquec
        '
        Me.chkbbloquec.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkbbloquec.Location = New System.Drawing.Point(16, 25)
        Me.chkbbloquec.Name = "chkbbloquec"
        Me.chkbbloquec.Size = New System.Drawing.Size(204, 17)
        Me.chkbbloquec.TabIndex = 85
        Me.chkbbloquec.Text = "Bloquear Area de Corte                                          "
        Me.chkbbloquec.UseVisualStyleBackColor = True
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(18, 6)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(72, 13)
        Me.Label40.TabIndex = 84
        Me.Label40.Text = "Default Corte"
        '
        'cmbdefault
        '
        Me.cmbdefault.FormattingEnabled = True
        Me.cmbdefault.Location = New System.Drawing.Point(206, 3)
        Me.cmbdefault.Name = "cmbdefault"
        Me.cmbdefault.Size = New System.Drawing.Size(101, 21)
        Me.cmbdefault.TabIndex = 83
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(345, 157)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(68, 13)
        Me.Label39.TabIndex = 82
        Me.Label39.Text = "% Embarazo"
        '
        'txtporemb
        '
        Me.txtporemb.Location = New System.Drawing.Point(534, 154)
        Me.txtporemb.Name = "txtporemb"
        Me.txtporemb.Size = New System.Drawing.Size(100, 21)
        Me.txtporemb.TabIndex = 81
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(548, 340)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(75, 11)
        Me.Label38.TabIndex = 80
        Me.Label38.Text = "Cont.  Beneficios"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(399, 341)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(59, 11)
        Me.Label37.TabIndex = 79
        Me.Label37.Text = "Cont. Sueldo"
        '
        'cmbcontbenef
        '
        Me.cmbcontbenef.FormattingEnabled = True
        Me.cmbcontbenef.Location = New System.Drawing.Point(546, 353)
        Me.cmbcontbenef.Name = "cmbcontbenef"
        Me.cmbcontbenef.Size = New System.Drawing.Size(134, 21)
        Me.cmbcontbenef.TabIndex = 78
        '
        'cmbcontsueldo
        '
        Me.cmbcontsueldo.FormattingEnabled = True
        Me.cmbcontsueldo.Location = New System.Drawing.Point(401, 353)
        Me.cmbcontsueldo.Name = "cmbcontsueldo"
        Me.cmbcontsueldo.Size = New System.Drawing.Size(143, 21)
        Me.cmbcontsueldo.TabIndex = 77
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(5, 443)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(30, 13)
        Me.Label36.TabIndex = 76
        Me.Label36.Text = "IECE"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(220, 414)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 13)
        Me.Label35.TabIndex = 75
        Me.Label35.Text = "SECAP"
        '
        'txtctaiece
        '
        Me.txtctaiece.Location = New System.Drawing.Point(123, 435)
        Me.txtctaiece.Name = "txtctaiece"
        Me.txtctaiece.Size = New System.Drawing.Size(91, 21)
        Me.txtctaiece.TabIndex = 74
        '
        'txtctasecap
        '
        Me.txtctasecap.Location = New System.Drawing.Point(304, 411)
        Me.txtctasecap.Name = "txtctasecap"
        Me.txtctasecap.Size = New System.Drawing.Size(91, 21)
        Me.txtctasecap.TabIndex = 73
        '
        'txtcodBanco
        '
        Me.txtcodBanco.Location = New System.Drawing.Point(534, 108)
        Me.txtcodBanco.Name = "txtcodBanco"
        Me.txtcodBanco.Size = New System.Drawing.Size(100, 21)
        Me.txtcodBanco.TabIndex = 72
        '
        'txtDiasPruebas
        '
        Me.txtDiasPruebas.Location = New System.Drawing.Point(534, 131)
        Me.txtDiasPruebas.Name = "txtDiasPruebas"
        Me.txtDiasPruebas.Size = New System.Drawing.Size(100, 21)
        Me.txtDiasPruebas.TabIndex = 71
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(5, 414)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(80, 13)
        Me.Label34.TabIndex = 70
        Me.Label34.Text = "Fondo Reserva"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(220, 391)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(60, 13)
        Me.Label33.TabIndex = 69
        Me.Label33.Text = "Vacaciones"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(6, 388)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(77, 13)
        Me.Label32.TabIndex = 68
        Me.Label32.Text = "Decimo Cuarto"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(218, 368)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(81, 13)
        Me.Label31.TabIndex = 67
        Me.Label31.Text = "Decimo Tercero"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 368)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(83, 13)
        Me.Label16.TabIndex = 66
        Me.Label16.Text = "Aporte Patronal"
        '
        'chkprovicionar
        '
        Me.chkprovicionar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkprovicionar.Enabled = False
        Me.chkprovicionar.Location = New System.Drawing.Point(579, 92)
        Me.chkprovicionar.Name = "chkprovicionar"
        Me.chkprovicionar.Size = New System.Drawing.Size(55, 17)
        Me.chkprovicionar.TabIndex = 65
        Me.chkprovicionar.Text = "Provisiones Parte del Suedo            "
        Me.chkprovicionar.UseVisualStyleBackColor = True
        Me.chkprovicionar.Visible = False
        '
        'txtctafondo
        '
        Me.txtctafondo.Location = New System.Drawing.Point(123, 411)
        Me.txtctafondo.Name = "txtctafondo"
        Me.txtctafondo.Size = New System.Drawing.Size(91, 21)
        Me.txtctafondo.TabIndex = 64
        '
        'txtctavacaciones
        '
        Me.txtctavacaciones.Location = New System.Drawing.Point(304, 388)
        Me.txtctavacaciones.Name = "txtctavacaciones"
        Me.txtctavacaciones.Size = New System.Drawing.Size(91, 21)
        Me.txtctavacaciones.TabIndex = 63
        '
        'txtctaxiv
        '
        Me.txtctaxiv.Location = New System.Drawing.Point(123, 388)
        Me.txtctaxiv.Name = "txtctaxiv"
        Me.txtctaxiv.Size = New System.Drawing.Size(91, 21)
        Me.txtctaxiv.TabIndex = 62
        '
        'txtctaxiii
        '
        Me.txtctaxiii.Location = New System.Drawing.Point(304, 365)
        Me.txtctaxiii.Name = "txtctaxiii"
        Me.txtctaxiii.Size = New System.Drawing.Size(91, 21)
        Me.txtctaxiii.TabIndex = 61
        '
        'txtctaaporte
        '
        Me.txtctaaporte.Location = New System.Drawing.Point(123, 365)
        Me.txtctaaporte.Name = "txtctaaporte"
        Me.txtctaaporte.Size = New System.Drawing.Size(91, 21)
        Me.txtctaaporte.TabIndex = 60
        '
        'GroupControl2
        '
        Me.GroupControl2.Controls.Add(Me.txtPorcentaje2)
        Me.GroupControl2.Controls.Add(Me.txtPorcentaje1)
        Me.GroupControl2.Controls.Add(Me.Label30)
        Me.GroupControl2.Controls.Add(Me.Label29)
        Me.GroupControl2.Controls.Add(Me.Label28)
        Me.GroupControl2.Controls.Add(Me.Label27)
        Me.GroupControl2.Location = New System.Drawing.Point(328, 244)
        Me.GroupControl2.Name = "GroupControl2"
        Me.GroupControl2.Size = New System.Drawing.Size(329, 70)
        Me.GroupControl2.TabIndex = 59
        Me.GroupControl2.Text = "Porcentaje de Liquidación"
        '
        'txtPorcentaje2
        '
        Me.txtPorcentaje2.Location = New System.Drawing.Point(206, 46)
        Me.txtPorcentaje2.Name = "txtPorcentaje2"
        Me.txtPorcentaje2.Size = New System.Drawing.Size(100, 21)
        Me.txtPorcentaje2.TabIndex = 59
        '
        'txtPorcentaje1
        '
        Me.txtPorcentaje1.Location = New System.Drawing.Point(206, 23)
        Me.txtPorcentaje1.Name = "txtPorcentaje1"
        Me.txtPorcentaje1.Size = New System.Drawing.Size(100, 21)
        Me.txtPorcentaje1.TabIndex = 58
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(305, 49)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(18, 13)
        Me.Label30.TabIndex = 57
        Me.Label30.Text = "%"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(306, 26)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(18, 13)
        Me.Label29.TabIndex = 56
        Me.Label29.Text = "%"
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(5, 49)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(195, 18)
        Me.Label28.TabIndex = 55
        Me.Label28.Text = "% de Liquidacion Segunda Quincena"
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(5, 26)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(195, 16)
        Me.Label27.TabIndex = 54
        Me.Label27.Text = "% de Liquidación Primera Quincena"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(345, 113)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(131, 13)
        Me.Label17.TabIndex = 57
        Me.Label17.Text = "Cód. Empresa para Banco"
        '
        'PanelControl1
        '
        Me.PanelControl1.Controls.Add(Me.txtXIV)
        Me.PanelControl1.Controls.Add(Me.Label21)
        Me.PanelControl1.Controls.Add(Me.dtpFecFXIV)
        Me.PanelControl1.Controls.Add(Me.Label25)
        Me.PanelControl1.Controls.Add(Me.dtpFecIXIV)
        Me.PanelControl1.Controls.Add(Me.Label24)
        Me.PanelControl1.Controls.Add(Me.dtpFecFXIII)
        Me.PanelControl1.Controls.Add(Me.Label23)
        Me.PanelControl1.Controls.Add(Me.dtpFecIXIII)
        Me.PanelControl1.Controls.Add(Me.Label22)
        Me.PanelControl1.Location = New System.Drawing.Point(401, 377)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(281, 125)
        Me.PanelControl1.TabIndex = 55
        '
        'txtXIV
        '
        Me.txtXIV.Location = New System.Drawing.Point(172, 3)
        Me.txtXIV.Name = "txtXIV"
        Me.txtXIV.Size = New System.Drawing.Size(100, 21)
        Me.txtXIV.TabIndex = 65
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(17, 11)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(85, 13)
        Me.Label21.TabIndex = 64
        Me.Label21.Text = "Valor XIV Sueldo"
        '
        'dtpFecFXIV
        '
        Me.dtpFecFXIV.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecFXIV.Location = New System.Drawing.Point(173, 99)
        Me.dtpFecFXIV.Name = "dtpFecFXIV"
        Me.dtpFecFXIV.Size = New System.Drawing.Size(100, 21)
        Me.dtpFecFXIV.TabIndex = 63
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 106)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(84, 13)
        Me.Label25.TabIndex = 62
        Me.Label25.Text = "Fecha Final. XVI"
        '
        'dtpFecIXIV
        '
        Me.dtpFecIXIV.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecIXIV.Location = New System.Drawing.Point(173, 76)
        Me.dtpFecIXIV.Name = "dtpFecIXIV"
        Me.dtpFecIXIV.Size = New System.Drawing.Size(100, 21)
        Me.dtpFecIXIV.TabIndex = 61
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(15, 83)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(87, 13)
        Me.Label24.TabIndex = 60
        Me.Label24.Text = "Fecha Inicio. XVI"
        '
        'dtpFecFXIII
        '
        Me.dtpFecFXIII.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecFXIII.Location = New System.Drawing.Point(173, 51)
        Me.dtpFecFXIII.Name = "dtpFecFXIII"
        Me.dtpFecFXIII.Size = New System.Drawing.Size(100, 21)
        Me.dtpFecFXIII.TabIndex = 59
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(16, 58)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(86, 13)
        Me.Label23.TabIndex = 58
        Me.Label23.Text = "Fecha Final. XIII"
        '
        'dtpFecIXIII
        '
        Me.dtpFecIXIII.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecIXIII.Location = New System.Drawing.Point(172, 27)
        Me.dtpFecIXIII.Name = "dtpFecIXIII"
        Me.dtpFecIXIII.Size = New System.Drawing.Size(100, 21)
        Me.dtpFecIXIII.TabIndex = 57
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(16, 34)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(89, 13)
        Me.Label22.TabIndex = 56
        Me.Label22.Text = "Fecha Inicio. XIII"
        '
        'mskFecPro
        '
        Me.mskFecPro.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.mskFecPro.Location = New System.Drawing.Point(175, 23)
        Me.mskFecPro.Name = "mskFecPro"
        Me.mskFecPro.Size = New System.Drawing.Size(100, 21)
        Me.mskFecPro.TabIndex = 53
        '
        'chkbloqueo
        '
        Me.chkbloqueo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkbloqueo.Location = New System.Drawing.Point(344, 91)
        Me.chkbloqueo.Name = "chkbloqueo"
        Me.chkbloqueo.Size = New System.Drawing.Size(204, 17)
        Me.chkbloqueo.TabIndex = 52
        Me.chkbloqueo.Text = "Bloquear                                            "
        Me.chkbloqueo.UseVisualStyleBackColor = True
        '
        'txtCtaComponente
        '
        Me.txtCtaComponente.Location = New System.Drawing.Point(304, 342)
        Me.txtCtaComponente.Name = "txtCtaComponente"
        Me.txtCtaComponente.Size = New System.Drawing.Size(91, 21)
        Me.txtCtaComponente.TabIndex = 45
        '
        'txtCtaSalario
        '
        Me.txtCtaSalario.Location = New System.Drawing.Point(123, 342)
        Me.txtCtaSalario.Name = "txtCtaSalario"
        Me.txtCtaSalario.Size = New System.Drawing.Size(91, 21)
        Me.txtCtaSalario.TabIndex = 44
        '
        'txtImpIva
        '
        Me.txtImpIva.Location = New System.Drawing.Point(534, 44)
        Me.txtImpIva.Name = "txtImpIva"
        Me.txtImpIva.Size = New System.Drawing.Size(100, 21)
        Me.txtImpIva.TabIndex = 43
        '
        'txtImpRenta
        '
        Me.txtImpRenta.Location = New System.Drawing.Point(534, 22)
        Me.txtImpRenta.Name = "txtImpRenta"
        Me.txtImpRenta.Size = New System.Drawing.Size(100, 21)
        Me.txtImpRenta.TabIndex = 40
        '
        'txtRepresentante
        '
        Me.txtRepresentante.Location = New System.Drawing.Point(175, 317)
        Me.txtRepresentante.Name = "txtRepresentante"
        Me.txtRepresentante.Size = New System.Drawing.Size(508, 21)
        Me.txtRepresentante.TabIndex = 39
        '
        'txtIdentificacion
        '
        Me.txtIdentificacion.Location = New System.Drawing.Point(175, 295)
        Me.txtIdentificacion.Name = "txtIdentificacion"
        Me.txtIdentificacion.Size = New System.Drawing.Size(100, 21)
        Me.txtIdentificacion.TabIndex = 38
        '
        'txtIECE
        '
        Me.txtIECE.Location = New System.Drawing.Point(175, 273)
        Me.txtIECE.Name = "txtIECE"
        Me.txtIECE.Size = New System.Drawing.Size(100, 21)
        Me.txtIECE.TabIndex = 37
        '
        'txtSECAP
        '
        Me.txtSECAP.Location = New System.Drawing.Point(175, 251)
        Me.txtSECAP.Name = "txtSECAP"
        Me.txtSECAP.Size = New System.Drawing.Size(100, 21)
        Me.txtSECAP.TabIndex = 36
        '
        'txtAportaIess
        '
        Me.txtAportaIess.Enabled = False
        Me.txtAportaIess.Location = New System.Drawing.Point(175, 229)
        Me.txtAportaIess.Name = "txtAportaIess"
        Me.txtAportaIess.Size = New System.Drawing.Size(100, 21)
        Me.txtAportaIess.TabIndex = 35
        '
        'txtIESSPT
        '
        Me.txtIESSPT.Location = New System.Drawing.Point(175, 207)
        Me.txtIESSPT.Name = "txtIESSPT"
        Me.txtIESSPT.Size = New System.Drawing.Size(100, 21)
        Me.txtIESSPT.TabIndex = 34
        '
        'txtApAdIESS
        '
        Me.txtApAdIESS.Location = New System.Drawing.Point(175, 184)
        Me.txtApAdIESS.Name = "txtApAdIESS"
        Me.txtApAdIESS.Size = New System.Drawing.Size(100, 21)
        Me.txtApAdIESS.TabIndex = 33
        '
        'txtApIESS
        '
        Me.txtApIESS.Location = New System.Drawing.Point(175, 161)
        Me.txtApIESS.Name = "txtApIESS"
        Me.txtApIESS.Size = New System.Drawing.Size(100, 21)
        Me.txtApIESS.TabIndex = 32
        '
        'txtTransporte
        '
        Me.txtTransporte.Location = New System.Drawing.Point(175, 138)
        Me.txtTransporte.Name = "txtTransporte"
        Me.txtTransporte.Size = New System.Drawing.Size(100, 21)
        Me.txtTransporte.TabIndex = 31
        '
        'txtBonificacion
        '
        Me.txtBonificacion.Location = New System.Drawing.Point(175, 115)
        Me.txtBonificacion.Name = "txtBonificacion"
        Me.txtBonificacion.Size = New System.Drawing.Size(100, 21)
        Me.txtBonificacion.TabIndex = 30
        '
        'txtComSPIA
        '
        Me.txtComSPIA.Location = New System.Drawing.Point(175, 92)
        Me.txtComSPIA.Name = "txtComSPIA"
        Me.txtComSPIA.Size = New System.Drawing.Size(100, 21)
        Me.txtComSPIA.TabIndex = 29
        '
        'txtSMVG
        '
        Me.txtSMVG.Location = New System.Drawing.Point(175, 69)
        Me.txtSMVG.Name = "txtSMVG"
        Me.txtSMVG.Size = New System.Drawing.Size(100, 21)
        Me.txtSMVG.TabIndex = 28
        '
        'txtCodAct
        '
        Me.txtCodAct.Location = New System.Drawing.Point(175, 46)
        Me.txtCodAct.Name = "txtCodAct"
        Me.txtCodAct.Size = New System.Drawing.Size(100, 21)
        Me.txtCodAct.TabIndex = 27
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(345, 137)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(69, 13)
        Me.Label26.TabIndex = 25
        Me.Label26.Text = "Dias Pruebas"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(218, 345)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(83, 13)
        Me.Label20.TabIndex = 19
        Me.Label20.Text = "Cta. Cble Cotes"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(3, 342)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(114, 13)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "Cta. Contable Salarios"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(342, 47)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(116, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Porcentaje Imp. I.V.A."
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(342, 25)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(144, 13)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "% Ret. I. Renta Menor Base"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 320)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(133, 13)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "Nombre del representante"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 298)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(158, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Identificación de representante"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(3, 276)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(121, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Porcentaje Aporte IECE"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(3, 254)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(130, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Porcentaje Aporte SECAP"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Enabled = False
        Me.Label10.Location = New System.Drawing.Point(3, 232)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(168, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "La Empresa asume el Aporte IESS"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 210)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(163, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Porcentaje Aporte Patronal IESS"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 187)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(151, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Porcentaje Aporte al IESS Ad."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 164)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(131, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Porcentaje Aporte al IESS"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 141)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(139, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Componente de Transporte"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 118)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Porcentaje de Bonificación"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 95)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Componente Salarial"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Salario mínimo vital"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(146, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Código de Actividad de la Cia"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(159, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha de proceso de liquidación"
        '
        'GroupControl1
        '
        Me.GroupControl1.Controls.Add(Me.pnlfondo)
        Me.GroupControl1.Controls.Add(Me.lblcompania)
        Me.GroupControl1.Controls.Add(Me.cmbcompania)
        Me.GroupControl1.Controls.Add(Me.PanelControl2)
        Me.GroupControl1.Location = New System.Drawing.Point(0, 27)
        Me.GroupControl1.Name = "GroupControl1"
        Me.GroupControl1.Size = New System.Drawing.Size(706, 594)
        Me.GroupControl1.TabIndex = 3
        Me.GroupControl1.Text = "Parametros "
        '
        'lblcompania
        '
        Me.lblcompania.Location = New System.Drawing.Point(28, 26)
        Me.lblcompania.Name = "lblcompania"
        Me.lblcompania.Size = New System.Drawing.Size(47, 13)
        Me.lblcompania.TabIndex = 5
        Me.lblcompania.Text = "Compañia"
        '
        'cmbcompania
        '
        Me.cmbcompania.Location = New System.Drawing.Point(87, 23)
        Me.cmbcompania.Name = "cmbcompania"
        Me.cmbcompania.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cmbcompania.Properties.View = Me.GridLookUpEdit1View
        Me.cmbcompania.Size = New System.Drawing.Size(597, 20)
        Me.cmbcompania.TabIndex = 4
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.pnlfrente)
        Me.PanelControl2.Location = New System.Drawing.Point(4, 49)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(699, 540)
        Me.PanelControl2.TabIndex = 3
        '
        'cbotomacarga
        '
        Me.cbotomacarga.FormattingEnabled = True
        Me.cbotomacarga.Location = New System.Drawing.Point(123, 462)
        Me.cbotomacarga.Name = "cbotomacarga"
        Me.cbotomacarga.Size = New System.Drawing.Size(232, 21)
        Me.cbotomacarga.TabIndex = 92
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(5, 465)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(83, 13)
        Me.Label43.TabIndex = 91
        Me.Label43.Text = "IR. Toma Carga"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(708, 623)
        Me.Controls.Add(Me.GroupControl1)
        Me.Controls.Add(Me.mnsForma)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mantenimiento de parámetros"
        Me.mnsForma.ResumeLayout(False)
        Me.mnsForma.PerformLayout()
        Me.pnlfrente.ResumeLayout(False)
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfondo.ResumeLayout(False)
        Me.pnlfondo.PerformLayout()
        CType(Me.gctrlDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gctrlDatos.ResumeLayout(False)
        Me.gctrlDatos.PerformLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        Me.PanelControl3.PerformLayout()
        CType(Me.GroupControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl2.ResumeLayout(False)
        Me.GroupControl2.PerformLayout()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        Me.PanelControl1.PerformLayout()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl1.ResumeLayout(False)
        Me.GroupControl1.PerformLayout()
        CType(Me.cmbcompania.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnsForma As System.Windows.Forms.MenuStrip
    Friend WithEvents mnunuevo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnumodificar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuconsultar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnugrabar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnucancelar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnusalir As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlfrente As System.Windows.Forms.Panel
    Friend WithEvents pnlfondo As System.Windows.Forms.Panel
    Friend WithEvents gctrlDatos As DevExpress.XtraEditors.GroupControl
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtCtaComponente As System.Windows.Forms.TextBox
    Friend WithEvents txtCtaSalario As System.Windows.Forms.TextBox
    Friend WithEvents txtImpIva As System.Windows.Forms.TextBox
    Friend WithEvents txtImpRenta As System.Windows.Forms.TextBox
    Friend WithEvents txtRepresentante As System.Windows.Forms.TextBox
    Friend WithEvents txtIdentificacion As System.Windows.Forms.TextBox
    Friend WithEvents txtIECE As System.Windows.Forms.TextBox
    Friend WithEvents txtSECAP As System.Windows.Forms.TextBox
    Friend WithEvents txtAportaIess As System.Windows.Forms.TextBox
    Friend WithEvents txtIESSPT As System.Windows.Forms.TextBox
    Friend WithEvents txtApAdIESS As System.Windows.Forms.TextBox
    Friend WithEvents txtApIESS As System.Windows.Forms.TextBox
    Friend WithEvents txtTransporte As System.Windows.Forms.TextBox
    Friend WithEvents txtBonificacion As System.Windows.Forms.TextBox
    Friend WithEvents txtComSPIA As System.Windows.Forms.TextBox
    Friend WithEvents txtSMVG As System.Windows.Forms.TextBox
    Friend WithEvents txtCodAct As System.Windows.Forms.TextBox
    Friend WithEvents chkbloqueo As System.Windows.Forms.CheckBox
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents mskFecPro As System.Windows.Forms.DateTimePicker
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents dtpFecFXIV As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents dtpFecIXIV As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents dtpFecFXIII As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents dtpFecIXIII As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtXIV As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents GroupControl1 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents lblcompania As DevExpress.XtraEditors.LabelControl
    Friend WithEvents cmbcompania As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GroupControl2 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtctafondo As System.Windows.Forms.TextBox
    Friend WithEvents txtctavacaciones As System.Windows.Forms.TextBox
    Friend WithEvents txtctaxiv As System.Windows.Forms.TextBox
    Friend WithEvents txtctaxiii As System.Windows.Forms.TextBox
    Friend WithEvents txtctaaporte As System.Windows.Forms.TextBox
    Friend WithEvents chkprovicionar As System.Windows.Forms.CheckBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtDiasPruebas As System.Windows.Forms.TextBox
    Friend WithEvents txtPorcentaje2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPorcentaje1 As System.Windows.Forms.TextBox
    Friend WithEvents txtcodBanco As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtctaiece As System.Windows.Forms.TextBox
    Friend WithEvents txtctasecap As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents cmbcontbenef As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcontsueldo As System.Windows.Forms.ComboBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtporemb As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents cmbdefault As System.Windows.Forms.ComboBox
    Friend WithEvents chkbbloquec As System.Windows.Forms.CheckBox
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtmaxsueldo As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtporfonres As System.Windows.Forms.TextBox
    Friend WithEvents cbotomacarga As System.Windows.Forms.ComboBox
    Friend WithEvents Label43 As System.Windows.Forms.Label

End Class
