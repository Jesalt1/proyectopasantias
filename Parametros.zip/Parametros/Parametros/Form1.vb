﻿Imports libreria
Imports DevExpress.XtraEditors
Imports System.Data.SqlClient
Imports System.Data.Sql

Public Class Form1
    Dim scommand As String
    Dim Tabla As New DataTable("tabla")
    Dim max_compania As Integer
    Public validar_fecha As Date

    Sub table()
        Tabla.Columns.Clear()
        Tabla.Rows.Clear()
        Tabla.Columns.Add(New DataColumn("Compañia", GetType(Integer)))
        Tabla.Columns.Add(New DataColumn("Fecha Proceso Liq.", GetType(Date)))
        Tabla.Columns.Add(New DataColumn("Salario Minimo Vital", GetType(Decimal)))
        Tabla.Columns.Add(New DataColumn("Comp. Salarial", GetType(Decimal)))
        Tabla.Columns.Add(New DataColumn("% Bonificacion", GetType(Decimal)))
        Tabla.Columns.Add(New DataColumn("Comp. de Transporte", GetType(Decimal)))
        Tabla.Columns.Add(New DataColumn("% Aportacion IESS", GetType(Decimal)))
        Tabla.Columns.Add(New DataColumn("% Aportacion Patronal IESS", GetType(Decimal)))

        GridView1.Columns.Clear()
        GridView1.OptionsView.ColumnAutoWidth = False
        GridView1.OptionsPrint.AutoWidth = False
        GridView1.BestFitColumns()
        'GridView1.OptionsView.ColumnAutoWidth = False
        GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
        GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
        GridControl1.DataSource = Nothing
        'GridControl1.Dispose()
        'GridControl1 = New DevExpress.XtraGrid.GridControl

        GridView1.OptionsView.ShowGroupPanel = False
        GridControl1.DataSource = Tabla
        GridView1.Columns("Compañia").Width = 80
        GridView1.Columns("Fecha Proceso Liq.").Width = 120
        GridView1.Columns("Salario Minimo Vital").Width = 110
        GridView1.Columns("Comp. Salarial").Width = 100
        GridView1.Columns("% Bonificacion").Width = 100
        GridView1.Columns("Comp. de Transporte").Width = 100
        GridView1.Columns("% Aportacion IESS").Width = 100
        GridView1.Columns("% Aportacion Patronal IESS").Width = 120
    End Sub
    Sub New()
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        scommand = Microsoft.VisualBasic.Interaction.Command()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub
    Sub New(ByVal iscommand As String)
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        scommand = iscommand
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try            
            If Load_Siac(Me, "ROLES", scommand) = False Then Me.Dispose()
            llenar_compania()
            If max_compania > 0 Then
                cmbcompania.EditValue = cmbcompania.Properties.GetKeyValue(0)
                sgCompaniaForm = sgCompania

                If mostrar_empresa() = "N" Then
                    lblcompania.Enabled = False
                    lblcompania.Visible = False
                    cmbcompania.Enabled = False
                    cmbcompania.Visible = False
                Else
                    lblcompania.Enabled = True
                    lblcompania.Visible = True
                    cmbcompania.Enabled = True
                    cmbcompania.Visible = True

                End If
            End If
            sgMaquina = My.Computer.Name
            seteo_boton(False)
            table()
            load_contenido()
            Call llenar_combo()
        Catch ex As Exception
            XtraMessageBox.Show("Error.. " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Sub load_contenido()
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        Dim gconextion As gConnectionSql.gConnection
        Try
            gconextion = New gConnectionSql.gConnection
            oCon = Nothing
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            Call table()
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub

            oComand = New SqlCommand
            With oComand
                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "consultar")
                .Parameters.AddWithValue("@NT08CODCIA", sgCompaniaForm)

            End With
            oRs = oComand.ExecuteReader()
            While oRs.Read
                Tabla.Rows.Add(oRs.Item("NT08CODCIA"), oRs.Item("TT08FECPRO"), oRs.Item("NT08SALMVG"), oRs.Item("NT08CMSPIA"), oRs.Item("NT08BONIFI"), oRs.Item("NT08TRANSP"), oRs.Item("NT08APIESS"), oRs.Item("NT08IESSPT"))
            End While

            GridView1.Columns("Compañia").OptionsColumn.AllowEdit = False
            GridView1.Columns("Fecha Proceso Liq.").OptionsColumn.AllowEdit = False
            GridView1.Columns("Salario Minimo Vital").OptionsColumn.AllowEdit = False
            GridView1.Columns("Comp. Salarial").OptionsColumn.AllowEdit = False
            GridView1.Columns("% Bonificacion").OptionsColumn.AllowEdit = False
            GridView1.Columns("Comp. de Transporte").OptionsColumn.AllowEdit = False
            GridView1.Columns("% Aportacion IESS").OptionsColumn.AllowEdit = False
            GridView1.Columns("% Aportacion Patronal IESS").OptionsColumn.AllowEdit = False

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            oRs.Close()           
            oRs = Nothing            
        Catch ex As Exception
            XtraMessageBox.Show("Error : " & ex.Message, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oComand = Nothing
        End Try
    End Sub

    Sub seteo_boton(ByVal opcion As Boolean)
        mnunuevo.Enabled = Not opcion
        mnumodificar.Enabled = Not opcion
        mnuconsultar.Enabled = Not opcion
        mnugrabar.Enabled = opcion
        mnucancelar.Enabled = opcion
        pnlfondo.Enabled = opcion
        pnlfondo.Visible = opcion        
        pnlfrente.Enabled = Not opcion
        pnlfrente.Visible = Not opcion
        gctrlDatos.Enabled = opcion
        gctrlDatos.Visible = opcion
        cmbcompania.Enabled = Not opcion
        'PanelControl2.Enabled = Not opcion
        'PanelControl2.Visible = Not opcion
    End Sub

    Private Sub mnunuevo_Click(sender As Object, e As EventArgs) Handles mnunuevo.Click
        igaccion = 1
        libreria.limpiar_formas(Me.gctrlDatos)
        seteo_boton(True)
        Habilitar(False)

        'If mskFecPro.Text.Trim = "" Then
        '    mskFecPro.Text = "____-__-__"
        'Else
        '    mskFecPro.Text = txtFecPro.Text
        'End If

        mskFecPro.Visible = True
        'txtFecPro.Visible = False
        Me.mskFecPro.Focus()
    End Sub

    Sub Habilitar(Flag As Boolean)
        'txtSMVG.Locked = Flag
        'txtComSPIA.Locked = Flag
        'txtBonificacion.Locked = Flag
        'txtTransporte.Locked = Flag
        'txtApIESS.Locked = Flag
        'txtIESSPT.Locked = Flag
        'txtCodAct.Locked = Flag
        'txtSECAP.Locked = Flag
        'txtIECE.Locked = Flag
        'txtIdentificacion.Locked = Flag
        'txtRepresentante.Locked = Flag
        'txtAportaIess.Locked = Flag
        'txtImpRenta.Locked = Flag
        'txtCtaSalario.Locked = Flag
        'txtCtaComponente.Locked = Flag
        'txtImpIva.Locked = False
        'txtImpRenta2.Locked = Flag
        'txtBaseTope.Locked = Flag
        'txtApAdIESS.Locked = Flag
        'txtXIV.Locked = Flag
        dtpFecFXIII.Enabled = Not (Flag)
        dtpFecFXIV.Enabled = Not (Flag)
        dtpFecIXIII.Enabled = Not (Flag)
        dtpFecIXIV.Enabled = Not (Flag)
        chkbloqueo.Enabled = Not (Flag)
        'txtDiasPruebas.Locked = Flag
    End Sub
    Private Sub mnugrabar_Click(sender As Object, e As EventArgs) Handles mnugrabar.Click
        Dim lwiaceptar As Integer
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        Dim ocomand As SqlCommand, items0 As ClsItemsData, items1 As ClsItemsData
        Dim connection As New gConnectionSql.gConnection
        Dim audxml As New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
        oCon = Nothing
        Dim verificar As Boolean, ierror As Integer, smensaje As String
        If Not connection.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
        ocomand = New SqlCommand

        Try
            If Validar() = False Then Exit Sub
            '  If mskFecPro.Value.Date = validar_fecha Then Exit Sub
            verificar = False
            'If mskFecPro.Value.Date <> validar_fecha Then
            Dim dxmla As New XElement("AUDITORIA")
            Dim cxmla As New XElement("PARAMETROS")
            cxmla.Add(New XAttribute("compania", sgCompania))
            cxmla.Add(New XAttribute("ejecutable", My.Application.Info.AssemblyName))
            cxmla.Add(New XAttribute("usuario", sgUsuario))
            cxmla.Add(New XAttribute("maquina", sgMaquina))
            dxmla.Add(cxmla)
            audxml.Add(dxmla)

            'If accion = 1 Then
            '    empleado = 0
            '    sopcion = "insert"
            'Else
            '    empleado = txtcodigo.Text
            '    sopcion = "update"
            'End If

            With ocomand
                .CommandTimeout = 0
                .CommandType = CommandType.StoredProcedure
                .CommandText = "spRol_Verificar_Cierre_Rol"
                .Connection = oCon
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                .Parameters.AddWithValue("@i_fecha", validar_fecha)
                '.Parameters.AddWithValue("@i_xml_aud", audxml.ToString)
                .Parameters.Add("@o_error", SqlDbType.Int)
                .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 8000)
                .Parameters("@o_error").Direction = ParameterDirection.Output
                .Parameters("@o_mensaje").Direction = ParameterDirection.Output
            End With
            ocomand.ExecuteScalar()
            ierror = ocomand.Parameters("@o_error").Value
            smensaje = ocomand.Parameters("@o_mensaje").Value

            ocomand = Nothing

            If ierror = 1 Then
                'XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                lwiaceptar = XtraMessageBox.Show("El periodo anterior no ha sido cerrado. ¿Desea Modificar la fecha?... ", NOMBRE_SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If lwiaceptar = 7 Then
                    Exit Sub
                End If
            End If

            'oRs = ocomand.ExecuteReader
            'If oRs.HasRows = True Then
            '    verificar = True
            'Else
            '    verificar = False
            'End If
            'oRs.Close()
            'oRs = Nothing
            'If verificar = False Then
            '    lwiaceptar = XtraMessageBox.Show("El periodo anterior no ha sido cerrado. ¿Desea Modificar la fecha?... ", NOMBRE_SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            '    If lwiaceptar = 7 Then
            '        Exit Sub
            '    End If
            'End If
            items0 = cmbcontsueldo.Items(cmbcontsueldo.SelectedIndex)
            items1 = cmbcontbenef.Items(cmbcontbenef.SelectedIndex)
            ocomand = New SqlCommand

            With ocomand
                .CommandTimeout = 0
                .CommandType = CommandType.StoredProcedure
                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .Parameters.AddWithValue("@i_operacion", "update")
                .Parameters.AddWithValue("@NT08CODCIA", sgCompaniaForm)
                .Parameters.AddWithValue("@TT08FECPRO", Me.mskFecPro.Value.Date)
                .Parameters.AddWithValue("@NT08SALMVG", Me.txtSMVG.Text)
                .Parameters.AddWithValue("@NT08CMSPIA", Me.txtComSPIA.Text)
                .Parameters.AddWithValue("@NT08TRANSP", Me.txtTransporte.Text)
                .Parameters.AddWithValue("@NT08BONIFI", Me.txtBonificacion.Text)
                .Parameters.AddWithValue("@NT08APIESS", Me.txtApIESS.Text)
                .Parameters.AddWithValue("@NT08IESSPT", Me.txtIESSPT.Text)
                .Parameters.AddWithValue("@NT08ASECAP", Me.txtSECAP.Text)
                .Parameters.AddWithValue("@NT08APIECE", Me.txtIECE.Text)
                .Parameters.AddWithValue("@CT08CODACT", Me.txtCodAct.Text)
                .Parameters.AddWithValue("@CT08IDENTI", Me.txtIdentificacion.Text.Trim)
                .Parameters.AddWithValue("@CT08REPRES", Me.txtRepresentante.Text.Trim)
                .Parameters.AddWithValue("@CT08ASUMEIESS", Me.txtAportaIess.Text)
                .Parameters.AddWithValue("@NT08PORRETEN", Me.txtImpRenta.Text)
                .Parameters.AddWithValue("@NT08PORIVA", Me.txtImpIva.Text)
                .Parameters.AddWithValue("@NT08XIV", Me.txtXIV.Text)
                .Parameters.AddWithValue("@NT08CTASALARIO", Me.txtCtaSalario.Text)
                .Parameters.AddWithValue("@NT08CTACOMPONENTE", Me.txtCtaComponente.Text)
                .Parameters.AddWithValue("@NT08FECHAIXIV", Me.dtpFecIXIV.Value.Date)
                .Parameters.AddWithValue("@NT08FECHAFXIV", Me.dtpFecFXIV.Value.Date)
                .Parameters.AddWithValue("@NT08FECHAIXIII", Me.dtpFecIXIII.Value.Date)
                .Parameters.AddWithValue("@NT08FECHAFXIII", Me.dtpFecFXIII.Value.Date)
                .Parameters.AddWithValue("@NT08APADIESS", Me.txtApAdIESS.Text)
                .Parameters.AddWithValue("@NT08DIASPRUEBA", Me.txtDiasPruebas.Text)
                .Parameters.AddWithValue("@NT08Usuario", sgUsuario)
                .Parameters.AddWithValue("@NT08BLOQUEO", IIf(Me.chkbloqueo.Checked = True, 1, 0))
                .Parameters.AddWithValue("@NT08IESSPAT", txtctaaporte.Text)

                .Parameters.AddWithValue("@NT08DEC3", txtctaxiii.Text)
                .Parameters.AddWithValue("@NT08DEC4", txtctaxiv.Text)
                .Parameters.AddWithValue("@NT08VAC", txtctavacaciones.Text)
                .Parameters.AddWithValue("@NT08RESERVA", txtctafondo.Text)
                .Parameters.AddWithValue("@NTPORRESERVA", txtporfonres.Text)

                .Parameters.AddWithValue("@NT08PROVSUEL", IIf(chkprovicionar.Checked = True, "S", "N"))
                .Parameters.AddWithValue("@NT08VALORBANCO", txtcodBanco.Text)
                .Parameters.AddWithValue("@NT08PORC1", txtPorcentaje1.Text)
                .Parameters.AddWithValue("@NT08PORC2", txtPorcentaje2.Text)
                .Parameters.AddWithValue("@NT08CTASECAP", txtctasecap.Text)
                .Parameters.AddWithValue("@NT08CTAIECE", txtctaiece.Text)
                .Parameters.AddWithValue("@NT08CONTSUELDO", items0.Generacion)
                .Parameters.AddWithValue("@NT08CONTBENE", items1.Generacion)
                .Parameters.AddWithValue("@NT08POREMB", txtporemb.Text)
                .Parameters.AddWithValue("@NT08DEFAULTCORTE", CType(cmbdefault.Items(cmbdefault.SelectedIndex), ClsItemsData).ItemData)
                .Parameters.AddWithValue("@NT08BLOQCORTE", IIf(chkbbloquec.Checked = True, "S", "N"))
                .Parameters.AddWithValue("@NT08MAXSUELDO", CDbl(txtmaxsueldo.Text))
                .Parameters.AddWithValue("@NT08CARGAIMP", CType(cbotomacarga.Items(cbotomacarga.SelectedIndex), ClsItemsData).ItemData)
                .Parameters.AddWithValue("@i_xml_aud", audxml.ToString)
                .Parameters.Add("@o_error", SqlDbType.Int)
                .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 8000)
                .Parameters("@o_error").Direction = ParameterDirection.Output
                .Parameters("@o_mensaje").Direction = ParameterDirection.Output

            End With

            ocomand.ExecuteScalar()
            ierror = ocomand.Parameters("@o_error").Value
            smensaje = ocomand.Parameters("@o_mensaje").Value
            XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            ocomand = Nothing
            oCon.Close()
            oCon = Nothing
          
            If ierror = 0 Then
                mnucancelar.PerformClick()
            End If





        Catch ex As Exception
            XtraMessageBox.Show("Error en el método de grabado: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)

            'If oCon.State = ConnectionState.Open Then
            '    oCon.Close()
            'End If
            'ocomand = Nothing
        End Try
    End Sub

    Function Validar() As Boolean
        Validar = True

        If Not IsDate(mskFecPro.Text) Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)            
            mskFecPro.Focus()
            Validar = False
            Exit Function
        End If

        If txtSMVG.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSMVG.Focus()
            Validar = False
            Exit Function
        End If

        If txtComSPIA.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtComSPIA.Focus()
            Validar = False
            Exit Function
        End If

        If txtBonificacion.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtBonificacion.Focus()
            Validar = False
            Exit Function
        End If

        If txtTransporte.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtTransporte.Focus()
            Validar = False
            Exit Function
        End If

        If txtApIESS.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtApIESS.Focus()
            Validar = False
            Exit Function
        End If

        If txtIESSPT.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtIESSPT.Focus()
            Validar = False
            Exit Function
        End If

        If txtSECAP.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSECAP.Focus()
            Validar = False
            Exit Function
        End If

        If txtIECE.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtIECE.Focus()
            Validar = False
            Exit Function
        End If

        If txtCodAct.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtCodAct.Focus()
            Validar = False
            Exit Function
        End If

        If txtIdentificacion.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtIdentificacion.Focus()
            Validar = False
            Exit Function
        End If

        If txtRepresentante.Text.Trim = "" Then
            XtraMessageBox.Show("Información requerida", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtRepresentante.Focus()
            Validar = False
            Exit Function
        End If
    End Function

    Sub seleccionar(Optional ByVal simensaje As String = "")
        Try
            If Tabla.Rows.Count > 0 Then
                pwinumero = GridView1.GetFocusedRowCellValue("Compañia")
            Else
                XtraMessageBox.Show("Escoja el registro a " + simensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            XtraMessageBox.Show("error.. " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Function load_registro(ByVal siclave As Double) As Boolean
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader = Nothing

        load_registro = False

        Dim connection As New gConnectionSql.gConnection
        oCon = Nothing
        If Not connection.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Function
        Try
            oComand = New SqlCommand
            With oComand

                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "consultar")            
                .Parameters.AddWithValue("@NT08CODCIA", siclave)
            End With
            oRs = oComand.ExecuteReader()
            If oRs.Read Then
                Me.mskFecPro.Value = oRs.Item("TT08FECPRO")
                Me.txtCodAct.Text = oRs.Item("CT08CODACT")
                Me.txtSMVG.Text = oRs.Item("NT08SALMVG")
                Me.txtComSPIA.Text = oRs.Item("NT08CMSPIA")
                Me.txtBonificacion.Text = oRs.Item("NT08BONIFI")
                Me.txtTransporte.Text = oRs.Item("NT08TRANSP")
                Me.txtApIESS.Text = oRs.Item("NT08APIESS")
                Me.txtApAdIESS.Text = IIf(IsDBNull(oRs.Item("NT08APADIESS")) = True, 0, oRs.Item("NT08APADIESS"))
                Me.txtIESSPT.Text = oRs.Item("NT08IESSPT")
                Me.txtAportaIess.Text = oRs.Item("CT08ASUMEIESS")
                Me.txtSECAP.Text = oRs.Item("NT08ASECAP")
                Me.txtIECE.Text = oRs.Item("NT08APIECE")
                Me.txtIdentificacion.Text = oRs.Item("CT08IDENTI")
                Me.txtRepresentante.Text = oRs.Item("CT08REPRES")
                Me.txtImpRenta.Text = oRs.Item("NT08PORRETEN")
                Me.txtImpIva.Text = oRs.Item("NT08PORIVA")
                Me.txtCtaSalario.Text = oRs.Item("NT08CTASALARIO")
                Me.txtCtaComponente.Text = oRs.Item("NT08CTACOMPONENTE")
                Me.txtXIV.Text = oRs.Item("NT08XIV")
                Me.dtpFecIXIII.Value = oRs.Item("NT08FECHAIXIII")
                Me.dtpFecFXIII.Value = oRs.Item("NT08FECHAFXIII")
                Me.dtpFecIXIV.Value = oRs.Item("NT08FECHAIXIV")
                Me.dtpFecFXIV.Value = oRs.Item("NT08FECHAFXIV")
                Me.txtDiasPruebas.Text = IIf(IsDBNull(oRs.Item("NT08DIASPRUEBA")) = True, 0, oRs.Item("NT08DIASPRUEBA"))
                Me.chkbloqueo.Checked = IIf(IIf(IsDBNull(oRs.Item("NT08BLOQUEO")), 0, oRs.Item("NT08BLOQUEO")) = 1, True, False)
                txtctaaporte.Text = oRs.Item("NT08IESSPAT")
                txtctaxiii.Text = oRs.Item("NT08DEC3")
                txtctaxiv.Text = oRs.Item("NT08DEC4")
                txtctavacaciones.Text = oRs.Item("NT08VAC")
                txtctafondo.Text = oRs.Item("NT08RESERVA")
                chkprovicionar.Checked = IIf(oRs.Item("NT08VAC") = "S", True, False)
                txtctaaporte.Text = oRs.Item("NT08IESSPAT")
                txtPorcentaje1.Text = oRs.Item("NT08PORC1")
                txtPorcentaje2.Text = oRs.Item("NT08PORC2")
                txtcodBanco.Text = oRs.Item("NT08VALORBANCO")
                txtctasecap.Text = oRs.Item("NT08CTASECAP")
                txtctaiece.Text = oRs.Item("NT08CTAIECE")
                txtporemb.Text = oRs.Item("NT08POREMB")
                txtmaxsueldo.Text = oRs.Item("NT08MAXSUELDO")
                Select Case oRs.Item("NT08CONTSUELDO")
                    Case "Q"
                        cmbcontsueldo.SelectedIndex = 0
                    Case "M"
                        cmbcontsueldo.SelectedIndex = 1
                End Select
                Select Case oRs.Item("NT08CONTBENE")
                    Case "Q"
                        cmbcontbenef.SelectedIndex = 0
                    Case "M"
                        cmbcontbenef.SelectedIndex = 1
                End Select
                Call ubicar_combo(cmbdefault, oRs.Item("NT08DEFAULTCORTE"))
                chkbbloquec.Checked = IIf(oRs.Item("NT08BLOQCORTE") = "S", True, False)
                txtporfonres.Text = oRs.Item("NTPORRESERVA")
                Call ubicar_combo(cbotomacarga, oRs.Item("NT08CARGAIMP"))
                load_registro = True

            End If
            oRs.Close()
            oRs = Nothing            

        Catch ex As Exception
            XtraMessageBox.Show("error.. " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oComand = Nothing
        End Try
    End Function

    Private Sub mnucancelar_Click(sender As Object, e As EventArgs) Handles mnucancelar.Click
        igaccion = 1
        seteo_boton(False)
        Call load_contenido()
    End Sub

    Private Sub mnusalir_Click(sender As Object, e As EventArgs) Handles mnusalir.Click
        Me.Dispose()
    End Sub

    Private Sub mnumodificar_Click(sender As Object, e As EventArgs) Handles mnumodificar.Click
        Try
            igaccion = 2
            Call seleccionar("Modificar")
            If pwinumero = Nothing Then Exit Sub
            limpiar_formas(Me.gctrlDatos)
            If load_registro(pwinumero) = False Then Exit Sub
            seteo_boton(True)
            validar_fecha = mskFecPro.Value.Date
        Catch ex As Exception
            XtraMessageBox.Show("error.. " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub mnuconsultar_Click(sender As Object, e As EventArgs) Handles mnuconsultar.Click
        Try
            igaccion = 2
            Call seleccionar("Modificar")
            If pwinumero = Nothing Then Exit Sub
            limpiar_formas(Me.gctrlDatos)
            If load_registro(pwinumero) = False Then Exit Sub
            seteo_boton(True)

            Me.gctrlDatos.Enabled = False
            Me.mnugrabar.Enabled = False
        Catch ex As Exception
            XtraMessageBox.Show("error.. " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
  

    Private Sub cmbcompania_EditValueChanged(sender As Object, e As EventArgs) Handles cmbcompania.EditValueChanged
        sgCompaniaForm = cmbcompania.EditValue
        load_contenido()
    End Sub
    Private Sub llenar_combo()


        Try
            cmbcontsueldo.Items.Clear()
            cmbcontbenef.Items.Clear()
            cmbcontsueldo.Items.Add(New ClsItemsData("Quincenal", 0, "Q"))
            cmbcontsueldo.Items.Add(New ClsItemsData("Mensual", 1, "M"))



            cmbcontsueldo.SelectedIndex = IIf(cmbcontsueldo.Items.Count > 0, 0, -1)
            cmbcontsueldo.AutoCompleteSource = AutoCompleteSource.ListItems
            cmbcontsueldo.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            cmbcontsueldo.DropDownStyle = ComboBoxStyle.DropDownList

            cmbcontbenef.Items.Add(New ClsItemsData("Quincenal", 0, "Q"))
            cmbcontbenef.Items.Add(New ClsItemsData("Mensual", 1, "M"))

            cmbcontbenef.SelectedIndex = IIf(cmbcontsueldo.Items.Count > 0, 0, -1)
            cmbcontbenef.AutoCompleteSource = AutoCompleteSource.ListItems
            cmbcontbenef.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            cmbcontbenef.DropDownStyle = ComboBoxStyle.DropDownList

            cmbdefault.Items.Clear()
            cmbdefault.Items.Add(New ClsItemsData("SEMANAL", 1))
            cmbdefault.Items.Add(New ClsItemsData("QUINCENAL", 2))
            cmbdefault.Items.Add(New ClsItemsData("MENSUAL", 3))



            cmbdefault.SelectedIndex = IIf(cmbdefault.Items.Count > 0, 0, -1)
            cmbdefault.AutoCompleteSource = AutoCompleteSource.ListItems
            cmbdefault.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            cmbdefault.DropDownStyle = ComboBoxStyle.DropDownList

            cbotomacarga.Items.Add(New ClsItemsData("Carga de Empleado", 1))
            cbotomacarga.Items.Add(New ClsItemsData("Formulario Gastos", 2))

            cbotomacarga.SelectedIndex = IIf(cmbcontsueldo.Items.Count > 0, 0, -1)
            cbotomacarga.AutoCompleteSource = AutoCompleteSource.ListItems
            cbotomacarga.AutoCompleteMode = AutoCompleteMode.SuggestAppend
            cbotomacarga.DropDownStyle = ComboBoxStyle.DropDownList

        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#Region "FUNCIONES Y PROCEDIMIENTOS BASICOS"
    Private Sub llenar_compania()

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim dt As New DataSet
        Dim dtadap As SqlDataAdapter

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                '.CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Compania"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "query_empresa")
            End With


            dtadap = New SqlDataAdapter(oComand)
            dtadap.Fill(dt)
            max_compania = dt.Tables(0).Rows.Count
            'max_compania = max_compania - 1
            ' llenacompania = False
            cmbcompania.Properties.DataSource = dt.Tables(0)
            cmbcompania.Properties.DisplayMember = "Nombre"
            cmbcompania.Properties.ValueMember = "Codigo"
            ' llenacompania = True
            oComand = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Function mostrar_empresa() As String

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim oRs As SqlDataReader

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        mostrar_empresa = "N"
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbase, sguser, sgpw, oCon) = False Then Exit Function
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "PARMSp_Mant_Parametro_General"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "mos_emp")

            End With
            oRs = oComand.ExecuteReader()
            If oRs.HasRows = True Then
                If oRs.Read Then

                    mostrar_empresa = oRs.Item("mostrar_empresa")
                End If
            End If

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

#End Region

    Private Sub mnsForma_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles mnsForma.ItemClicked

    End Sub

    Private Sub Label27_Click(sender As Object, e As EventArgs) Handles Label27.Click

    End Sub

    Private Sub txtPorcentaje1_TextChanged(sender As Object, e As EventArgs) Handles txtPorcentaje1.TextChanged

    End Sub

    Private Sub txtImpIva_TextChanged(sender As Object, e As EventArgs) Handles txtImpIva.TextChanged

    End Sub

    Private Sub txtmaxsueldo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtmaxsueldo.KeyPress
        Numeros_Decimal(e)
    End Sub

    Private Sub txtmaxsueldo_TextChanged(sender As Object, e As EventArgs) Handles txtmaxsueldo.TextChanged

    End Sub

    Private Sub Label16_Click(sender As Object, e As EventArgs) Handles Label16.Click

    End Sub

    Private Sub txtctasecap_TextChanged(sender As Object, e As EventArgs) Handles txtctasecap.TextChanged

    End Sub
End Class

