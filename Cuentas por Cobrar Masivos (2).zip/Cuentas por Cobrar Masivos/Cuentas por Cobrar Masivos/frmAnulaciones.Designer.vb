﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAnulaciones
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelTop = New DevExpress.XtraEditors.PanelControl()
        Me.DgvPanel1 = New DevExpress.XtraEditors.PanelControl()
        Me.BotPanel = New DevExpress.XtraEditors.PanelControl()
        Me.CabGridControl = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.DetGridControl = New DevExpress.XtraGrid.GridControl()
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.SimpleButton1 = New DevExpress.XtraEditors.SimpleButton()
        Me.SimpleButton2 = New DevExpress.XtraEditors.SimpleButton()
        Me.SimpleButton3 = New DevExpress.XtraEditors.SimpleButton()
        Me.CheckEdit1 = New DevExpress.XtraEditors.CheckEdit()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        CType(Me.PanelTop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTop.SuspendLayout()
        CType(Me.DgvPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DgvPanel1.SuspendLayout()
        CType(Me.BotPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BotPanel.SuspendLayout()
        CType(Me.CabGridControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DetGridControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CheckEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelTop
        '
        Me.PanelTop.Controls.Add(Me.DateTimePicker1)
        Me.PanelTop.Controls.Add(Me.CheckEdit1)
        Me.PanelTop.Controls.Add(Me.SimpleButton3)
        Me.PanelTop.Controls.Add(Me.SimpleButton2)
        Me.PanelTop.Controls.Add(Me.SimpleButton1)
        Me.PanelTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelTop.Location = New System.Drawing.Point(0, 0)
        Me.PanelTop.Name = "PanelTop"
        Me.PanelTop.Size = New System.Drawing.Size(958, 113)
        Me.PanelTop.TabIndex = 0
        '
        'DgvPanel1
        '
        Me.DgvPanel1.Controls.Add(Me.CabGridControl)
        Me.DgvPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DgvPanel1.Location = New System.Drawing.Point(0, 113)
        Me.DgvPanel1.Name = "DgvPanel1"
        Me.DgvPanel1.Size = New System.Drawing.Size(958, 182)
        Me.DgvPanel1.TabIndex = 1
        '
        'BotPanel
        '
        Me.BotPanel.Controls.Add(Me.DetGridControl)
        Me.BotPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BotPanel.Location = New System.Drawing.Point(0, 295)
        Me.BotPanel.Name = "BotPanel"
        Me.BotPanel.Size = New System.Drawing.Size(958, 222)
        Me.BotPanel.TabIndex = 2
        '
        'CabGridControl
        '
        Me.CabGridControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CabGridControl.Location = New System.Drawing.Point(2, 2)
        Me.CabGridControl.MainView = Me.GridView1
        Me.CabGridControl.Name = "CabGridControl"
        Me.CabGridControl.Size = New System.Drawing.Size(954, 178)
        Me.CabGridControl.TabIndex = 0
        Me.CabGridControl.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.CabGridControl
        Me.GridView1.Name = "GridView1"
        '
        'DetGridControl
        '
        Me.DetGridControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DetGridControl.Location = New System.Drawing.Point(2, 2)
        Me.DetGridControl.MainView = Me.GridView2
        Me.DetGridControl.Name = "DetGridControl"
        Me.DetGridControl.Size = New System.Drawing.Size(954, 218)
        Me.DetGridControl.TabIndex = 0
        Me.DetGridControl.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView2})
        '
        'GridView2
        '
        Me.GridView2.GridControl = Me.DetGridControl
        Me.GridView2.Name = "GridView2"
        '
        'SimpleButton1
        '
        Me.SimpleButton1.Location = New System.Drawing.Point(816, 29)
        Me.SimpleButton1.Name = "SimpleButton1"
        Me.SimpleButton1.Size = New System.Drawing.Size(89, 61)
        Me.SimpleButton1.TabIndex = 0
        Me.SimpleButton1.Text = "SimpleButton1"
        '
        'SimpleButton2
        '
        Me.SimpleButton2.Location = New System.Drawing.Point(701, 29)
        Me.SimpleButton2.Name = "SimpleButton2"
        Me.SimpleButton2.Size = New System.Drawing.Size(103, 61)
        Me.SimpleButton2.TabIndex = 1
        Me.SimpleButton2.Text = "SimpleButton2"
        '
        'SimpleButton3
        '
        Me.SimpleButton3.Location = New System.Drawing.Point(580, 29)
        Me.SimpleButton3.Name = "SimpleButton3"
        Me.SimpleButton3.Size = New System.Drawing.Size(115, 61)
        Me.SimpleButton3.TabIndex = 2
        Me.SimpleButton3.Text = "SimpleButton3"
        '
        'CheckEdit1
        '
        Me.CheckEdit1.Location = New System.Drawing.Point(92, 49)
        Me.CheckEdit1.Name = "CheckEdit1"
        Me.CheckEdit1.Properties.Caption = "CheckEdit1"
        Me.CheckEdit1.Size = New System.Drawing.Size(75, 19)
        Me.CheckEdit1.TabIndex = 3
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(259, 47)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(94, 21)
        Me.DateTimePicker1.TabIndex = 4
        '
        'frmAnulaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(958, 517)
        Me.Controls.Add(Me.BotPanel)
        Me.Controls.Add(Me.DgvPanel1)
        Me.Controls.Add(Me.PanelTop)
        Me.Name = "frmAnulaciones"
        Me.Text = "frmAnulaciones"
        CType(Me.PanelTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTop.ResumeLayout(False)
        CType(Me.DgvPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DgvPanel1.ResumeLayout(False)
        CType(Me.BotPanel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BotPanel.ResumeLayout(False)
        CType(Me.CabGridControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DetGridControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CheckEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelTop As DevExpress.XtraEditors.PanelControl
    Friend WithEvents CheckEdit1 As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents SimpleButton3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton1 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents DgvPanel1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents CabGridControl As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents BotPanel As DevExpress.XtraEditors.PanelControl
    Friend WithEvents DetGridControl As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
End Class
