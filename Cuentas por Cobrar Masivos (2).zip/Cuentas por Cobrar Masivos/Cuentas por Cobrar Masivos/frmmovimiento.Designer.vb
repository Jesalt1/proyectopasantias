﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmovimiento
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmmovimiento))
        Me.LayoutControl1 = New DevExpress.XtraLayout.LayoutControl()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.btnValidar = New Infragistics.Win.Misc.UltraButton()
        Me.chktodos = New System.Windows.Forms.CheckBox()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.GroupControl1 = New DevExpress.XtraEditors.GroupControl()
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl()
        Me.txtnumero = New DevExpress.XtraEditors.TextEdit()
        Me.txtobservacion = New System.Windows.Forms.TextBox()
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl()
        Me.txtncuotas = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl()
        Me.cbofcobro = New System.Windows.Forms.ComboBox()
        Me.txtvalor = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.dtpfecha_proceso = New System.Windows.Forms.DateTimePicker()
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.glucuentaxcobrar = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridView4 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.LabelControl7 = New DevExpress.XtraEditors.LabelControl()
        Me.gluTipCXC = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridView3 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl()
        Me.lblcompania = New System.Windows.Forms.Label()
        Me.cmbCompania = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuempleados = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportExcelOption = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuguardar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCancelar = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnubuscar = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuexportar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnulimpiar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnusalir = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnulacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LayoutControlGroup1 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.LayoutControlGroup3 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.LayoutControlGroup4 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.LayoutControlItem2 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlGroup5 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.LayoutControlItem1 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.VerdetalleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        CType(Me.LayoutControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LayoutControl1.SuspendLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl1.SuspendLayout()
        CType(Me.txtnumero.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtncuotas.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtvalor.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.glucuentaxcobrar.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gluTipCXC.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlGroup3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlGroup4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlGroup5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LayoutControl1
        '
        Me.LayoutControl1.Controls.Add(Me.PanelControl2)
        Me.LayoutControl1.Controls.Add(Me.GroupControl1)
        Me.LayoutControl1.Controls.Add(Me.MenuStrip1)
        Me.LayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LayoutControl1.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControl1.Name = "LayoutControl1"
        Me.LayoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = New System.Drawing.Rectangle(354, 412, 948, 350)
        Me.LayoutControl1.Root = Me.LayoutControlGroup1
        Me.LayoutControl1.Size = New System.Drawing.Size(1040, 652)
        Me.LayoutControl1.TabIndex = 0
        Me.LayoutControl1.Text = "LayoutControl1"
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.btnValidar)
        Me.PanelControl2.Controls.Add(Me.chktodos)
        Me.PanelControl2.Controls.Add(Me.PanelControl3)
        Me.PanelControl2.Location = New System.Drawing.Point(27, 153)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(986, 472)
        Me.PanelControl2.TabIndex = 3
        '
        'btnValidar
        '
        Appearance1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnValidar.Appearance = Appearance1
        Me.btnValidar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnValidar.Location = New System.Drawing.Point(2, 430)
        Me.btnValidar.Name = "btnValidar"
        Me.btnValidar.Size = New System.Drawing.Size(982, 23)
        Me.btnValidar.TabIndex = 2
        Me.btnValidar.Text = "VALIDAR"
        Me.btnValidar.Visible = False
        '
        'chktodos
        '
        Me.chktodos.AutoSize = True
        Me.chktodos.Checked = True
        Me.chktodos.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chktodos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.chktodos.Location = New System.Drawing.Point(2, 453)
        Me.chktodos.Name = "chktodos"
        Me.chktodos.Size = New System.Drawing.Size(982, 17)
        Me.chktodos.TabIndex = 1
        Me.chktodos.Text = "Todos"
        Me.chktodos.UseVisualStyleBackColor = True
        '
        'PanelControl3
        '
        Me.PanelControl3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelControl3.Controls.Add(Me.GridControl1)
        Me.PanelControl3.Location = New System.Drawing.Point(2, 0)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(984, 445)
        Me.PanelControl3.TabIndex = 0
        '
        'GridControl1
        '
        Me.GridControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridControl1.Location = New System.Drawing.Point(2, 2)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(980, 441)
        Me.GridControl1.TabIndex = 0
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        '
        'GroupControl1
        '
        Me.GroupControl1.Controls.Add(Me.LabelControl6)
        Me.GroupControl1.Controls.Add(Me.txtnumero)
        Me.GroupControl1.Controls.Add(Me.txtobservacion)
        Me.GroupControl1.Controls.Add(Me.LabelControl5)
        Me.GroupControl1.Controls.Add(Me.txtncuotas)
        Me.GroupControl1.Controls.Add(Me.LabelControl3)
        Me.GroupControl1.Controls.Add(Me.cbofcobro)
        Me.GroupControl1.Controls.Add(Me.txtvalor)
        Me.GroupControl1.Controls.Add(Me.LabelControl2)
        Me.GroupControl1.Controls.Add(Me.dtpfecha_proceso)
        Me.GroupControl1.Controls.Add(Me.LabelControl1)
        Me.GroupControl1.Controls.Add(Me.glucuentaxcobrar)
        Me.GroupControl1.Controls.Add(Me.LabelControl7)
        Me.GroupControl1.Controls.Add(Me.gluTipCXC)
        Me.GroupControl1.Controls.Add(Me.LabelControl4)
        Me.GroupControl1.Controls.Add(Me.lblcompania)
        Me.GroupControl1.Controls.Add(Me.cmbCompania)
        Me.GroupControl1.Location = New System.Drawing.Point(27, 27)
        Me.GroupControl1.Name = "GroupControl1"
        Me.GroupControl1.Size = New System.Drawing.Size(986, 98)
        Me.GroupControl1.TabIndex = 2
        Me.GroupControl1.Text = "Parametros"
        '
        'LabelControl6
        '
        Me.LabelControl6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LabelControl6.Location = New System.Drawing.Point(641, 24)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(17, 13)
        Me.LabelControl6.TabIndex = 29
        Me.LabelControl6.Text = "No:"
        '
        'txtnumero
        '
        Me.txtnumero.EditValue = ""
        Me.txtnumero.Enabled = False
        Me.txtnumero.Location = New System.Drawing.Point(685, 21)
        Me.txtnumero.Name = "txtnumero"
        Me.txtnumero.Properties.Mask.EditMask = "d"
        Me.txtnumero.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtnumero.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtnumero.Size = New System.Drawing.Size(125, 20)
        Me.txtnumero.TabIndex = 28
        '
        'txtobservacion
        '
        Me.txtobservacion.Location = New System.Drawing.Point(81, 67)
        Me.txtobservacion.Name = "txtobservacion"
        Me.txtobservacion.Size = New System.Drawing.Size(777, 21)
        Me.txtobservacion.TabIndex = 27
        '
        'LabelControl5
        '
        Me.LabelControl5.Location = New System.Drawing.Point(11, 70)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(64, 13)
        Me.LabelControl5.TabIndex = 26
        Me.LabelControl5.Text = "Observación:"
        '
        'txtncuotas
        '
        Me.txtncuotas.EditValue = "1"
        Me.txtncuotas.Location = New System.Drawing.Point(919, 47)
        Me.txtncuotas.Name = "txtncuotas"
        Me.txtncuotas.Properties.Mask.EditMask = "d"
        Me.txtncuotas.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtncuotas.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtncuotas.Size = New System.Drawing.Size(50, 20)
        Me.txtncuotas.TabIndex = 25
        Me.txtncuotas.Visible = False
        '
        'LabelControl3
        '
        Me.LabelControl3.Location = New System.Drawing.Point(864, 50)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(49, 13)
        Me.LabelControl3.TabIndex = 24
        Me.LabelControl3.Text = "N.Cuotas:"
        Me.LabelControl3.Visible = False
        '
        'cbofcobro
        '
        Me.cbofcobro.FormattingEnabled = True
        Me.cbofcobro.Location = New System.Drawing.Point(610, 43)
        Me.cbofcobro.Name = "cbofcobro"
        Me.cbofcobro.Size = New System.Drawing.Size(142, 21)
        Me.cbofcobro.TabIndex = 23
        Me.cbofcobro.Visible = False
        '
        'txtvalor
        '
        Me.txtvalor.EditValue = "0.00"
        Me.txtvalor.Location = New System.Drawing.Point(758, 44)
        Me.txtvalor.Name = "txtvalor"
        Me.txtvalor.Properties.Mask.EditMask = "n2"
        Me.txtvalor.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtvalor.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtvalor.Size = New System.Drawing.Size(100, 20)
        Me.txtvalor.TabIndex = 22
        Me.txtvalor.Visible = False
        '
        'LabelControl2
        '
        Me.LabelControl2.Location = New System.Drawing.Point(561, 47)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(38, 13)
        Me.LabelControl2.TabIndex = 21
        Me.LabelControl2.Text = "T.Valor:"
        Me.LabelControl2.Visible = False
        '
        'dtpfecha_proceso
        '
        Me.dtpfecha_proceso.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpfecha_proceso.CustomFormat = "dd/MM/yyyy"
        Me.dtpfecha_proceso.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpfecha_proceso.Location = New System.Drawing.Point(873, 18)
        Me.dtpfecha_proceso.Name = "dtpfecha_proceso"
        Me.dtpfecha_proceso.Size = New System.Drawing.Size(96, 21)
        Me.dtpfecha_proceso.TabIndex = 19
        '
        'LabelControl1
        '
        Me.LabelControl1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LabelControl1.Location = New System.Drawing.Point(825, 23)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(42, 13)
        Me.LabelControl1.TabIndex = 18
        Me.LabelControl1.Text = "Fecha P:"
        '
        'glucuentaxcobrar
        '
        Me.glucuentaxcobrar.Location = New System.Drawing.Point(340, 43)
        Me.glucuentaxcobrar.Name = "glucuentaxcobrar"
        Me.glucuentaxcobrar.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.glucuentaxcobrar.Properties.View = Me.GridView4
        Me.glucuentaxcobrar.Size = New System.Drawing.Size(215, 20)
        Me.glucuentaxcobrar.TabIndex = 16
        '
        'GridView4
        '
        Me.GridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView4.Name = "GridView4"
        Me.GridView4.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView4.OptionsView.ShowGroupPanel = False
        '
        'LabelControl7
        '
        Me.LabelControl7.Location = New System.Drawing.Point(250, 46)
        Me.LabelControl7.Name = "LabelControl7"
        Me.LabelControl7.Size = New System.Drawing.Size(84, 13)
        Me.LabelControl7.TabIndex = 15
        Me.LabelControl7.Text = "Cuenta x Cobrar:"
        '
        'gluTipCXC
        '
        Me.gluTipCXC.Location = New System.Drawing.Point(68, 43)
        Me.gluTipCXC.Name = "gluTipCXC"
        Me.gluTipCXC.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.gluTipCXC.Properties.View = Me.GridView3
        Me.gluTipCXC.Size = New System.Drawing.Size(176, 20)
        Me.gluTipCXC.TabIndex = 9
        '
        'GridView3
        '
        Me.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView3.Name = "GridView3"
        Me.GridView3.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView3.OptionsView.ShowGroupPanel = False
        '
        'LabelControl4
        '
        Me.LabelControl4.Location = New System.Drawing.Point(11, 46)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(47, 13)
        Me.LabelControl4.TabIndex = 10
        Me.LabelControl4.Text = "Tipo CxC:"
        '
        'lblcompania
        '
        Me.lblcompania.AutoSize = True
        Me.lblcompania.Location = New System.Drawing.Point(8, 23)
        Me.lblcompania.Name = "lblcompania"
        Me.lblcompania.Size = New System.Drawing.Size(54, 13)
        Me.lblcompania.TabIndex = 7
        Me.lblcompania.Text = "Compañia"
        '
        'cmbCompania
        '
        Me.cmbCompania.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbCompania.Location = New System.Drawing.Point(68, 20)
        Me.cmbCompania.Name = "cmbCompania"
        Me.cmbCompania.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cmbCompania.Properties.View = Me.GridLookUpEdit1View
        Me.cmbCompania.Size = New System.Drawing.Size(541, 20)
        Me.cmbCompania.TabIndex = 6
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuempleados, Me.ImportExcelOption, Me.mnuguardar, Me.mnuCancelar, Me.ToolStripMenuItem1, Me.mnubuscar, Me.ToolStripMenuItem2, Me.mnuexportar, Me.mnulimpiar, Me.mnusalir, Me.AnulacionesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 2)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1040, 22)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuempleados
        '
        Me.mnuempleados.Image = CType(resources.GetObject("mnuempleados.Image"), System.Drawing.Image)
        Me.mnuempleados.Name = "mnuempleados"
        Me.mnuempleados.Size = New System.Drawing.Size(76, 18)
        Me.mnuempleados.Text = "&Generar"
        Me.mnuempleados.Visible = False
        '
        'ImportExcelOption
        '
        Me.ImportExcelOption.Image = Global.Cuentas_Cobrar_Mas.My.Resources.Resources.Excel
        Me.ImportExcelOption.Name = "ImportExcelOption"
        Me.ImportExcelOption.Size = New System.Drawing.Size(81, 18)
        Me.ImportExcelOption.Text = "Importar"
        '
        'mnuguardar
        '
        Me.mnuguardar.Image = CType(resources.GetObject("mnuguardar.Image"), System.Drawing.Image)
        Me.mnuguardar.Name = "mnuguardar"
        Me.mnuguardar.Size = New System.Drawing.Size(77, 18)
        Me.mnuguardar.Text = "&Guardar"
        '
        'mnuCancelar
        '
        Me.mnuCancelar.Image = Global.Cuentas_Cobrar_Mas.My.Resources.Resources.stock_no
        Me.mnuCancelar.Name = "mnuCancelar"
        Me.mnuCancelar.Size = New System.Drawing.Size(81, 18)
        Me.mnuCancelar.Text = "Cancelar"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(22, 18)
        Me.ToolStripMenuItem1.Text = "|"
        '
        'mnubuscar
        '
        Me.mnubuscar.Image = Global.Cuentas_Cobrar_Mas.My.Resources.Resources.search
        Me.mnubuscar.Name = "mnubuscar"
        Me.mnubuscar.Size = New System.Drawing.Size(70, 18)
        Me.mnubuscar.Text = "Buscar"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(22, 18)
        Me.ToolStripMenuItem2.Text = "|"
        '
        'mnuexportar
        '
        Me.mnuexportar.Image = Global.Cuentas_Cobrar_Mas.My.Resources.Resources.printer16x16
        Me.mnuexportar.Name = "mnuexportar"
        Me.mnuexportar.Size = New System.Drawing.Size(81, 18)
        Me.mnuexportar.Text = "&Imprimir"
        '
        'mnulimpiar
        '
        Me.mnulimpiar.Image = CType(resources.GetObject("mnulimpiar.Image"), System.Drawing.Image)
        Me.mnulimpiar.Name = "mnulimpiar"
        Me.mnulimpiar.Size = New System.Drawing.Size(75, 18)
        Me.mnulimpiar.Text = "&Limpiar"
        Me.mnulimpiar.Visible = False
        '
        'mnusalir
        '
        Me.mnusalir.Image = CType(resources.GetObject("mnusalir.Image"), System.Drawing.Image)
        Me.mnusalir.Name = "mnusalir"
        Me.mnusalir.Size = New System.Drawing.Size(57, 18)
        Me.mnusalir.Text = "&Salir"
        '
        'AnulacionesToolStripMenuItem
        '
        Me.AnulacionesToolStripMenuItem.Name = "AnulacionesToolStripMenuItem"
        Me.AnulacionesToolStripMenuItem.Size = New System.Drawing.Size(84, 18)
        Me.AnulacionesToolStripMenuItem.Text = "Anulaciones"
        Me.AnulacionesToolStripMenuItem.Visible = False
        '
        'LayoutControlGroup1
        '
        Me.LayoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.[True]
        Me.LayoutControlGroup1.GroupBordersVisible = False
        Me.LayoutControlGroup1.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.LayoutControlGroup3})
        Me.LayoutControlGroup1.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlGroup1.Name = "Root"
        Me.LayoutControlGroup1.Size = New System.Drawing.Size(1040, 652)
        '
        'LayoutControlGroup3
        '
        Me.LayoutControlGroup3.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.LayoutControlGroup4, Me.LayoutControlGroup5})
        Me.LayoutControlGroup3.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlGroup3.Name = "LayoutControlGroup3"
        Me.LayoutControlGroup3.Size = New System.Drawing.Size(1020, 632)
        Me.LayoutControlGroup3.TextVisible = False
        '
        'LayoutControlGroup4
        '
        Me.LayoutControlGroup4.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.LayoutControlItem2})
        Me.LayoutControlGroup4.Location = New System.Drawing.Point(0, 126)
        Me.LayoutControlGroup4.Name = "LayoutControlGroup4"
        Me.LayoutControlGroup4.Padding = New DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0)
        Me.LayoutControlGroup4.Size = New System.Drawing.Size(996, 482)
        Me.LayoutControlGroup4.TextVisible = False
        '
        'LayoutControlItem2
        '
        Me.LayoutControlItem2.Control = Me.PanelControl2
        Me.LayoutControlItem2.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlItem2.Name = "LayoutControlItem2"
        Me.LayoutControlItem2.Size = New System.Drawing.Size(990, 476)
        Me.LayoutControlItem2.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem2.TextVisible = False
        '
        'LayoutControlGroup5
        '
        Me.LayoutControlGroup5.AllowHide = False
        Me.LayoutControlGroup5.ExpandButtonVisible = True
        Me.LayoutControlGroup5.ExpandOnDoubleClick = True
        Me.LayoutControlGroup5.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.LayoutControlItem1})
        Me.LayoutControlGroup5.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlGroup5.Name = "LayoutControlGroup5"
        Me.LayoutControlGroup5.Padding = New DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0)
        Me.LayoutControlGroup5.Size = New System.Drawing.Size(996, 126)
        Me.LayoutControlGroup5.Text = "Parametros"
        Me.LayoutControlGroup5.TextLocation = DevExpress.Utils.Locations.Bottom
        '
        'LayoutControlItem1
        '
        Me.LayoutControlItem1.Control = Me.GroupControl1
        Me.LayoutControlItem1.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlItem1.Name = "LayoutControlItem1"
        Me.LayoutControlItem1.Size = New System.Drawing.Size(990, 102)
        Me.LayoutControlItem1.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem1.TextVisible = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VerdetalleToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(130, 26)
        '
        'VerdetalleToolStripMenuItem
        '
        Me.VerdetalleToolStripMenuItem.Name = "VerdetalleToolStripMenuItem"
        Me.VerdetalleToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.VerdetalleToolStripMenuItem.Text = "Ver Detalle"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "Archivo Excel | *.xls"
        '
        'frmmovimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1040, 652)
        Me.Controls.Add(Me.LayoutControl1)
        Me.Name = "frmmovimiento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.LayoutControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LayoutControl1.ResumeLayout(False)
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.PanelControl2.PerformLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl1.ResumeLayout(False)
        Me.GroupControl1.PerformLayout()
        CType(Me.txtnumero.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtncuotas.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtvalor.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.glucuentaxcobrar.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gluTipCXC.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlGroup3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlGroup4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlGroup5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LayoutControl1 As DevExpress.XtraLayout.LayoutControl
    Friend WithEvents GroupControl1 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents LayoutControlGroup1 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents LayoutControlGroup3 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents LayoutControlGroup4 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents LayoutControlGroup5 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents LayoutControlItem1 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents LayoutControlItem2 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents VerdetalleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblcompania As System.Windows.Forms.Label
    Friend WithEvents cmbCompania As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents glucuentaxcobrar As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView4 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents LabelControl7 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents gluTipCXC As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents dtpfecha_proceso As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtvalor As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents cbofcobro As System.Windows.Forms.ComboBox
    Friend WithEvents txtncuotas As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtobservacion As System.Windows.Forms.TextBox
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents chktodos As System.Windows.Forms.CheckBox
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtnumero As DevExpress.XtraEditors.TextEdit
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuempleados As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportExcelOption As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuguardar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCancelar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnubuscar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuexportar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnulimpiar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnusalir As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnValidar As Infragistics.Win.Misc.UltraButton
    Friend WithEvents AnulacionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
