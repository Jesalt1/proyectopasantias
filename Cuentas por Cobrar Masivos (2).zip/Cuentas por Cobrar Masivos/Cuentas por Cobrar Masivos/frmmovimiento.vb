﻿Imports libreria
Imports DevExpress.XtraEditors
Imports System.Data.SqlClient
Imports System.IO
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraGrid.Views.Base
Imports DevExpress.XtraEditors.Repository
Imports DevExpress.XtraPrinting

'Imports ClosedXML
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmmovimiento
    Dim commands As String
    Dim Tabla As New DataTable("tabla")
    Dim Tabla_Periodo As New DataTable("Tipo_Periodo")
    Dim lwiItemsData As ClsItemsData
    Dim max_compania As Integer, lwdfecha_proceso As Date
    Dim pwoObjeto As New List(Of ClsObjetos)

    Dim operacion As Integer
    Dim dtResultado As New DataTable()

    Dim dt As New DataTable
    Dim Validado As Boolean
    Dim hasEmptyField As Boolean = False
    Sub New()
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        commands = Microsoft.VisualBasic.Interaction.Command()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub
    Sub New(ByVal iscommand As String)
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        commands = iscommand
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub

    Sub cargar_tabla()
        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim oArray() As String
        Dim oDts As New Data.DataSet


        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing


        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "ROLSp_Cuentas_Cobrar_Masivas"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "tabla")
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
            End With
            Dim oDar As New SqlDataAdapter(oComand)
            oDar.Fill(oDts)
            If oDts.Tables.Count > 1 Then
                If oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(0).ToString() = "collection" Then
                    oArray = Split(oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(1).ToString(), ";")
                    For i = 0 To oDts.Tables.Count - 2
                        oDts.Tables(i).TableName = oArray(i).ToString()
                    Next
                End If
            End If
            For Each oTabla As DataTable In oDts.Tables
                Select Case oTabla.TableName
                    Case "tipo_corte"
                        Tabla_Periodo.Rows.Clear()
                        For Each oReg As DataRow In oTabla.Rows
                            Tabla_Periodo.Rows.Add(oReg("Codigo"), oReg("Descripcion"))
                        Next

                End Select
            Next
            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If

            oCon = Nothing
            oComand = Nothing



        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SeteoBoton(ByVal bool As Boolean)
        ImportExcelOption.Enabled = Not bool
        mnuempleados.Enabled = Not bool
        mnuguardar.Enabled = bool
        mnuCancelar.Enabled = bool
        mnubuscar.Enabled = Not bool
        mnuexportar.Enabled = bool

    End Sub

    Private Sub frmMigradorFacturas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If Not Load_Siac(Me, "ROLES", commands) Then
                Me.Dispose()
            End If
            sgMaquina = My.Computer.Name
            llenar_compania()
            If max_compania > 0 Then
                cmbCompania.EditValue = cmbCompania.Properties.GetKeyValue(0)
                sgCompaniaForm = sgCompania

                If mostrar_empresa() = "N" Then
                    lblcompania.Enabled = False
                    lblcompania.Visible = False
                    cmbCompania.Enabled = False
                    cmbCompania.Visible = False
                Else
                    lblcompania.Enabled = True
                    lblcompania.Visible = True
                    cmbCompania.Enabled = True
                    cmbCompania.Visible = True

                End If
            End If

            Call table()
            'cargar_combo_opciones()
            sgMaquina = My.Computer.Name
            sgFecha = fecha_proceso(sgCompaniaForm)  'FechaServidor2(sgbase)
            pwoObjeto.Add(New ClsObjetos(1, "glu_tipo", gluTipCXC))
            pwoObjeto.Add(New ClsObjetos(2, "cbo_tipo", cbofcobro))
            pwoObjeto.Add(New ClsObjetos(3, "dtp_fecha", dtpfecha_proceso))
            Call Cargar_Objetos(sgbaseRoles, "ROLSp_Cuentas_Cobrar_Masivas", "load", pwoObjeto)
            pwoObjeto.Clear()
            Call cargar_tabla()
            Call SeteoBoton(False)
            chktodos.Visible = False
            ' dtpfecha_proceso.Enabled = False
            ' dtpperiodo.Value = "01/" & Format(sgFecha, "MM/yyyy")
        Catch ex As Exception
            XtraMessageBox.Show("Error en la ejecución de la aplicación: " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub
#Region "FUNCIONES Y PROCEDIMIENTOS BASICOS"
    Private Sub llenar_compania()

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim dt As New DataSet
        Dim dtadap As SqlDataAdapter

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                '.CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Compania"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "query_empresa")
            End With


            dtadap = New SqlDataAdapter(oComand)
            dtadap.Fill(dt)
            max_compania = dt.Tables(0).Rows.Count
            ' max_compania = max_compania - 1
            ' llenacompania = False
            cmbCompania.Properties.DataSource = dt.Tables(0)
            cmbCompania.Properties.DisplayMember = "Nombre"
            cmbCompania.Properties.ValueMember = "Codigo"
            ' llenacompania = True
            oComand = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Function mostrar_empresa() As String

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim oRs As SqlDataReader

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        mostrar_empresa = "N"
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbase, sguser, sgpw, oCon) = False Then Exit Function
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "PARMSp_Mant_Parametro_General"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "mos_emp")

            End With
            oRs = oComand.ExecuteReader()
            If oRs.HasRows = True Then
                If oRs.Read Then

                    mostrar_empresa = oRs.Item("mostrar_empresa")
                End If
            End If

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Function fecha_proceso(compania As Integer) As String
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        'Dim ierror As Integer, smensaje As String
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            fecha_proceso = ""
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Function
            oComand = New SqlCommand
            With oComand

                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "fec_proc")
                .Parameters.AddWithValue("@NT08CODCIA", compania)

            End With
            oRs = oComand.ExecuteReader()

            If oRs.HasRows = True Then
                If oRs.Read Then
                    fecha_proceso = Format(oRs.Item("fecha"), "dd/MM/yyyy")
                End If
            End If


            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)

        End Try
    End Function
#End Region
    Sub table()
        'Dim oCon As SqlConnection
        'Dim oComand As SqlCommand
        'Dim dt As New DataSet
        'Dim dtadap As SqlDataAdapter
        'Dim oconexion As gConnectionSql.gConnection
        'Dim RepositorioItems As New DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit

        'oconexion = New gConnectionSql.gConnection

        'oCon = Nothing
        Try
            '    If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            '    oComand = New SqlCommand
            '    With oComand
            '        '.CommandTimeout = 0
            '        .CommandText = "RolSp_Mant_Tipo_Cobro"
            '        .Connection = oCon
            '        .CommandType = CommandType.StoredProcedure
            '        .Parameters.AddWithValue("@i_operacion", "combo")
            '    End With
            '    dtadap = New SqlDataAdapter(oComand)
            '    dtadap.Fill(dt)

            '    '  RepositorioItems.Dispose()
            '    With RepositorioItems
            '        .DataSource = dt.Tables(0)
            '        .ValueMember = "idtipocobro"
            '        .DisplayMember = "descripcion"
            '    End With


            '    'llenacompania = True
            '    oComand = Nothing
            '    oCon.Close()
            '    oCon = Nothing

            Tabla_Periodo.Rows.Clear()
            Tabla_Periodo.Columns.Clear()
            Tabla_Periodo.Columns.Add(New DataColumn("Clave", GetType(Integer)))
            Tabla_Periodo.Columns.Add(New DataColumn("Descripcion", GetType(String)))



            Tabla.Columns.Clear()
            Tabla.Rows.Clear()
            Tabla.Columns.Add(New DataColumn("-", GetType(Boolean)))
            Tabla.Columns.Add(New DataColumn("Compania", GetType(Integer)))
            Tabla.Columns.Add(New DataColumn("Clave", GetType(Integer)))
            Tabla.Columns.Add(New DataColumn("Ruc", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Nombre", GetType(String)))

            Tabla.Columns.Add(New DataColumn("Departamento", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Cargo", GetType(String)))

            Tabla.Columns.Add(New DataColumn("Tipo CxC", GetType(String)))
            Tabla.Columns.Add(New DataColumn("CxC", GetType(String)))

            'Tabla.Columns.Add(New DataColumn("Sector", GetType(String)))
            'Tabla.Columns.Add(New DataColumn("No.CtaxCbr", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Base", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("Porcentaje", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("Valor", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("N.Cuotas", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("Cuotas", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("S.Cuotas", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("Fecha", GetType(DateTime)))
            Tabla.Columns.Add(New DataColumn("TipoCobro", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Observacion", GetType(String)))
            Tabla.Columns.Add(New DataColumn("iddepartamento", GetType(Integer)))
            Tabla.Columns.Add(New DataColumn("idcargo", GetType(Integer)))

            Tabla.Columns.Add(New DataColumn("tipocxc", GetType(Integer)))
            Tabla.Columns.Add(New DataColumn("cxc", GetType(Integer)))
            


            GridView1.Columns.Clear()
            GridView1.OptionsView.ColumnAutoWidth = False
            GridView1.OptionsPrint.AutoWidth = False
            GridView1.BestFitColumns()

            GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
            GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
            GridControl1.DataSource = Nothing
            GridView1.OptionsView.ShowGroupPanel = False
            GridControl1.DataSource = Tabla
            GridView1.Columns("-").Width = 20
            GridView1.Columns("Compania").Visible = False
            ' GridView1.Columns("Clave").Visible = False
            GridView1.Columns("Ruc").Width = 80
            GridView1.Columns("Nombre").Width = 150
            GridView1.Columns("Departamento").Width = 100
            GridView1.Columns("Cargo").Width = 80
            GridView1.Columns("Base").Width = 90
            GridView1.Columns("Porcentaje").Width = 90
            GridView1.Columns("Valor").Width = 90
            GridView1.Columns("N.Cuotas").Width = 90
            GridView1.Columns("Cuotas").Width = 90
            GridView1.Columns("S.Cuotas").Width = 90
            GridView1.Columns("Fecha").Width = 90
            GridView1.Columns("TipoCobro").Width = 120

            GridView1.Columns("Observacion").Width = 150
            ' GridView1.Columns("Editar").Visible = False
            GridView1.Columns("iddepartamento").Visible = False
            GridView1.Columns("idcargo").Visible = False
            GridView1.Columns("Base").Visible = False
            GridView1.Columns("Porcentaje").Visible = False
            GridView1.Columns("iddepartamento").Visible = False

            '.OptionsView.ShowFooter = True
            GridView1.Columns("TipoCobro").OptionsColumn.AllowEdit = True
            GridView1.Columns("Valor").OptionsColumn.ReadOnly = True
            GridView1.Columns("Valor").Summary.Add(DevExpress.Data.SummaryItemType.Sum, "Valor", "{0:#.##}")
            GridView1.Columns("tipocxc").Width = 120
            GridView1.Columns("cxc").Width = 120
            Dim rilperiodo As New RepositoryItemGridLookUpEdit()
            rilperiodo.DataSource = Tabla_Periodo
            rilperiodo.ValueMember = "Clave"
            rilperiodo.DisplayMember = "Descripcion" ' "Descripcion"
            rilperiodo.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            'rilcentro_costo.View.Column()
            GridView1.Columns("TipoCobro").ColumnEdit = rilperiodo
            GridView1.OptionsView.ShowAutoFilterRow = True

            ' GridView1.OptionsBehavior.EditingMode = GridEditingMode.EditFormInplace
            '    GridView1.OptionsNavigation.EnterMoveNextColumn = True
        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    'Sub cargar_combo_opciones()
    '    Try


    '        cmbaccion.Items.Add(New ClsItemsData("Sin Agrupar", 1))
    '        cmbaccion.Items.Add(New ClsItemsData("Agrupados", 2))
    '        cmbaccion.Items.Add(New ClsItemsData("Registrados", 3))
    '        cmbaccion.SelectedIndex = IIf(cmbaccion.Items.Count > 0, 0, -1)

    '        '    Call seteo_boton(True)
    '        cmbaccion.AutoCompleteSource = AutoCompleteSource.ListItems
    '        cmbaccion.AutoCompleteMode = AutoCompleteMode.SuggestAppend
    '        cmbaccion.DropDownStyle = ComboBoxStyle.DropDownList
    '    Catch ex As Exception
    '        XtraMessageBox.Show("Error al cargar combo : " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    '    End Try

    'End Sub

    Function load_cuentas_cobrar() As Boolean
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        ' Dim oRs As SqlDataReader
        Dim oArray() As String
        Dim oDts As New DataSet
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        Dim bbol As Boolean = False
        oCon = Nothing
        Try
            oComand = New SqlCommand
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then
                bbol = False
                Return bbol
                Exit Function
            End If

            With oComand

                .CommandText = "ROLSp_Cuentas_Cobrar_Masivas"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "query")
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                '.Parameters.AddWithValue("@i_usuario", sgUsuario)
                '.Parameters.AddWithValue("@i_maquina", sgMaquina)
                .Parameters.AddWithValue("@i_numero", CDbl(txtnumero.Text))
                ' .Parameters.AddWithValue("@i_ctas_cobrar", sgCompaniaForm)
            End With
            Call table()
            Call cargar_tabla()

            Tabla.Rows.Clear()

            Dim oDar As New SqlDataAdapter(oComand)
            oDar.Fill(oDts)

            If oDts.Tables(0).Rows.Count = 0 Then
                XtraMessageBox.Show("No existen datos con los Parámetros ingresados......Verifique", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtnumero.Text = ""
                bbol = False
                Return bbol
                Exit Function
            End If

            If oDts.Tables.Count > 1 Then
                If oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(0).ToString() = "collection" Then
                    oArray = Split(oDts.Tables(oDts.Tables.Count - 1).Rows(0).ItemArray(1).ToString(), ";")
                    For i = 0 To oDts.Tables.Count - 2
                        oDts.Tables(i).TableName = oArray(i).ToString()
                    Next
                End If
            End If


            For Each oTabla As DataTable In oDts.Tables
                Select Case oTabla.TableName
                    Case "cab"
                        For Each oReg As DataRow In oTabla.Rows
                            gluTipCXC.EditValue = oReg("tipo_cxc")
                            glucuentaxcobrar.EditValue = oReg("ctasxcbr")
                            txtobservacion.Text = oReg("observacion")
                            dtpfecha_proceso.Value = oReg("fecha")
                            ubicar_combo(cbofcobro, oReg("tdes_cxc"))
                            txtvalor.Text = oReg("valor")
                            txtncuotas.Text = oReg("ncuotas")
                        Next
                    Case "det"
                        For Each oReg As DataRow In oTabla.Rows


                            Tabla.Rows.Add(oReg("sel"), oReg("Compania"), oReg("clave"), oReg("identificacion"), oReg("nombre"), oReg("departamento"), _
                                  oReg("cargo"), oReg("Tipo CxC"), oReg("CxC"), oReg("base"), oReg("por"), oReg("valor"), oReg("ncuotas"), oReg("cuotas"), _
                                  oReg("res"), oReg("fecha"), oReg("tipoc"), oReg("observacion"), oReg("iddepartamento"), oReg("idcargo"), oReg("tipoc"), oReg("ccx"))
                        Next
                End Select
            Next

            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oCon = Nothing
            oComand = Nothing
            bbol = True
            Return bbol
        Catch ex As Exception
            XtraMessageBox.Show(" Error " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Function validar_grid() As Boolean
        validar_grid = True
        For Each row As DataRow In Tabla.Rows
            If row("Valor") > 0 Then

                If row("Cuotas").ToString.Trim.Length = 0 Then
                    MsgBox("No ha ingresado el numero de Cuotas a Aplicar")
                    validar_grid = False
                    Exit Function
                End If
                If row("Cuotas") = 0 Then
                    MsgBox("No ha ingresado el numero de Cuotas a Aplicar")
                    validar_grid = False
                    Exit Function
                End If
                If row("TipoCobro").ToString.Trim.Length = 0 Then
                    MsgBox("No ha Selecionado el Tipo de Cobro......")
                    validar_grid = False
                    Exit Function
                End If
                If row("Fecha").ToString.Trim.Length = 0 Then
                    MsgBox("No ha ingresado la fecha a realizar la aplicacion de la Cuenta por Cobrar")
                    validar_grid = False
                    Exit Function
                End If


            End If
        Next
    End Function
    Private Sub mnuguardar_Click(sender As Object, e As EventArgs) Handles mnuguardar.Click
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim numero As Double, secuencia As Integer
        Dim xml As New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
        Dim ierror As Integer, smensaje As String, fnumero As Double
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing


        If hasEmptyField Then



        ElseIf (operacion = 1) Then
            Try
                If XtraMessageBox.Show("Esta seguro de Registrar las Cuentas por cobrar Masivas", NOMBRE_SISTEMA, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) = DialogResult.Cancel Then Exit Sub
                txtobservacion.Focus()
                If validar_grid() = False Then Exit Sub
                If txtnumero.Text.Trim.Length = 0 Then
                    numero = 0
                Else
                    numero = txtnumero.Text
                End If
                Dim dxml As New XElement("CXC")
                Dim cxml As New XElement("CAB")
                cxml.Add(New XAttribute("compania", sgCompaniaForm))
                cxml.Add(New XAttribute("usuario", sgUsuario))
                cxml.Add(New XAttribute("maquina", sgMaquina))
                cxml.Add(New XAttribute("numero", CDbl(numero).ToString("########0")))
                cxml.Add(New XAttribute("fecha", Format(dtpfecha_proceso.Value, "yyyyMMdd")))
                cxml.Add(New XAttribute("descripcion", txtobservacion.Text))
                cxml.Add(New XAttribute("tcxc", gluTipCXC.EditValue))
                cxml.Add(New XAttribute("ctscbr", glucuentaxcobrar.EditValue))
                cxml.Add(New XAttribute("valor", CDbl(txtvalor.Text).ToString("########0.00")))
                cxml.Add(New XAttribute("tdes", CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).ItemData))
                cxml.Add(New XAttribute("ncuota", CDbl(txtncuotas.Text).ToString("########0")))
                cxml.Add(New XAttribute("num_reg", Tabla.Rows.Count))
                cxml.Add(New XAttribute("estado", "A"))
                secuencia = 1
                For Each row As DataRow In Tabla.Rows
                    If row("-") = True Then
                        Dim detxml As New XElement("DET")
                        detxml.Add(New XAttribute("secuencia", secuencia))
                        detxml.Add(New XAttribute("empleado", row("compania")))
                        detxml.Add(New XAttribute("iddepartamento", row("iddepartamento")))
                        detxml.Add(New XAttribute("idcargo", row("idcargo")))
                        detxml.Add(New XAttribute("departamento", row("Departamento")))
                        detxml.Add(New XAttribute("cargo", row("Cargo")))
                        detxml.Add(New XAttribute("base", CDbl(row("Base")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("por", CDbl(row("Porcentaje")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("valor", CDbl(row("Valor")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("ncuota", CDbl(row("N.Cuotas")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("cuota", CDbl(row("Cuotas")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("scuota", CDbl(row("S.Cuotas")).ToString("###########0.00")))

                        detxml.Add(New XAttribute("fecha", Format(row("Fecha"), "yyyyMMdd")))
                        detxml.Add(New XAttribute("tipoc", row("TipoCobro")))
                        detxml.Add(New XAttribute("observacion", row("Observacion")))
                        cxml.Add(detxml)
                        secuencia += 1
                    End If
                Next
                dxml.Add(cxml)
                xml.Add(dxml)

                oComand = New SqlCommand
                If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
                With oComand
                    .CommandTimeout = 0
                    .CommandText = "ROLSp_Cuentas_Cobrar_Masivas"
                    .Connection = oCon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "registrar_")
                    .Parameters.AddWithValue("@i_compania", sgCompania)
                    '.Parameters.AddWithValue("@i_anio", dtpperiodo.Value.Year)
                    '.Parameters.AddWithValue("@i_mes", dtpperiodo.Value.Month)
                    .Parameters.AddWithValue("@i_xml", xml.ToString)
                    .Parameters.AddWithValue("@i_usuario", sgUsuario)
                    .Parameters.AddWithValue("@i_maquina", sgMaquina)

                    .Parameters.Add("@o_error", SqlDbType.Int)

                    .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 8000)
                    .Parameters.Add("@o_numero", SqlDbType.Float)
                    .Parameters("@o_error").Direction = ParameterDirection.Output
                    .Parameters("@o_mensaje").Direction = ParameterDirection.Output
                    .Parameters("@o_numero").Direction = ParameterDirection.Output
                End With
                oComand.ExecuteScalar()
                ierror = oComand.Parameters("@o_error").Value
                smensaje = oComand.Parameters("@o_mensaje").Value
                fnumero = oComand.Parameters("@o_numero").Value

                XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)

                oComand = Nothing

                oCon.Close()
                oCon = Nothing
                If ierror = 0 Then
                    txtnumero.Text = fnumero
                    If load_cuentas_cobrar() = False Then Exit Sub
                    mnuexportar.PerformClick()
                    mnuCancelar.PerformClick()
                End If
                ' Tabla.Rows.Clear()
            Catch ex As Exception
                XtraMessageBox.Show("Error : " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Try


            'Opcion de subida de acrhivo excel

        ElseIf operacion = 2 And Validado = True Then
           Try
                If XtraMessageBox.Show("Esta seguro de Registrar las Cuentas por cobrar Masivas", NOMBRE_SISTEMA, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) = DialogResult.Cancel Then Exit Sub
                txtobservacion.Focus()
                'If validar_grid() = False Then Exit Sub
                If txtnumero.Text.Trim.Length = 0 Then
                    numero = 0
                Else
                    numero = txtnumero.Text
                End If
                Dim dxml As New XElement("CXC")
                Dim cxml As New XElement("CAB")
                cxml.Add(New XAttribute("compania", sgCompaniaForm))
                cxml.Add(New XAttribute("usuario", sgUsuario))
                cxml.Add(New XAttribute("maquina", sgMaquina))
                cxml.Add(New XAttribute("numero", CDbl(numero).ToString("########0")))
                cxml.Add(New XAttribute("fecha", Format(dtpfecha_proceso.Value, "yyyyMMdd")))
                cxml.Add(New XAttribute("descripcion", txtobservacion.Text))
                cxml.Add(New XAttribute("tcxc", gluTipCXC.EditValue))
                cxml.Add(New XAttribute("ctscbr", glucuentaxcobrar.EditValue))
                cxml.Add(New XAttribute("valor", CDbl(txtvalor.Text).ToString("########0.00")))
                cxml.Add(New XAttribute("tdes", CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).ItemData))
                cxml.Add(New XAttribute("ncuota", CDbl(txtncuotas.Text).ToString("########0")))
                cxml.Add(New XAttribute("num_reg", Tabla.Rows.Count))
                cxml.Add(New XAttribute("estado", "A"))
                secuencia = 1
                For Each row As DataRow In Tabla.Rows
                    If row("-") = True Then
                        Dim detxml As New XElement("DET")
                        detxml.Add(New XAttribute("secuencia", secuencia))
                        detxml.Add(New XAttribute("empleado", row("Clave")))
                        detxml.Add(New XAttribute("iddepartamento", row("iddepartamento")))
                        detxml.Add(New XAttribute("idcargo", row("idcargo")))
                        detxml.Add(New XAttribute("departamento", row("Departamento")))
                        detxml.Add(New XAttribute("cargo", row("Cargo")))
                        detxml.Add(New XAttribute("base", CDbl(row("Base")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("por", CDbl(row("Porcentaje")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("valor", CDbl(row("Valor")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("ncuota", 1))
                        detxml.Add(New XAttribute("cuota", CDbl(row("Valor")).ToString("###########0.00")))
                        detxml.Add(New XAttribute("scuota", CDbl(row("S.Cuotas")).ToString("###########0.00")))

                        detxml.Add(New XAttribute("fecha", Format(row("Fecha"), "yyyyMMdd")))
                        detxml.Add(New XAttribute("tipoc", row("TipoCobro")))
                        detxml.Add(New XAttribute("observacion", row("Observacion")))
                        detxml.Add(New XAttribute("tipocxc", row("tipocxc")))
                        detxml.Add(New XAttribute("ctasxcbr", row("cxc")))
                        cxml.Add(detxml)
                        secuencia += 1
                    End If
                Next
                dxml.Add(cxml)
                xml.Add(dxml)

                oComand = New SqlCommand
                If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
                With oComand
                    .CommandTimeout = 0
                    .CommandText = "ROLSp_Cuentas_Cobrar_Masivas"
                    .Connection = oCon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "registrar_")
                    .Parameters.AddWithValue("@i_compania", sgCompania)
                    '.Parameters.AddWithValue("@i_anio", dtpperiodo.Value.Year)
                    '.Parameters.AddWithValue("@i_mes", dtpperiodo.Value.Month)
                    .Parameters.AddWithValue("@i_xml", xml.ToString)
                    .Parameters.AddWithValue("@i_usuario", sgUsuario)
                    .Parameters.AddWithValue("@i_maquina", sgMaquina)

                    .Parameters.Add("@o_error", SqlDbType.Int)

                    .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 8000)
                    .Parameters.Add("@o_numero", SqlDbType.Float)
                    .Parameters("@o_error").Direction = ParameterDirection.Output
                    .Parameters("@o_mensaje").Direction = ParameterDirection.Output
                    .Parameters("@o_numero").Direction = ParameterDirection.Output
                End With
                oComand.ExecuteScalar()
                ierror = oComand.Parameters("@o_error").Value
                smensaje = oComand.Parameters("@o_mensaje").Value
                fnumero = oComand.Parameters("@o_numero").Value

                XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)

                oComand = Nothing

                oCon.Close()
                oCon = Nothing
                If ierror = 0 Then
                    txtnumero.Text = fnumero
                    If load_cuentas_cobrar() = False Then Exit Sub
                    OcultarCamposDGV()
                    mnuexportar.PerformClick()
                    mnuCancelar.PerformClick()
                End If
                ' Tabla.Rows.Clear()
            Catch ex As Exception
                XtraMessageBox.Show("Error : " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Try


        ElseIf operacion = 2 And Validado = False Then
            XtraMessageBox.Show("Favor de Validar los datos ingresados", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        'End If

    End Sub



    'Private Sub cmbaccion_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboctaxcobrar.SelectedIndexChanged
    '    'lwiItemsData = cboctaxcobrar.Items(cboctaxcobrar.SelectedIndex)

    '    'Select Case lwiItemsData.ItemData

    '    '    Case 1
    '    '        cmdregistrar.Enabled = False
    '    '    Case 2
    '    '        cmdregistrar.Enabled = True
    '    '    Case 3
    '    '        cmdregistrar.Enabled = False
    '    'End Select


    '    'Tabla.Rows.Clear()
    'End Sub


    Private Sub GridView1_CellValueChanged(sender As Object, e As DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs) Handles GridView1.CellValueChanged
        Select Case e.Column.FieldName
            Case "Porcentaje"
                GridView1.GetDataRow(sender.FocusedRowHandle)("Valor") = GridView1.GetDataRow(sender.FocusedRowHandle)("Base") * (GridView1.GetDataRow(sender.FocusedRowHandle)("Porcentaje") * 0.01)
                GridView1.GetDataRow(sender.FocusedRowHandle)("Cuotas") = Math.Truncate(CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("Valor")) / CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("N.Cuotas")))
                GridView1.GetDataRow(sender.FocusedRowHandle)("S.Cuotas") = CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("Valor")) Mod CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("N.Cuotas"))
            Case "N.Cuotas"
                GridView1.GetDataRow(sender.FocusedRowHandle)("Cuotas") = Math.Truncate(CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("Valor")) / CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("N.Cuotas")))
                GridView1.GetDataRow(sender.FocusedRowHandle)("S.Cuotas") = CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("Valor")) Mod CDbl(GridView1.GetDataRow(sender.FocusedRowHandle)("N.Cuotas"))
        End Select

    End Sub

    Private Sub VerdetalleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerdetalleToolStripMenuItem.Click
        'GridView1.Columns("Clave").OptionsColumn.AllowEdit = False
        'GridView1.Columns("Ruc").OptionsColumn.AllowEdit = False
        'GridView1.Columns("Nombre").OptionsColumn.AllowEdit = False
        'GridView1.Columns("Labora").OptionsColumn.AllowEdit = False
        'GridView1.Columns("TipoCxC").OptionsColumn.AllowEdit = False
        'GridView1.Columns("CuentaCobrar").OptionsColumn.AllowEdit = False
        'GridView1.Columns("No.CtaxCbr").OptionsColumn.AllowEdit = False
        'GridView1.Columns("No.CtaxCbr").Visible = True
        'GridView1.Columns("Valor").OptionsColumn.AllowEdit = False
        'GridView1.Columns("N.Cuotas").OptionsColumn.AllowEdit = False
        'GridView1.Columns("Cuotas").OptionsColumn.AllowEdit = False
        'GridView1.Columns("S.Cuotas").OptionsColumn.AllowEdit = False
        'GridView1.Columns("Fecha").OptionsColumn.AllowEdit = False
        'GridView1.Columns("TipoCobro").OptionsColumn.AllowEdit = False
        'GridView1.Columns("Observacion").OptionsColumn.AllowEdit = False


        'Dim formas As New frmdetalle(dtpperiodo.Value.Year, dtpperiodo.Value.Month, GridView1.GetFocusedDataRow("TipoCxC"), GridView1.GetFocusedDataRow("Ruc"))
        'formas.ShowDialog()
    End Sub


    Private Sub mnuexportar_Click(sender As Object, e As EventArgs) Handles mnuexportar.Click
        Try
            GridView1.ShowPrintPreview()

        Catch ex As Exception
            XtraMessageBox.Show("Error en la ejecución de imprimir: " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub mnulimpiar_Click(sender As Object, e As EventArgs) Handles mnulimpiar.Click
        Try
            ' Tabla.Rows.Clear()
            Call limpiar()
            txtnumero.Text = ""
            txtnumero.Enabled = False
            mnuempleados.Enabled = True
            mnuguardar.Enabled = True
            btnValidar.Visible = False
        Catch ex As Exception
            XtraMessageBox.Show("Error: " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub

    Private Sub mnusalir_Click(sender As Object, e As EventArgs) Handles mnusalir.Click
        Me.Dispose()
    End Sub

    Private Sub gluTipCXC_EditValueChanged(sender As Object, e As EventArgs) Handles gluTipCXC.EditValueChanged
        llenarcuentaxcobrar(gluTipCXC.EditValue)
    End Sub
    Private Sub llenarcuentaxcobrar(codcuenta As Integer)
        Dim sSql As String
        Dim oCon As SqlConnection
        Dim oComand As New SqlCommand
        Dim dt As New DataSet
        Dim dtadp As SqlDataAdapter

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "ROLSp_Cuentas_Cobrar_Masivas"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "cxc")
                .Parameters.AddWithValue("@i_compania", cmbCompania.EditValue)
                .Parameters.AddWithValue("@i_tipo_cxc", gluTipCXC.EditValue)

            End With
            oComand.ExecuteScalar()

            dtadp = New SqlDataAdapter(oComand)
            dtadp.Fill(dt)
            oCon.Close()

            glucuentaxcobrar.Properties.DataSource = dt.Tables(0)
            glucuentaxcobrar.Properties.DisplayMember = "Descripcion"
            glucuentaxcobrar.Properties.ValueMember = "Codigo"
            glucuentaxcobrar.EditValue = IIf(CType(glucuentaxcobrar.Properties.DataSource, Data.DataTable).Rows.Count > 0, glucuentaxcobrar.Properties.GetKeyValue(0), glucuentaxcobrar.Properties.GetKeyValue(-1))

        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try
    End Sub

    Private Sub mnuempleados_Click(sender As Object, e As EventArgs) Handles mnuempleados.Click
        Call table()
        cargar_tabla()
        SeteoBoton(True)

        gluTipCXC.Enabled = True
        glucuentaxcobrar.Enabled = True
        cbofcobro.Enabled = True
        txtvalor.Enabled = True
        txtncuotas.Enabled = True
        dtpfecha_proceso.Enabled = True

        btnValidar.Visible = False

        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        'Dim ierror As Integer, smensaje As String
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
            oComand = New SqlCommand
            With oComand

                .CommandText = "ROLSp_Cuentas_Cobrar_Masivas"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "grid")
                .Parameters.AddWithValue("@i_compania", sgCompania)
                .Parameters.AddWithValue("@i_fecha", Format(dtpfecha_proceso.Value, "yyyyMMdd"))
                .Parameters.AddWithValue("@i_fcobrar", CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).ItemData)
                .Parameters.AddWithValue("@i_valor", CDbl(txtvalor.Text).ToString("########0.00"))
                .Parameters.AddWithValue("@i_ncuota", CDbl(txtncuotas.Text).ToString("########0"))
                .Parameters.AddWithValue("@i_observacion", txtobservacion.Text)

                '.Parameters.AddWithValue("@i_usuario", sgUsuario)
                '.Parameters.AddWithValue("@i_maquina", sgMaquina)
            End With
            oRs = oComand.ExecuteReader()
            Tabla.Rows.Clear()
            If oRs.HasRows = True Then
                While oRs.Read
                    Tabla.Rows.Add(oRs.Item("sel"), oRs.Item("clave"), oRs.Item("identificacion"), oRs.Item("nombre"), oRs.Item("departamento"), _
                                   oRs.Item("cargo"), oRs.Item("base"), oRs.Item("por"), oRs.Item("valor"), Double.Parse(oRs.Item("ncuotas").ToString()), oRs.Item("cuotas"), _
                                   oRs.Item("res"), oRs.Item("fecha"), oRs.Item("corte"), oRs.Item("observacion"), oRs.Item("iddepartamento"), _
                                   oRs.Item("idcargo"))
                End While
            End If

            chktodos.Visible = True
            chktodos.Checked = True

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
            operacion = 1
        Catch ex As Exception
            XtraMessageBox.Show("Facturas Procesadas: Error " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub cmbCompania_EditValueChanged(sender As Object, e As EventArgs) Handles cmbCompania.EditValueChanged
        sgCompaniaForm = cmbCompania.EditValue

        dtpfecha_proceso.Value = fecha_proceso(sgCompaniaForm)
        lwdfecha_proceso = dtpfecha_proceso.Value
    End Sub

    Private Sub GridView1_PrintInitialize(sender As Object, e As PrintInitializeEventArgs) Handles GridView1.PrintInitialize
        Dim pb As PrintingSystemBase = CType(e.PrintingSystem, PrintingSystemBase)
        Dim Titulo As String = ""
        'If Tabla
        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Header.Content.Clear()
        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Footer.Content.Clear()
        pb.PageSettings.Landscape = True
        pb.PageSettings.RightMargin = 2
        pb.PageSettings.LeftMargin = 2
        'pb.PageSettings.TopMargin = 5
        'pb.PageSettings.BottomMargin = 5

        If txtnumero.Text.Trim.Length = 0 Then
            Titulo = "CxC Masivo  " '& " Tipo Valor: " & CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).Name
        ElseIf txtnumero.Text = 0 Then
            Titulo = "CxC Masivo  " ' & " Tipo Valor: " & CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).Name
        Else
            Titulo = "CxC Masivo # " & txtnumero.Text '& " Tipo Valor: " & CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).Name
        End If
        pb.Document.AutoFitToPagesWidth = 1

        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Header.LineAlignment = BrickAlignment.Far
        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Footer.LineAlignment = BrickAlignment.Near

        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Header.Content.AddRange({"Periodo:" & Format(dtpfecha_proceso.Value, "dd/MM/yyyy"), Titulo, " Tipo Valor: " & CType(cbofcobro.Items(cbofcobro.SelectedIndex), ClsItemsData).Name})
        'If Tabla_Rubro.Rows.Count > 0 Then
        '    If IsNothing(GridView2.GetDataRow(sender.FocusedRowHandle)("Archivo")) = False Then
        '        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Footer.Content.AddRange({"Fecha: [Date Printed][Time Printed]", "[Page # of Pages #]", GridView2.GetDataRow(sender.FocusedRowHandle)("Archivo")})
        '    Else
        '        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Footer.Content.AddRange({"Fecha: [Date Printed][Time Printed]", "[Page # of Pages #]", ""})

        '    End If
        'Else
        'CType(e.Link.PageHeaderFooter, PageHeaderFooter).Footer.Content.AddRange({"Fecha: [Date Printed][Time Printed]", "[Page # of Pages #]", ""})
        'End If
        CType(e.Link.PageHeaderFooter, PageHeaderFooter).Footer.Content.AddRange({"Fecha: [Date Printed][Time Printed]", "[Page # of Pages #]", " Usuario: " & sgUsuario})

    End Sub

    Private Sub GridView1_RowStyle(sender As Object, e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles GridView1.RowStyle
        'Dim View As GridView = sender
        'If (e.RowHandle >= 0) Then
        '    Dim editar As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns("Editar"))
        '    If editar = "0" Then
        '        e.Appearance.BackColor = Color.Tomato
        '        e.Appearance.BackColor2 = Color.SeaShell
        '        'e.Appearance.BorderColor = Color.Olive
        '    End If
        'End If
    End Sub

    Private Sub GridView1_ShowingEditor(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles GridView1.ShowingEditor
        'If GridView1.GetDataRow(sender.FocusedRowHandle)("Editar") = 0 Then
        '    e.Cancel = True
        'Else
        If New String() {"-", "Porcentaje", "Porcentaje", "Valor", "N.Cuotas", "TipoCobro", "Observacion"}.Contains(GridView1.FocusedColumn.FieldName) Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If
        ''End If
    End Sub

    Private Sub GridControl1_ProcessGridKey(sender As Object, e As KeyEventArgs) Handles GridControl1.ProcessGridKey
        Try



            ' Dim valor As Integer
            If e.KeyCode = Keys.Enter Then
                '  TryCast(GridControl1.FocusedView, ColumnView).Columns(1) = 1
                ' TryCast(GridControl1.FocusedView, ColumnView).FocusedRowHandle += 1
                If (GridView1.FocusedColumn.VisibleIndex = GridView1.VisibleColumns.Count - 1) Then
                    GridView1.FocusedRowHandle += 1
                    GridView1.FocusedColumn = GridView1.Columns(0)

                Else
                    'GridView1.SetFocusedValue()
                    'MsgBox(GridView1.FocusedColumn.VisibleIndex)
                    'valor = CInt(GridView1.FocusedColumn.VisibleIndex) + 2

                    GridView1.FocusedColumn = GridView1.Columns(GridView1.FocusedColumn.VisibleIndex + 2)
                    ' GridView1.FocusedColumn = GridView1.GetNearestCanFocusedColumn(GridView1.FocusedColumn)
                    'GridView1.get
                    ' GridControl1.SelectNextControl(GridControl1, e.Modifiers = Keys.None, False, False, True)
                End If
                e.Handled = True
            End If
            'Catch ex As Exception
            '    XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)

            'End Try
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub chktodos_CheckedChanged(sender As Object, e As EventArgs) Handles chktodos.CheckedChanged
        If chktodos.Checked = True Then
            For Each oReg As DataRow In Tabla.Rows
                oReg("-") = True
            Next
        Else
            For Each oReg As DataRow In Tabla.Rows
                oReg("-") = False
            Next
        End If
    End Sub

    Sub limpiar()
        Tabla.Rows.Clear()
        gluTipCXC.EditValue = IIf(CType(gluTipCXC.Properties.DataSource, Data.DataTable).Rows.Count > 0, gluTipCXC.Properties.GetKeyValue(0), gluTipCXC.Properties.GetKeyValue(-1))
        glucuentaxcobrar.EditValue = IIf(CType(glucuentaxcobrar.Properties.DataSource, Data.DataTable).Rows.Count > 0, glucuentaxcobrar.Properties.GetKeyValue(0), glucuentaxcobrar.Properties.GetKeyValue(-1))
        Call ubicar_combo(cbofcobro, 1)
        txtvalor.Text = "0.00"
        txtncuotas.Text = "1"
        txtobservacion.Text = ""
        mnuguardar.Enabled = True
        dtpfecha_proceso.Value = sgFecha
    End Sub

    Private Sub mnubuscar_Click(sender As Object, e As EventArgs) Handles mnubuscar.Click
        Try
            If txtnumero.Text.Trim.Length = 0 Or txtnumero.Enabled = False Then
                XtraMessageBox.Show("Ingrese Número a Consultar..", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call limpiar()
                'LayoutControlGroup5.Enabled = True
                txtnumero.Text = ""
                txtnumero.Enabled = True
                txtnumero.Focus()
                mnuguardar.Enabled = False
                btnValidar.Visible = False
            Else
                If load_cuentas_cobrar() = True Then
                    SeteoBoton(False)
                    chktodos.Visible = True
                    'Call table()
                    'mnuguardar.Enabled = False
                    'mnuempleados.Enabled = False
                    'txtnumero.Enabled = False
                Else
                    txtnumero.Text = ""
                    txtnumero.Enabled = False
                    limpiar()
                    mnuguardar.Enabled = True
                    mnuempleados.Enabled = True
                End If
            End If
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ImportarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportExcelOption.Click
        Dim openFileDialog As New OpenFileDialog()

        hasEmptyField = False
       

        SeteoBoton(True)


        Try
            openFileDialog.Filter = "Archivos de Excel|*.xls;*.xlsx; *.xlsm"
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                Dim excelApp As New Microsoft.Office.Interop.Excel.Application()
                Dim workbook As Microsoft.Office.Interop.Excel.Workbook = excelApp.Workbooks.Open(openFileDialog.FileName)
                Dim worksheet As Microsoft.Office.Interop.Excel.Worksheet = DirectCast(workbook.Sheets(1), Excel.Worksheet)

                'Dim worksheet As Excel.IXLWorksheet = workbook.Worksheet(sheetName)
                'Dim dataTable As DataTable = worksheet.Table(tableName).AsNativeDataTable()


                ' Limpiar datos previos en el DataGridView
                GridView1.Columns.Clear()
                GridControl1.DataSource = Nothing
                dt.Clear()
                dt.Columns.Clear() 'Limpia también las columnas del DataTable

                ' Agregar columnas al DataTable
                For col As Integer = 1 To worksheet.UsedRange.Columns.Count
                    Dim colName As String = worksheet.Cells(1, col).Value
                    dt.Columns.Add(colName)
                Next

                ' Agregar una columna de estado de datos que se usara en la verificacion
                dt.Columns.Add("Estado Datos")

                ' Cargar datos al DataTable, omitiendo filas en blanco
                For row As Integer = 2 To worksheet.UsedRange.Rows.Count
                    Dim isEmptyRow As Boolean = True
                    For col As Integer = 1 To worksheet.UsedRange.Columns.Count
                        Dim cellValue As Object = worksheet.Cells(row, col).Value
                        If cellValue IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(cellValue.ToString()) Then
                            isEmptyRow = False
                            Exit For
                        Else
                            hasEmptyField = True ' Marcar la fila como que tiene al menos un campo vacío

                        End If
                    Next

                    If Not isEmptyRow Then
                        Dim newRow As System.Data.DataRow = dt.NewRow()
                        For col As Integer = 1 To worksheet.UsedRange.Columns.Count
                            newRow(col - 1) = worksheet.Cells(row, col).Value
                        Next
                        dt.Rows.Add(newRow)
                    End If
                Next

                'Validacion para saber si hay campos vacios
                If hasEmptyField Then
                    XtraMessageBox.Show("Error: " + "Existen campos vacios en el excel, revisar antes de enviar", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                End If
                GridControl1.DataSource = dt

                ' Desseleccionar la primera fila después de cargar los datos
                GridView1.ClearSelection()
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.OptionsView.ShowGroupPanel = False


                'estableciendo el dgv esto para evitar errores al cargar el excel y realizar modificaciones no establecidas
                'GridView1.Editable = True

                'DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
                'DataGridView1.EnableHeadersVisualStyles = False
                'DataGridView1.AllowUserToOrderColumns = False
                'DataGridView1.Dock = DockStyle.Fill


                ''genera copia del excel subido a la base de datos

                'Dim destDirectory As String = "C:\Users\USER02\Downloads" ' Cambia esto a la ubicación deseada
                ''aqui se especifica el nombre que tendra la copia del archivo
                'Dim excelFileName As String = "prueba.xlsx"
                'Dim copiedExcelFilePath As String = Path.Combine(destDirectory, excelFileName)

                ' Obtener la ruta de la carpeta destino

                ' Copiar el archivo Excel al directorio de destino
                'File.Copy(openFileDialog.FileName, copiedExcelFilePath, True)

                'visibiliza el check
                chktodos.Visible = False

                excelApp.Quit()

                btnValidar.Visible = True

                ' gluTipCXC.Enabled = False
                '  glucuentaxcobrar.Enabled = False
                cbofcobro.Enabled = False
                txtvalor.Enabled = False
                txtncuotas.Enabled = False
                dtpfecha_proceso.Enabled = False

            Else
                mnuCancelar.PerformClick()
            End If


        Catch ex As Exception
            XtraMessageBox.Show("Error: " + "No se encontro la Tabla con el nombre Tabla Sistema", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            mnuCancelar.PerformClick()
        End Try

    End Sub

    Private Sub mnuCancelar_Click(sender As Object, e As EventArgs) Handles mnuCancelar.Click
        Try
            ' Tabla.Rows.Clear()
            Call limpiar()


            SeteoBoton(False)
            chktodos.Visible = False
            LayoutControlGroup5.Enabled = True
            btnValidar.Visible = False
            GridView1.Columns.Clear()
            txtnumero.Text = ""
            txtnumero.Enabled = False
            operacion = 0
            Validado = False

            gluTipCXC.Enabled = True
            glucuentaxcobrar.Enabled = True
            cbofcobro.Enabled = True
            txtvalor.Enabled = True
            txtncuotas.Enabled = True
            dtpfecha_proceso.Enabled = True

            Call table()

            ' mnuempleados.Enabled = True
            'mnuguardar.Enabled = True
        Catch ex As Exception
            XtraMessageBox.Show("Error: " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub

    Private Sub btnValidar_Click(sender As Object, e As EventArgs) Handles btnValidar.Click

        Dim dto As New DataTable


        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        'Dim ierror As Integer, smensaje As String
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing

        'Call table()

        Try
            Validado = True
            For Each row As DataRow In dt.Rows

                Dim cedulaValue As Object = row("Cedula")
                Dim tipocxc As Object = row("Tipo_CxC")
                Dim cxc As Object = row("CxC")
                Dim valor As Object = row("Valor")
                Dim fecha As Object = row("Fecha")
                Dim observacion As Object = row("Observacion")

                If cedulaValue IsNot Nothing AndAlso Not DBNull.Value.Equals(cedulaValue) Then
                    ' Ahora puedes usar cedulaValue en tu consulta SQL o para otros fines.
                    ' ...

                    ' Ahora puedes usar el valor de "id" en tu consulta SQL o para otros fines.

                    If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
                    ' Ahora puedes usar el valor de "id" en tu consulta SQL o para otros fines.

                    oComand = New SqlCommand
                    With oComand

                        .CommandText = "nuevo"
                        .Connection = oCon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@Cedula", CType(cedulaValue, String))
                        .Parameters.AddWithValue("@tipocxc", tipocxc)
                        .Parameters.AddWithValue("@CxC", cxc)
                        .Parameters.AddWithValue("@valor", valor)
                        .Parameters.AddWithValue("@fecha", Convert.ToDateTime(fecha))
                        .Parameters.AddWithValue("@observacion", observacion)
                        .Parameters.Add("@ErrorMsg", SqlDbType.VarChar, 200)
                        .Parameters("@ErrorMsg").Direction = ParameterDirection.Output

                        '.Parameters.AddWithValue("@i_usuario", sgUsuario)
                        '.Parameters.AddWithValue("@i_maquina", sgMaquina)
                    End With

                    'oComand.ExecuteNonQuery()
                    ' Rellena el DataGridView con los datos obtenidos
                    Dim dte As New DataTable()

                    oRs = oComand.ExecuteReader()

                    ' dte = oRs
                    'Tabla.Rows.Clear()

                    Dim number As Integer
                    number = oRs.FieldCount
                    '  Dim rowCount As Integer = 0
                    Dim fila As Integer = 1 ' Puedes establecer el número de fila inicial aquí

               Dim rowCount As Integer = 0
                    If oRs.HasRows Then
                        While oRs.Read

                            Tabla.Rows.Add(
                                (1),
                                oRs.Item("Compania"),
                                oRs.Item("Clave"),
                                oRs.Item("Identificacion"),
                                oRs.Item("Nombre"),
                                oRs.Item("Departamento"),
                                oRs.Item("Cargo"),
                                oRs.Item("Tipo CxC Descripcion"),
                                oRs.Item("CxC"),
                                oRs.Item("Valor"),
                                (0),
                                oRs.Item("Valor"),
                                (1),
                                (0),
                                (0),
                                oRs.Item("Fecha"),
                                (2),
                                oRs.Item("Observacion"),
                                oRs.Item("iddepartamento"),
                                oRs.Item("idcargo"),
                                oRs.Item("Tipo CxC"),
                                oRs.Item("CxC Codigo"))

                            'rowCount += 1

                        End While

                    End If
                    

                End If


                ' Verifica si hubo un error
                Dim mensajeDeError As String = oComand.Parameters("@ErrorMsg").Value
                If Not String.IsNullOrEmpty(mensajeDeError) Then
                    XtraMessageBox.Show("Error: " + mensajeDeError, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Validado = False
                    row("Estado Datos") = mensajeDeError ' Sale del metodo en caso de error
                End If

                

            Next

            oRs.Close()
            oCon.Close()
            oComand.Dispose()



            operacion = 2

            If Validado Then
                Call SetDGV()
                OcultarCamposDGV()

                XtraMessageBox.Show("Datos validados correctaente", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub OcultarCamposDGV()
        GridView1.Columns("Observacion").Width = 150
        ' GridView1.Columns("Editar").Visible = False
        GridView1.Columns("iddepartamento").Visible = False
        GridView1.Columns("idcargo").Visible = False
        GridView1.Columns("Base").Visible = False
        GridView1.Columns("Porcentaje").Visible = False
        GridView1.Columns("Cuotas").Visible = False
        GridView1.Columns("S.Cuotas").Visible = False
        GridView1.Columns("TipoCobro").Visible = False
        GridView1.Columns("tipocxc").Visible = False
        GridView1.Columns("cxc").Visible = False
        GridView1.Columns("N.Cuotas").Visible = False
    End Sub

    Private Sub SetDGV()

        GridView1.Columns.Clear()
        GridView1.OptionsView.ColumnAutoWidth = False
        GridView1.OptionsPrint.AutoWidth = False
        GridView1.BestFitColumns()

        GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
        GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
        GridControl1.DataSource = Nothing
        GridView1.OptionsView.ShowGroupPanel = False
        GridControl1.DataSource = Tabla
        GridView1.Columns("-").Width = 20
        'GridView1.Columns("Clave").Visible = True
        GridView1.Columns("Ruc").Width = 80
        GridView1.Columns("Nombre").Width = 150
        GridView1.Columns("Departamento").Width = 100
        GridView1.Columns("Cargo").Width = 80
        GridView1.Columns("Base").Width = 90
        GridView1.Columns("Porcentaje").Width = 90
        GridView1.Columns("Valor").Width = 90
        GridView1.Columns("N.Cuotas").Width = 90
        GridView1.Columns("Cuotas").Width = 90
        GridView1.Columns("S.Cuotas").Width = 90
        GridView1.Columns("Fecha").Width = 90
        GridView1.Columns("TipoCobro").Width = 120

        GridView1.Columns("Observacion").Width = 150
        ' GridView1.Columns("Editar").Visible = False
        GridView1.Columns("iddepartamento").Visible = False
        GridView1.Columns("idcargo").Visible = False
        GridView1.Columns("Base").Visible = False
        GridView1.Columns("Porcentaje").Visible = False
        GridView1.Columns("iddepartamento").Visible = False

        GridView1.OptionsView.ShowFooter = True
        GridView1.Columns("TipoCobro").OptionsColumn.AllowEdit = True
        GridView1.Columns("Valor").Summary.Add(DevExpress.Data.SummaryItemType.Sum, "Valor", "{0:#.##}")
        GridView1.Columns("tipocxc").Width = 120
        GridView1.Columns("cxc").Width = 120
        Dim rilperiodo As New RepositoryItemGridLookUpEdit()
        rilperiodo.DataSource = Tabla_Periodo
        rilperiodo.ValueMember = "Clave"
        rilperiodo.DisplayMember = "Descripcion" ' "Descripcion"
        rilperiodo.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
        'rilcentro_costo.View.Column()
        GridView1.Columns("TipoCobro").ColumnEdit = rilperiodo
        GridView1.OptionsView.ShowAutoFilterRow = True
    End Sub

    Private Sub gridView1_CustomDrawCell(sender As Object, e As DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventArgs) Handles GridView1.CustomDrawCell
        If e.Column.FieldName = "Estado Datos" AndAlso e.RowHandle >= 0 Then
            Dim valorCelda As String = GridView1.GetRowCellValue(e.RowHandle, "Estado Datos").ToString()

            If Not String.IsNullOrWhiteSpace(valorCelda) Then
                e.Appearance.BackColor = Color.Red
                e.Appearance.ForeColor = Color.White
            End If
        End If
    End Sub


    Private Sub AnulacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AnulacionesToolStripMenuItem.Click

    End Sub
End Class
