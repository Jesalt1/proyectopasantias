﻿Imports System.Data.SqlClient
Imports libreria
Imports DevExpress.XtraEditors

Public Class frmdetalle
    Dim Tabla As New DataTable("tabla")
    Dim lanio As Integer, lmes As Integer, ltipo As String, lcedula As String
    Sub New(ianio As Integer, imes As Integer, itipo As String, icedula As String)
        lanio = ianio
        lmes = imes
        ltipo = itipo
        lcedula = icedula
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        Call llenar_datos(lanio, lmes, ltipo, lcedula)
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Sub table()

        Try



            Tabla.Columns.Clear()
            Tabla.Rows.Clear()
            Tabla.Columns.Add(New DataColumn("No", GetType(Integer)))
            Tabla.Columns.Add(New DataColumn("Emisora", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Localidad", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Fecha", GetType(Date)))
            Tabla.Columns.Add(New DataColumn("Tipo", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Documento", GetType(String)))
            Tabla.Columns.Add(New DataColumn("Valor", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("Saldo", GetType(Double)))
            Tabla.Columns.Add(New DataColumn("Observacion", GetType(String)))
            GridView1.Columns.Clear()
            GridView1.OptionsView.ColumnAutoWidth = False
            GridView1.OptionsPrint.AutoWidth = False
            GridView1.BestFitColumns()
            GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
            GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
            GridControl1.DataSource = Nothing
            GridView1.OptionsView.ShowGroupPanel = False
            GridControl1.DataSource = Tabla
            GridView1.Columns("No").Width = 30
            GridView1.Columns("Emisora").Width = 100
            GridView1.Columns("Localidad").Width = 100
            GridView1.Columns("Fecha").Width = 80
            GridView1.Columns("Tipo").Width = 50
            GridView1.Columns("Documento").Width = 80
            GridView1.Columns("Valor").Width = 90
            GridView1.Columns("Saldo").Width = 90
            GridView1.Columns("Observacion").Width = 150
            GridView1.OptionsView.ShowFooter = True
            GridView1.Columns("Emisora").Summary.Add(DevExpress.Data.SummaryItemType.Count, "Emisora", "TOTAL")
            GridView1.Columns("Valor").Summary.Add(DevExpress.Data.SummaryItemType.Sum, "Valor", "{0:#.##}")
            GridView1.Columns("Saldo").Summary.Add(DevExpress.Data.SummaryItemType.Sum, "Saldo", "{0:#.##}")

        Catch ex As Exception
            XtraMessageBox.Show("Procesar: Error " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
      
    End Sub
    Sub llenar_datos(anio As Integer, mes As Integer, tipo As String, cedula As String)
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader

        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            oComand = New SqlCommand
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
            With oComand
                .CommandTimeout = 0
                .CommandText = "ROLSp_Cuentas_Cobrar_Migrador"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "grid_det")
                .Parameters.AddWithValue("@i_compania", sgCompania)
                .Parameters.AddWithValue("@i_anio", anio)
                .Parameters.AddWithValue("@i_mes", mes)
                .Parameters.AddWithValue("@i_tipo", tipo)
                .Parameters.AddWithValue("@i_cedula", cedula)
            End With
            Call table()

            ' Tabla.Rows.Clear()
            oRs = oComand.ExecuteReader()
            If oRs.HasRows = True Then
                While oRs.Read
                    'GridView1.Columns("No").Width = 20
                    'GridView1.Columns("Emisora").Width = 100
                    'GridView1.Columns("Localidad").Width = 100
                    'GridView1.Columns("Fecha").Width = 80
                    'GridView1.Columns("Tipo").Width = 50
                    'GridView1.Columns("Documento").Width = 80
                    'GridView1.Columns("Valor").Width = 90
                    'GridView1.Columns("Saldo").Width = 90
                    'GridView1.Columns("Observacion").Width = 150

                    Tabla.Rows.Add(oRs.Item("secuencia"), oRs.Item("emision"), oRs.Item("localidad"), oRs.Item("fecha"), _
                                    oRs.Item("tipo"), oRs.Item("documento"), oRs.Item("valor"), oRs.Item("saldo"), oRs.Item("observacion"))
                    ', oRs.Item("fc_valor"), "01/01/1900", _
                    '                                   1, "")
                End While
            End If
            GridView1.Columns("No").OptionsColumn.AllowEdit = False
            GridView1.Columns("Emisora").OptionsColumn.AllowEdit = False
            GridView1.Columns("Localidad").OptionsColumn.AllowEdit = False
            GridView1.Columns("Fecha").OptionsColumn.AllowEdit = False
            GridView1.Columns("Tipo").OptionsColumn.AllowEdit = False
            GridView1.Columns("Documento").OptionsColumn.AllowEdit = False
            GridView1.Columns("Valor").OptionsColumn.AllowEdit = False

            GridView1.Columns("Saldo").OptionsColumn.AllowEdit = False
            GridView1.Columns("Observacion").OptionsColumn.AllowEdit = False

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing


        Catch ex As Exception
            XtraMessageBox.Show("Procesar: Error " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Dispose()
    End Sub
End Class