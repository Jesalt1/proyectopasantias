﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEmpleados
    Inherits DevExpress.XtraEditors.XtraForm

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.mnsForma = New System.Windows.Forms.MenuStrip()
        Me.mnunuevo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnumodificar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuconsultar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuanular = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnugrabar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnucancelar = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnusalir = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlfrente = New System.Windows.Forms.Panel()
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.GroupControl2 = New DevExpress.XtraEditors.GroupControl()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.TxtNombre = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.TxtCedula_Ruc = New System.Windows.Forms.TextBox()
        Me.txtcodigo = New System.Windows.Forms.TextBox()
        Me.cmbTipo = New System.Windows.Forms.ComboBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.pbximagen = New System.Windows.Forms.PictureBox()
        Me.butfoto = New System.Windows.Forms.Button()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.gluccosto = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridView5 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.txtcedulacta = New System.Windows.Forms.TextBox()
        Me.txtemail = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.PanelControl4 = New DevExpress.XtraEditors.PanelControl()
        Me.chkempemfcatastrofica = New System.Windows.Forms.CheckBox()
        Me.chkbono = New System.Windows.Forms.CheckBox()
        Me.chkacredita = New System.Windows.Forms.CheckBox()
        Me.chkPagomensualBeneficios = New System.Windows.Forms.CheckBox()
        Me.chkprueba = New System.Windows.Forms.CheckBox()
        Me.chkestado = New System.Windows.Forms.CheckBox()
        Me.chkbeneficios = New System.Windows.Forms.CheckBox()
        Me.chkpagafondo = New System.Windows.Forms.CheckBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtctacble = New System.Windows.Forms.TextBox()
        Me.txtcontacto = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtobservacion = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtpordiscapacidad = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtbiometrico = New System.Windows.Forms.TextBox()
        Me.chkDiscapacidad = New System.Windows.Forms.CheckBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.cmbTcalculoIR = New System.Windows.Forms.ComboBox()
        Me.txtcodigo_cargo = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtMatriculaPortuaria = New System.Windows.Forms.TextBox()
        Me.cmbtipoLiqui = New System.Windows.Forms.ComboBox()
        Me.txtNumCta = New System.Windows.Forms.TextBox()
        Me.txtCarnetIess = New System.Windows.Forms.TextBox()
        Me.dtpfechaTermiContrato = New System.Windows.Forms.DateTimePicker()
        Me.dtpfechaNacimiento = New System.Windows.Forms.DateTimePicker()
        Me.dtpfechaEgreso = New System.Windows.Forms.DateTimePicker()
        Me.txtTipoSangre = New System.Windows.Forms.TextBox()
        Me.cmbestadocivil = New System.Windows.Forms.ComboBox()
        Me.cmbclaseEmpleado = New System.Windows.Forms.ComboBox()
        Me.cmbTipoCta = New System.Windows.Forms.ComboBox()
        Me.txtcedMilitar = New System.Windows.Forms.TextBox()
        Me.dtpfechaIngreso = New System.Windows.Forms.DateTimePicker()
        Me.cmbsexo = New System.Windows.Forms.ComboBox()
        Me.txtTelefono = New System.Windows.Forms.TextBox()
        Me.TxtDireccion = New System.Windows.Forms.TextBox()
        Me.txtlugarNaci = New System.Windows.Forms.TextBox()
        Me.txtCodCiudad = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.GroupControl5 = New DevExpress.XtraEditors.GroupControl()
        Me.txtalimentacion = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.chkpagootro = New System.Windows.Forms.CheckBox()
        Me.txtMoviQuincenal = New System.Windows.Forms.TextBox()
        Me.txtSueldoExtraMen = New System.Windows.Forms.TextBox()
        Me.txtSueldoBasicoMen = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbltitulo = New System.Windows.Forms.TextBox()
        Me.txttitulo = New System.Windows.Forms.TextBox()
        Me.txtestudios = New System.Windows.Forms.TextBox()
        Me.lblestudios = New System.Windows.Forms.TextBox()
        Me.lblnacionalidad = New System.Windows.Forms.TextBox()
        Me.txtnacionalidad = New System.Windows.Forms.TextBox()
        Me.lblcargo = New System.Windows.Forms.TextBox()
        Me.txtcargo = New System.Windows.Forms.TextBox()
        Me.lbldepartamento = New System.Windows.Forms.TextBox()
        Me.txtdepartamento = New System.Windows.Forms.TextBox()
        Me.lblsector = New System.Windows.Forms.TextBox()
        Me.txtsector = New System.Windows.Forms.TextBox()
        Me.lblsectorial = New System.Windows.Forms.TextBox()
        Me.txtcodsectorial = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.BtnModificar = New System.Windows.Forms.Button()
        Me.GrdCargaFamiliar = New DevExpress.XtraGrid.GridControl()
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.GridView4 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.BtnQuitarF = New System.Windows.Forms.Button()
        Me.BtnAceptarF = New System.Windows.Forms.Button()
        Me.GroupControl4 = New DevExpress.XtraEditors.GroupControl()
        Me.chkemfcatastrifica = New System.Windows.Forms.CheckBox()
        Me.chkimprenta = New System.Windows.Forms.CheckBox()
        Me.chkutilidad = New System.Windows.Forms.CheckBox()
        Me.chkaporta = New System.Windows.Forms.CheckBox()
        Me.dtpfechanac = New System.Windows.Forms.DateTimePicker()
        Me.chkestadoFamiliar = New System.Windows.Forms.CheckBox()
        Me.cmbsexoFamiliar = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtNombreFamiliar = New System.Windows.Forms.TextBox()
        Me.cmbtipoFamiliar = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.XtraTabPage4 = New DevExpress.XtraTab.XtraTabPage()
        Me.GridControl2 = New DevExpress.XtraGrid.GridControl()
        Me.GridView3 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.pnlfondo = New System.Windows.Forms.Panel()
        Me.chkInactivos = New System.Windows.Forms.CheckBox()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.txtbus = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.optTodos = New System.Windows.Forms.RadioButton()
        Me.optPorNombre = New System.Windows.Forms.RadioButton()
        Me.optPorCodigo = New System.Windows.Forms.RadioButton()
        Me.optPorcedula = New System.Windows.Forms.RadioButton()
        Me.DefaultLookAndFeel1 = New DevExpress.LookAndFeel.DefaultLookAndFeel(Me.components)
        Me.FormAssistant1 = New DevExpress.XtraBars.FormAssistant()
        Me.GroupControl1 = New DevExpress.XtraEditors.GroupControl()
        Me.plcfiltro = New DevExpress.XtraEditors.PanelControl()
        Me.cmbCompania = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.lblcompania = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.mnsForma.SuspendLayout()
        Me.pnlfrente.SuspendLayout()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GroupControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl2.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        CType(Me.pbximagen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        CType(Me.gluccosto.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl4.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        CType(Me.GroupControl5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl5.SuspendLayout()
        Me.XtraTabPage3.SuspendLayout()
        CType(Me.GrdCargaFamiliar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GroupControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl4.SuspendLayout()
        Me.XtraTabPage4.SuspendLayout()
        CType(Me.GridControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfondo.SuspendLayout()
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupControl1.SuspendLayout()
        CType(Me.plcfiltro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.plcfiltro.SuspendLayout()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnsForma
        '
        Me.mnsForma.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.mnsForma.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnunuevo, Me.mnumodificar, Me.mnuconsultar, Me.mnuanular, Me.mnugrabar, Me.mnucancelar, Me.mnusalir})
        Me.mnsForma.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.mnsForma.Location = New System.Drawing.Point(0, 0)
        Me.mnsForma.Name = "mnsForma"
        Me.mnsForma.Size = New System.Drawing.Size(860, 28)
        Me.mnsForma.TabIndex = 3
        Me.mnsForma.Text = "MenuStrip1"
        '
        'mnunuevo
        '
        Me.mnunuevo.Image = Global.Empleados.My.Resources.Resources.application_add
        Me.mnunuevo.Name = "mnunuevo"
        Me.mnunuevo.Size = New System.Drawing.Size(81, 24)
        Me.mnunuevo.Text = "&Ingresar"
        '
        'mnumodificar
        '
        Me.mnumodificar.Image = Global.Empleados.My.Resources.Resources.application_form_edit
        Me.mnumodificar.Name = "mnumodificar"
        Me.mnumodificar.Size = New System.Drawing.Size(90, 24)
        Me.mnumodificar.Text = "&Modificar"
        '
        'mnuconsultar
        '
        Me.mnuconsultar.Image = Global.Empleados.My.Resources.Resources.application_form_magnify
        Me.mnuconsultar.Name = "mnuconsultar"
        Me.mnuconsultar.Size = New System.Drawing.Size(90, 24)
        Me.mnuconsultar.Text = "C&onsultar"
        '
        'mnuanular
        '
        Me.mnuanular.Image = Global.Empleados.My.Resources.Resources.application_delete
        Me.mnuanular.Name = "mnuanular"
        Me.mnuanular.Size = New System.Drawing.Size(74, 24)
        Me.mnuanular.Text = "Anular"
        '
        'mnugrabar
        '
        Me.mnugrabar.Enabled = False
        Me.mnugrabar.Image = Global.Empleados.My.Resources.Resources.table_save
        Me.mnugrabar.Name = "mnugrabar"
        Me.mnugrabar.Size = New System.Drawing.Size(81, 24)
        Me.mnugrabar.Text = "&Guardar"
        '
        'mnucancelar
        '
        Me.mnucancelar.Enabled = False
        Me.mnucancelar.Image = Global.Empleados.My.Resources.Resources.stock_no
        Me.mnucancelar.Name = "mnucancelar"
        Me.mnucancelar.Size = New System.Drawing.Size(85, 24)
        Me.mnucancelar.Text = "&Cancelar"
        '
        'mnusalir
        '
        Me.mnusalir.Image = Global.Empleados.My.Resources.Resources.stock_exit
        Me.mnusalir.Name = "mnusalir"
        Me.mnusalir.Size = New System.Drawing.Size(61, 24)
        Me.mnusalir.Text = "&Salir"
        '
        'pnlfrente
        '
        Me.pnlfrente.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlfrente.Controls.Add(Me.GridControl1)
        Me.pnlfrente.Location = New System.Drawing.Point(12, 100)
        Me.pnlfrente.Name = "pnlfrente"
        Me.pnlfrente.Size = New System.Drawing.Size(733, 570)
        Me.pnlfrente.TabIndex = 4
        '
        'GridControl1
        '
        Me.GridControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridControl1.Location = New System.Drawing.Point(0, 0)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(733, 570)
        Me.GridControl1.TabIndex = 0
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        '
        'GroupControl2
        '
        Me.GroupControl2.Controls.Add(Me.PanelControl3)
        Me.GroupControl2.Controls.Add(Me.PanelControl1)
        Me.GroupControl2.Controls.Add(Me.XtraTabControl1)
        Me.GroupControl2.Location = New System.Drawing.Point(3, 0)
        Me.GroupControl2.Name = "GroupControl2"
        Me.GroupControl2.Size = New System.Drawing.Size(741, 561)
        Me.GroupControl2.TabIndex = 0
        Me.GroupControl2.Text = "Información del Empleado"
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.TxtNombre)
        Me.PanelControl3.Controls.Add(Me.Label40)
        Me.PanelControl3.Controls.Add(Me.Label41)
        Me.PanelControl3.Controls.Add(Me.TxtCedula_Ruc)
        Me.PanelControl3.Controls.Add(Me.txtcodigo)
        Me.PanelControl3.Controls.Add(Me.cmbTipo)
        Me.PanelControl3.Controls.Add(Me.Label42)
        Me.PanelControl3.Location = New System.Drawing.Point(3, 18)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(580, 92)
        Me.PanelControl3.TabIndex = 3
        '
        'TxtNombre
        '
        Me.TxtNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtNombre.Location = New System.Drawing.Point(64, 54)
        Me.TxtNombre.Name = "TxtNombre"
        Me.TxtNombre.Size = New System.Drawing.Size(512, 21)
        Me.TxtNombre.TabIndex = 6
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(7, 6)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(44, 13)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "Codigo:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(5, 63)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(48, 13)
        Me.Label41.TabIndex = 1
        Me.Label41.Text = "Nombre:"
        '
        'TxtCedula_Ruc
        '
        Me.TxtCedula_Ruc.Location = New System.Drawing.Point(191, 30)
        Me.TxtCedula_Ruc.MaxLength = 13
        Me.TxtCedula_Ruc.Name = "TxtCedula_Ruc"
        Me.TxtCedula_Ruc.Size = New System.Drawing.Size(195, 21)
        Me.TxtCedula_Ruc.TabIndex = 5
        '
        'txtcodigo
        '
        Me.txtcodigo.Location = New System.Drawing.Point(64, 6)
        Me.txtcodigo.Name = "txtcodigo"
        Me.txtcodigo.Size = New System.Drawing.Size(125, 21)
        Me.txtcodigo.TabIndex = 4
        '
        'cmbTipo
        '
        Me.cmbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTipo.FormattingEnabled = True
        Me.cmbTipo.Location = New System.Drawing.Point(64, 30)
        Me.cmbTipo.Name = "cmbTipo"
        Me.cmbTipo.Size = New System.Drawing.Size(125, 21)
        Me.cmbTipo.TabIndex = 3
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(7, 35)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(27, 13)
        Me.Label42.TabIndex = 2
        Me.Label42.Text = "Tipo"
        '
        'PanelControl1
        '
        Me.PanelControl1.Controls.Add(Me.PanelControl2)
        Me.PanelControl1.Controls.Add(Me.butfoto)
        Me.PanelControl1.Location = New System.Drawing.Point(586, 16)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(155, 134)
        Me.PanelControl1.TabIndex = 2
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.pbximagen)
        Me.PanelControl2.Location = New System.Drawing.Point(2, 5)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(118, 127)
        Me.PanelControl2.TabIndex = 2
        '
        'pbximagen
        '
        Me.pbximagen.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pbximagen.Location = New System.Drawing.Point(2, 2)
        Me.pbximagen.Name = "pbximagen"
        Me.pbximagen.Size = New System.Drawing.Size(114, 123)
        Me.pbximagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbximagen.TabIndex = 0
        Me.pbximagen.TabStop = False
        '
        'butfoto
        '
        Me.butfoto.Image = Global.Empleados.My.Resources.Resources.camara_de_fotos
        Me.butfoto.Location = New System.Drawing.Point(121, 108)
        Me.butfoto.Name = "butfoto"
        Me.butfoto.Size = New System.Drawing.Size(32, 23)
        Me.butfoto.TabIndex = 1
        Me.butfoto.UseVisualStyleBackColor = True
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Location = New System.Drawing.Point(1, 136)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(715, 420)
        Me.XtraTabControl1.TabIndex = 1
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2, Me.XtraTabPage3, Me.XtraTabPage4})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.gluccosto)
        Me.XtraTabPage1.Controls.Add(Me.Label46)
        Me.XtraTabPage1.Controls.Add(Me.Label45)
        Me.XtraTabPage1.Controls.Add(Me.txtcedulacta)
        Me.XtraTabPage1.Controls.Add(Me.txtemail)
        Me.XtraTabPage1.Controls.Add(Me.Label43)
        Me.XtraTabPage1.Controls.Add(Me.PanelControl4)
        Me.XtraTabPage1.Controls.Add(Me.Label38)
        Me.XtraTabPage1.Controls.Add(Me.txtctacble)
        Me.XtraTabPage1.Controls.Add(Me.txtcontacto)
        Me.XtraTabPage1.Controls.Add(Me.Label37)
        Me.XtraTabPage1.Controls.Add(Me.Label36)
        Me.XtraTabPage1.Controls.Add(Me.txtobservacion)
        Me.XtraTabPage1.Controls.Add(Me.Label35)
        Me.XtraTabPage1.Controls.Add(Me.txtpordiscapacidad)
        Me.XtraTabPage1.Controls.Add(Me.Label34)
        Me.XtraTabPage1.Controls.Add(Me.txtbiometrico)
        Me.XtraTabPage1.Controls.Add(Me.chkDiscapacidad)
        Me.XtraTabPage1.Controls.Add(Me.Label33)
        Me.XtraTabPage1.Controls.Add(Me.cmbTcalculoIR)
        Me.XtraTabPage1.Controls.Add(Me.txtcodigo_cargo)
        Me.XtraTabPage1.Controls.Add(Me.Label32)
        Me.XtraTabPage1.Controls.Add(Me.txtMatriculaPortuaria)
        Me.XtraTabPage1.Controls.Add(Me.cmbtipoLiqui)
        Me.XtraTabPage1.Controls.Add(Me.txtNumCta)
        Me.XtraTabPage1.Controls.Add(Me.txtCarnetIess)
        Me.XtraTabPage1.Controls.Add(Me.dtpfechaTermiContrato)
        Me.XtraTabPage1.Controls.Add(Me.dtpfechaNacimiento)
        Me.XtraTabPage1.Controls.Add(Me.dtpfechaEgreso)
        Me.XtraTabPage1.Controls.Add(Me.txtTipoSangre)
        Me.XtraTabPage1.Controls.Add(Me.cmbestadocivil)
        Me.XtraTabPage1.Controls.Add(Me.cmbclaseEmpleado)
        Me.XtraTabPage1.Controls.Add(Me.cmbTipoCta)
        Me.XtraTabPage1.Controls.Add(Me.txtcedMilitar)
        Me.XtraTabPage1.Controls.Add(Me.dtpfechaIngreso)
        Me.XtraTabPage1.Controls.Add(Me.cmbsexo)
        Me.XtraTabPage1.Controls.Add(Me.txtTelefono)
        Me.XtraTabPage1.Controls.Add(Me.TxtDireccion)
        Me.XtraTabPage1.Controls.Add(Me.txtlugarNaci)
        Me.XtraTabPage1.Controls.Add(Me.txtCodCiudad)
        Me.XtraTabPage1.Controls.Add(Me.Label31)
        Me.XtraTabPage1.Controls.Add(Me.Label30)
        Me.XtraTabPage1.Controls.Add(Me.Label29)
        Me.XtraTabPage1.Controls.Add(Me.Label21)
        Me.XtraTabPage1.Controls.Add(Me.Label20)
        Me.XtraTabPage1.Controls.Add(Me.Label19)
        Me.XtraTabPage1.Controls.Add(Me.Label18)
        Me.XtraTabPage1.Controls.Add(Me.Label17)
        Me.XtraTabPage1.Controls.Add(Me.Label16)
        Me.XtraTabPage1.Controls.Add(Me.Label15)
        Me.XtraTabPage1.Controls.Add(Me.Label14)
        Me.XtraTabPage1.Controls.Add(Me.Label13)
        Me.XtraTabPage1.Controls.Add(Me.Label12)
        Me.XtraTabPage1.Controls.Add(Me.Label11)
        Me.XtraTabPage1.Controls.Add(Me.Label10)
        Me.XtraTabPage1.Controls.Add(Me.Label9)
        Me.XtraTabPage1.Controls.Add(Me.Label8)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(713, 395)
        Me.XtraTabPage1.Text = "&Información General"
        '
        'gluccosto
        '
        Me.gluccosto.Location = New System.Drawing.Point(319, 325)
        Me.gluccosto.Name = "gluccosto"
        Me.gluccosto.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.gluccosto.Properties.View = Me.GridView5
        Me.gluccosto.Size = New System.Drawing.Size(379, 20)
        Me.gluccosto.TabIndex = 111
        '
        'GridView5
        '
        Me.GridView5.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView5.Name = "GridView5"
        Me.GridView5.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView5.OptionsView.ShowGroupPanel = False
        '
        'Label46
        '
        Me.Label46.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(267, 328)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(46, 13)
        Me.Label46.TabIndex = 110
        Me.Label46.Text = "C.Costo"
        '
        'Label45
        '
        Me.Label45.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(224, 190)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(60, 13)
        Me.Label45.TabIndex = 109
        Me.Label45.Text = "Cedula Cta"
        '
        'txtcedulacta
        '
        Me.txtcedulacta.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcedulacta.Location = New System.Drawing.Point(310, 184)
        Me.txtcedulacta.Name = "txtcedulacta"
        Me.txtcedulacta.Size = New System.Drawing.Size(108, 21)
        Me.txtcedulacta.TabIndex = 108
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(118, 302)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(580, 21)
        Me.txtemail.TabIndex = 107
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(28, 306)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(35, 13)
        Me.Label43.TabIndex = 106
        Me.Label43.Text = "E-Mail"
        '
        'PanelControl4
        '
        Me.PanelControl4.Controls.Add(Me.chkempemfcatastrofica)
        Me.PanelControl4.Controls.Add(Me.chkbono)
        Me.PanelControl4.Controls.Add(Me.chkacredita)
        Me.PanelControl4.Controls.Add(Me.chkPagomensualBeneficios)
        Me.PanelControl4.Controls.Add(Me.chkprueba)
        Me.PanelControl4.Controls.Add(Me.chkestado)
        Me.PanelControl4.Controls.Add(Me.chkbeneficios)
        Me.PanelControl4.Controls.Add(Me.chkpagafondo)
        Me.PanelControl4.Location = New System.Drawing.Point(14, 350)
        Me.PanelControl4.Name = "PanelControl4"
        Me.PanelControl4.Size = New System.Drawing.Size(690, 42)
        Me.PanelControl4.TabIndex = 105
        '
        'chkempemfcatastrofica
        '
        Me.chkempemfcatastrofica.AutoSize = True
        Me.chkempemfcatastrofica.Location = New System.Drawing.Point(359, 20)
        Me.chkempemfcatastrofica.Name = "chkempemfcatastrofica"
        Me.chkempemfcatastrofica.Size = New System.Drawing.Size(148, 17)
        Me.chkempemfcatastrofica.TabIndex = 8
        Me.chkempemfcatastrofica.Text = "Emfermedad Catastrofica"
        Me.chkempemfcatastrofica.UseVisualStyleBackColor = True
        '
        'chkbono
        '
        Me.chkbono.AutoSize = True
        Me.chkbono.Location = New System.Drawing.Point(528, 22)
        Me.chkbono.Name = "chkbono"
        Me.chkbono.Size = New System.Drawing.Size(117, 17)
        Me.chkbono.TabIndex = 6
        Me.chkbono.Text = "Aplica Bono Medico"
        Me.chkbono.UseVisualStyleBackColor = True
        '
        'chkacredita
        '
        Me.chkacredita.AutoSize = True
        Me.chkacredita.Location = New System.Drawing.Point(12, 5)
        Me.chkacredita.Name = "chkacredita"
        Me.chkacredita.Size = New System.Drawing.Size(143, 17)
        Me.chkacredita.TabIndex = 0
        Me.chkacredita.Text = "Se Acredita por el banco"
        Me.chkacredita.UseVisualStyleBackColor = True
        '
        'chkPagomensualBeneficios
        '
        Me.chkPagomensualBeneficios.AutoSize = True
        Me.chkPagomensualBeneficios.Location = New System.Drawing.Point(186, 22)
        Me.chkPagomensualBeneficios.Name = "chkPagomensualBeneficios"
        Me.chkPagomensualBeneficios.Size = New System.Drawing.Size(158, 17)
        Me.chkPagomensualBeneficios.TabIndex = 3
        Me.chkPagomensualBeneficios.Text = "Pago mensual de Beneficios"
        Me.chkPagomensualBeneficios.UseVisualStyleBackColor = True
        '
        'chkprueba
        '
        Me.chkprueba.AutoSize = True
        Me.chkprueba.Checked = True
        Me.chkprueba.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkprueba.Location = New System.Drawing.Point(528, 2)
        Me.chkprueba.Name = "chkprueba"
        Me.chkprueba.Size = New System.Drawing.Size(70, 17)
        Me.chkprueba.TabIndex = 5
        Me.chkprueba.Text = "A prueba"
        Me.chkprueba.UseVisualStyleBackColor = True
        '
        'chkestado
        '
        Me.chkestado.AutoSize = True
        Me.chkestado.Checked = True
        Me.chkestado.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkestado.Location = New System.Drawing.Point(12, 22)
        Me.chkestado.Name = "chkestado"
        Me.chkestado.Size = New System.Drawing.Size(56, 17)
        Me.chkestado.TabIndex = 1
        Me.chkestado.Text = "Activo"
        Me.chkestado.UseVisualStyleBackColor = True
        '
        'chkbeneficios
        '
        Me.chkbeneficios.AutoSize = True
        Me.chkbeneficios.Checked = True
        Me.chkbeneficios.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkbeneficios.Location = New System.Drawing.Point(186, 2)
        Me.chkbeneficios.Name = "chkbeneficios"
        Me.chkbeneficios.Size = New System.Drawing.Size(140, 17)
        Me.chkbeneficios.TabIndex = 2
        Me.chkbeneficios.Text = "Aplica Beneficios de Ley"
        Me.chkbeneficios.UseVisualStyleBackColor = True
        '
        'chkpagafondo
        '
        Me.chkpagafondo.AutoSize = True
        Me.chkpagafondo.Checked = True
        Me.chkpagafondo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkpagafondo.Location = New System.Drawing.Point(359, 2)
        Me.chkpagafondo.Name = "chkpagafondo"
        Me.chkpagafondo.Size = New System.Drawing.Size(130, 17)
        Me.chkpagafondo.TabIndex = 4
        Me.chkpagafondo.Text = "Aplica Fondo Reserva"
        Me.chkpagafondo.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(28, 334)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(48, 13)
        Me.Label38.TabIndex = 104
        Me.Label38.Text = "Cta Cble"
        '
        'txtctacble
        '
        Me.txtctacble.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtctacble.Location = New System.Drawing.Point(118, 325)
        Me.txtctacble.Name = "txtctacble"
        Me.txtctacble.Size = New System.Drawing.Size(143, 21)
        Me.txtctacble.TabIndex = 103
        '
        'txtcontacto
        '
        Me.txtcontacto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcontacto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtcontacto.Location = New System.Drawing.Point(428, 119)
        Me.txtcontacto.MaxLength = 250
        Me.txtcontacto.Multiline = True
        Me.txtcontacto.Name = "txtcontacto"
        Me.txtcontacto.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtcontacto.Size = New System.Drawing.Size(270, 63)
        Me.txtcontacto.TabIndex = 102
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(425, 103)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(55, 13)
        Me.Label37.TabIndex = 101
        Me.Label37.Text = "Contacto."
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(432, 184)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(71, 13)
        Me.Label36.TabIndex = 100
        Me.Label36.Text = "Observación."
        '
        'txtobservacion
        '
        Me.txtobservacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtobservacion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtobservacion.Location = New System.Drawing.Point(427, 200)
        Me.txtobservacion.MaxLength = 250
        Me.txtobservacion.Multiline = True
        Me.txtobservacion.Name = "txtobservacion"
        Me.txtobservacion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtobservacion.Size = New System.Drawing.Size(270, 50)
        Me.txtobservacion.TabIndex = 99
        '
        'Label35
        '
        Me.Label35.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(509, 75)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(18, 13)
        Me.Label35.TabIndex = 98
        Me.Label35.Text = "%"
        '
        'txtpordiscapacidad
        '
        Me.txtpordiscapacidad.Location = New System.Drawing.Point(533, 72)
        Me.txtpordiscapacidad.Name = "txtpordiscapacidad"
        Me.txtpordiscapacidad.Size = New System.Drawing.Size(75, 21)
        Me.txtpordiscapacidad.TabIndex = 21
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(24, 238)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(56, 13)
        Me.Label34.TabIndex = 96
        Me.Label34.Text = "Biometrico"
        '
        'txtbiometrico
        '
        Me.txtbiometrico.Location = New System.Drawing.Point(118, 234)
        Me.txtbiometrico.Name = "txtbiometrico"
        Me.txtbiometrico.Size = New System.Drawing.Size(102, 21)
        Me.txtbiometrico.TabIndex = 17
        '
        'chkDiscapacidad
        '
        Me.chkDiscapacidad.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkDiscapacidad.Location = New System.Drawing.Point(424, 75)
        Me.chkDiscapacidad.Name = "chkDiscapacidad"
        Me.chkDiscapacidad.Size = New System.Drawing.Size(79, 17)
        Me.chkDiscapacidad.TabIndex = 20
        Me.chkDiscapacidad.Text = "Discapacidad"
        Me.chkDiscapacidad.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(223, 260)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(53, 13)
        Me.Label33.TabIndex = 94
        Me.Label33.Text = "T. Cal. IR"
        '
        'cmbTcalculoIR
        '
        Me.cmbTcalculoIR.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbTcalculoIR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTcalculoIR.FormattingEnabled = True
        Me.cmbTcalculoIR.Location = New System.Drawing.Point(310, 255)
        Me.cmbTcalculoIR.Name = "cmbTcalculoIR"
        Me.cmbTcalculoIR.Size = New System.Drawing.Size(108, 21)
        Me.cmbTcalculoIR.TabIndex = 18
        '
        'txtcodigo_cargo
        '
        Me.txtcodigo_cargo.Location = New System.Drawing.Point(118, 257)
        Me.txtcodigo_cargo.Name = "txtcodigo_cargo"
        Me.txtcodigo_cargo.Size = New System.Drawing.Size(102, 21)
        Me.txtcodigo_cargo.TabIndex = 19
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(24, 260)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(69, 13)
        Me.Label32.TabIndex = 91
        Me.Label32.Text = "Cód Cargo M"
        '
        'txtMatriculaPortuaria
        '
        Me.txtMatriculaPortuaria.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMatriculaPortuaria.Location = New System.Drawing.Point(310, 231)
        Me.txtMatriculaPortuaria.Name = "txtMatriculaPortuaria"
        Me.txtMatriculaPortuaria.Size = New System.Drawing.Size(108, 21)
        Me.txtMatriculaPortuaria.TabIndex = 16
        '
        'cmbtipoLiqui
        '
        Me.cmbtipoLiqui.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbtipoLiqui.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtipoLiqui.FormattingEnabled = True
        Me.cmbtipoLiqui.Location = New System.Drawing.Point(310, 208)
        Me.cmbtipoLiqui.Name = "cmbtipoLiqui"
        Me.cmbtipoLiqui.Size = New System.Drawing.Size(108, 21)
        Me.cmbtipoLiqui.TabIndex = 14
        '
        'txtNumCta
        '
        Me.txtNumCta.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNumCta.Location = New System.Drawing.Point(310, 162)
        Me.txtNumCta.Name = "txtNumCta"
        Me.txtNumCta.Size = New System.Drawing.Size(108, 21)
        Me.txtNumCta.TabIndex = 12
        '
        'txtCarnetIess
        '
        Me.txtCarnetIess.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCarnetIess.Location = New System.Drawing.Point(310, 139)
        Me.txtCarnetIess.Name = "txtCarnetIess"
        Me.txtCarnetIess.Size = New System.Drawing.Size(108, 21)
        Me.txtCarnetIess.TabIndex = 10
        '
        'dtpfechaTermiContrato
        '
        Me.dtpfechaTermiContrato.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpfechaTermiContrato.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpfechaTermiContrato.Location = New System.Drawing.Point(310, 116)
        Me.dtpfechaTermiContrato.Name = "dtpfechaTermiContrato"
        Me.dtpfechaTermiContrato.Size = New System.Drawing.Size(108, 21)
        Me.dtpfechaTermiContrato.TabIndex = 8
        '
        'dtpfechaNacimiento
        '
        Me.dtpfechaNacimiento.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpfechaNacimiento.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpfechaNacimiento.Location = New System.Drawing.Point(310, 92)
        Me.dtpfechaNacimiento.Name = "dtpfechaNacimiento"
        Me.dtpfechaNacimiento.Size = New System.Drawing.Size(108, 21)
        Me.dtpfechaNacimiento.TabIndex = 6
        '
        'dtpfechaEgreso
        '
        Me.dtpfechaEgreso.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpfechaEgreso.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpfechaEgreso.Location = New System.Drawing.Point(310, 68)
        Me.dtpfechaEgreso.Name = "dtpfechaEgreso"
        Me.dtpfechaEgreso.Size = New System.Drawing.Size(108, 21)
        Me.dtpfechaEgreso.TabIndex = 4
        '
        'txtTipoSangre
        '
        Me.txtTipoSangre.Location = New System.Drawing.Point(118, 211)
        Me.txtTipoSangre.Name = "txtTipoSangre"
        Me.txtTipoSangre.Size = New System.Drawing.Size(102, 21)
        Me.txtTipoSangre.TabIndex = 15
        '
        'cmbestadocivil
        '
        Me.cmbestadocivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbestadocivil.FormattingEnabled = True
        Me.cmbestadocivil.Location = New System.Drawing.Point(118, 187)
        Me.cmbestadocivil.Name = "cmbestadocivil"
        Me.cmbestadocivil.Size = New System.Drawing.Size(102, 21)
        Me.cmbestadocivil.TabIndex = 13
        '
        'cmbclaseEmpleado
        '
        Me.cmbclaseEmpleado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbclaseEmpleado.FormattingEnabled = True
        Me.cmbclaseEmpleado.Location = New System.Drawing.Point(118, 163)
        Me.cmbclaseEmpleado.Name = "cmbclaseEmpleado"
        Me.cmbclaseEmpleado.Size = New System.Drawing.Size(102, 21)
        Me.cmbclaseEmpleado.TabIndex = 11
        '
        'cmbTipoCta
        '
        Me.cmbTipoCta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTipoCta.FormattingEnabled = True
        Me.cmbTipoCta.Location = New System.Drawing.Point(118, 139)
        Me.cmbTipoCta.Name = "cmbTipoCta"
        Me.cmbTipoCta.Size = New System.Drawing.Size(102, 21)
        Me.cmbTipoCta.TabIndex = 9
        '
        'txtcedMilitar
        '
        Me.txtcedMilitar.Location = New System.Drawing.Point(118, 116)
        Me.txtcedMilitar.Name = "txtcedMilitar"
        Me.txtcedMilitar.Size = New System.Drawing.Size(102, 21)
        Me.txtcedMilitar.TabIndex = 7
        '
        'dtpfechaIngreso
        '
        Me.dtpfechaIngreso.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpfechaIngreso.Location = New System.Drawing.Point(118, 70)
        Me.dtpfechaIngreso.Name = "dtpfechaIngreso"
        Me.dtpfechaIngreso.Size = New System.Drawing.Size(102, 21)
        Me.dtpfechaIngreso.TabIndex = 3
        '
        'cmbsexo
        '
        Me.cmbsexo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbsexo.FormattingEnabled = True
        Me.cmbsexo.Location = New System.Drawing.Point(118, 93)
        Me.cmbsexo.Name = "cmbsexo"
        Me.cmbsexo.Size = New System.Drawing.Size(102, 21)
        Me.cmbsexo.TabIndex = 5
        '
        'txtTelefono
        '
        Me.txtTelefono.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTelefono.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTelefono.Location = New System.Drawing.Point(118, 46)
        Me.txtTelefono.MaxLength = 20
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(580, 21)
        Me.txtTelefono.TabIndex = 2
        '
        'TxtDireccion
        '
        Me.TxtDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtDireccion.Location = New System.Drawing.Point(118, 8)
        Me.TxtDireccion.MaxLength = 250
        Me.TxtDireccion.Multiline = True
        Me.TxtDireccion.Name = "TxtDireccion"
        Me.TxtDireccion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TxtDireccion.Size = New System.Drawing.Size(580, 35)
        Me.TxtDireccion.TabIndex = 1
        '
        'txtlugarNaci
        '
        Me.txtlugarNaci.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtlugarNaci.Location = New System.Drawing.Point(223, 279)
        Me.txtlugarNaci.Name = "txtlugarNaci"
        Me.txtlugarNaci.ReadOnly = True
        Me.txtlugarNaci.Size = New System.Drawing.Size(475, 21)
        Me.txtlugarNaci.TabIndex = 74
        '
        'txtCodCiudad
        '
        Me.txtCodCiudad.Location = New System.Drawing.Point(118, 279)
        Me.txtCodCiudad.Name = "txtCodCiudad"
        Me.txtCodCiudad.Size = New System.Drawing.Size(102, 21)
        Me.txtCodCiudad.TabIndex = 22
        '
        'Label31
        '
        Me.Label31.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(221, 236)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(63, 13)
        Me.Label31.TabIndex = 17
        Me.Label31.Text = "M.Portuaria"
        '
        'Label30
        '
        Me.Label30.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(220, 212)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(71, 13)
        Me.Label30.TabIndex = 16
        Me.Label30.Text = "Tipo De Liqui."
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(221, 166)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 13)
        Me.Label29.TabIndex = 15
        Me.Label29.Text = "Numero Cta"
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(220, 142)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(65, 13)
        Me.Label21.TabIndex = 14
        Me.Label21.Text = "Carnet IEES"
        '
        'Label20
        '
        Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(221, 117)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(74, 13)
        Me.Label20.TabIndex = 13
        Me.Label20.Text = "F. Term. Cont"
        '
        'Label19
        '
        Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(220, 93)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(72, 13)
        Me.Label19.TabIndex = 12
        Me.Label19.Text = "F. Nacimiento"
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(221, 70)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(67, 13)
        Me.Label18.TabIndex = 11
        Me.Label18.Text = "Fecha Salida"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(23, 282)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(66, 13)
        Me.Label17.TabIndex = 10
        Me.Label17.Text = "Cód. Ciudad"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(23, 214)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(64, 13)
        Me.Label16.TabIndex = 9
        Me.Label16.Text = "Tipo Sangre"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(23, 191)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(62, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Estado Civil"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(23, 166)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 13)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "T. Empleado"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(23, 142)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(67, 13)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Tipo De Cta."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(23, 118)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 13)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "Ced. Militar"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(23, 97)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(31, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Sexo"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(23, 74)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 13)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Fecha Ing."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 49)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(66, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Teléfono(s):"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(23, 11)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Dirección:"
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.GroupControl5)
        Me.XtraTabPage2.Controls.Add(Me.lbltitulo)
        Me.XtraTabPage2.Controls.Add(Me.txttitulo)
        Me.XtraTabPage2.Controls.Add(Me.txtestudios)
        Me.XtraTabPage2.Controls.Add(Me.lblestudios)
        Me.XtraTabPage2.Controls.Add(Me.lblnacionalidad)
        Me.XtraTabPage2.Controls.Add(Me.txtnacionalidad)
        Me.XtraTabPage2.Controls.Add(Me.lblcargo)
        Me.XtraTabPage2.Controls.Add(Me.txtcargo)
        Me.XtraTabPage2.Controls.Add(Me.lbldepartamento)
        Me.XtraTabPage2.Controls.Add(Me.txtdepartamento)
        Me.XtraTabPage2.Controls.Add(Me.lblsector)
        Me.XtraTabPage2.Controls.Add(Me.txtsector)
        Me.XtraTabPage2.Controls.Add(Me.lblsectorial)
        Me.XtraTabPage2.Controls.Add(Me.txtcodsectorial)
        Me.XtraTabPage2.Controls.Add(Me.Label28)
        Me.XtraTabPage2.Controls.Add(Me.Label27)
        Me.XtraTabPage2.Controls.Add(Me.Label26)
        Me.XtraTabPage2.Controls.Add(Me.Label25)
        Me.XtraTabPage2.Controls.Add(Me.Label24)
        Me.XtraTabPage2.Controls.Add(Me.Label23)
        Me.XtraTabPage2.Controls.Add(Me.Label22)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(713, 395)
        Me.XtraTabPage2.Text = "Inf.Adic./ Sueldo"
        '
        'GroupControl5
        '
        Me.GroupControl5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupControl5.Controls.Add(Me.txtalimentacion)
        Me.GroupControl5.Controls.Add(Me.Label44)
        Me.GroupControl5.Controls.Add(Me.chkpagootro)
        Me.GroupControl5.Controls.Add(Me.txtMoviQuincenal)
        Me.GroupControl5.Controls.Add(Me.txtSueldoExtraMen)
        Me.GroupControl5.Controls.Add(Me.txtSueldoBasicoMen)
        Me.GroupControl5.Controls.Add(Me.Label5)
        Me.GroupControl5.Controls.Add(Me.Label7)
        Me.GroupControl5.Controls.Add(Me.Label6)
        Me.GroupControl5.Location = New System.Drawing.Point(57, 215)
        Me.GroupControl5.Name = "GroupControl5"
        Me.GroupControl5.Size = New System.Drawing.Size(595, 142)
        Me.GroupControl5.TabIndex = 85
        Me.GroupControl5.Text = "Ingresos"
        '
        'txtalimentacion
        '
        Me.txtalimentacion.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtalimentacion.Location = New System.Drawing.Point(187, 96)
        Me.txtalimentacion.Name = "txtalimentacion"
        Me.txtalimentacion.Size = New System.Drawing.Size(120, 21)
        Me.txtalimentacion.TabIndex = 96
        Me.txtalimentacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label44
        '
        Me.Label44.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(54, 98)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(67, 13)
        Me.Label44.TabIndex = 95
        Me.Label44.Text = "Alimentación"
        '
        'chkpagootro
        '
        Me.chkpagootro.AutoSize = True
        Me.chkpagootro.Location = New System.Drawing.Point(334, 100)
        Me.chkpagootro.Name = "chkpagootro"
        Me.chkpagootro.Size = New System.Drawing.Size(95, 17)
        Me.chkpagootro.TabIndex = 94
        Me.chkpagootro.Text = "Pago Adicional"
        Me.chkpagootro.UseVisualStyleBackColor = True
        '
        'txtMoviQuincenal
        '
        Me.txtMoviQuincenal.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtMoviQuincenal.Location = New System.Drawing.Point(187, 73)
        Me.txtMoviQuincenal.Name = "txtMoviQuincenal"
        Me.txtMoviQuincenal.Size = New System.Drawing.Size(120, 21)
        Me.txtMoviQuincenal.TabIndex = 93
        Me.txtMoviQuincenal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSueldoExtraMen
        '
        Me.txtSueldoExtraMen.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSueldoExtraMen.Location = New System.Drawing.Point(187, 48)
        Me.txtSueldoExtraMen.Name = "txtSueldoExtraMen"
        Me.txtSueldoExtraMen.Size = New System.Drawing.Size(120, 21)
        Me.txtSueldoExtraMen.TabIndex = 92
        Me.txtSueldoExtraMen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSueldoBasicoMen
        '
        Me.txtSueldoBasicoMen.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSueldoBasicoMen.Location = New System.Drawing.Point(187, 24)
        Me.txtSueldoBasicoMen.Name = "txtSueldoBasicoMen"
        Me.txtSueldoBasicoMen.Size = New System.Drawing.Size(120, 21)
        Me.txtSueldoBasicoMen.TabIndex = 86
        Me.txtSueldoBasicoMen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(46, 76)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 13)
        Me.Label5.TabIndex = 88
        Me.Label5.Text = "Movilizacion Quincenal"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(47, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(114, 13)
        Me.Label7.TabIndex = 86
        Me.Label7.Text = "Sueldo Basico Mensual"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(47, 51)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(110, 13)
        Me.Label6.TabIndex = 87
        Me.Label6.Text = "Sueldo Extra Mensual"
        '
        'lbltitulo
        '
        Me.lbltitulo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbltitulo.Enabled = False
        Me.lbltitulo.Location = New System.Drawing.Point(214, 188)
        Me.lbltitulo.Name = "lbltitulo"
        Me.lbltitulo.ReadOnly = True
        Me.lbltitulo.Size = New System.Drawing.Size(443, 21)
        Me.lbltitulo.TabIndex = 84
        '
        'txttitulo
        '
        Me.txttitulo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txttitulo.Location = New System.Drawing.Point(133, 188)
        Me.txttitulo.Name = "txttitulo"
        Me.txttitulo.Size = New System.Drawing.Size(75, 21)
        Me.txttitulo.TabIndex = 83
        '
        'txtestudios
        '
        Me.txtestudios.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtestudios.Location = New System.Drawing.Point(133, 161)
        Me.txtestudios.Name = "txtestudios"
        Me.txtestudios.Size = New System.Drawing.Size(75, 21)
        Me.txtestudios.TabIndex = 82
        '
        'lblestudios
        '
        Me.lblestudios.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblestudios.Enabled = False
        Me.lblestudios.Location = New System.Drawing.Point(214, 161)
        Me.lblestudios.Name = "lblestudios"
        Me.lblestudios.ReadOnly = True
        Me.lblestudios.Size = New System.Drawing.Size(443, 21)
        Me.lblestudios.TabIndex = 81
        '
        'lblnacionalidad
        '
        Me.lblnacionalidad.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblnacionalidad.Enabled = False
        Me.lblnacionalidad.Location = New System.Drawing.Point(214, 134)
        Me.lblnacionalidad.Name = "lblnacionalidad"
        Me.lblnacionalidad.ReadOnly = True
        Me.lblnacionalidad.Size = New System.Drawing.Size(443, 21)
        Me.lblnacionalidad.TabIndex = 80
        '
        'txtnacionalidad
        '
        Me.txtnacionalidad.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtnacionalidad.Location = New System.Drawing.Point(133, 134)
        Me.txtnacionalidad.Name = "txtnacionalidad"
        Me.txtnacionalidad.Size = New System.Drawing.Size(75, 21)
        Me.txtnacionalidad.TabIndex = 79
        '
        'lblcargo
        '
        Me.lblcargo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblcargo.Enabled = False
        Me.lblcargo.Location = New System.Drawing.Point(214, 80)
        Me.lblcargo.Name = "lblcargo"
        Me.lblcargo.ReadOnly = True
        Me.lblcargo.Size = New System.Drawing.Size(443, 21)
        Me.lblcargo.TabIndex = 78
        '
        'txtcargo
        '
        Me.txtcargo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcargo.Location = New System.Drawing.Point(133, 80)
        Me.txtcargo.Name = "txtcargo"
        Me.txtcargo.Size = New System.Drawing.Size(75, 21)
        Me.txtcargo.TabIndex = 77
        '
        'lbldepartamento
        '
        Me.lbldepartamento.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbldepartamento.Enabled = False
        Me.lbldepartamento.Location = New System.Drawing.Point(214, 53)
        Me.lbldepartamento.Name = "lbldepartamento"
        Me.lbldepartamento.ReadOnly = True
        Me.lbldepartamento.Size = New System.Drawing.Size(443, 21)
        Me.lbldepartamento.TabIndex = 76
        '
        'txtdepartamento
        '
        Me.txtdepartamento.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtdepartamento.Location = New System.Drawing.Point(133, 53)
        Me.txtdepartamento.Name = "txtdepartamento"
        Me.txtdepartamento.Size = New System.Drawing.Size(75, 21)
        Me.txtdepartamento.TabIndex = 75
        '
        'lblsector
        '
        Me.lblsector.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblsector.Enabled = False
        Me.lblsector.Location = New System.Drawing.Point(214, 107)
        Me.lblsector.Name = "lblsector"
        Me.lblsector.ReadOnly = True
        Me.lblsector.Size = New System.Drawing.Size(443, 21)
        Me.lblsector.TabIndex = 74
        '
        'txtsector
        '
        Me.txtsector.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtsector.Location = New System.Drawing.Point(133, 107)
        Me.txtsector.Name = "txtsector"
        Me.txtsector.Size = New System.Drawing.Size(75, 21)
        Me.txtsector.TabIndex = 73
        '
        'lblsectorial
        '
        Me.lblsectorial.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblsectorial.Enabled = False
        Me.lblsectorial.Location = New System.Drawing.Point(214, 26)
        Me.lblsectorial.Name = "lblsectorial"
        Me.lblsectorial.ReadOnly = True
        Me.lblsectorial.Size = New System.Drawing.Size(443, 21)
        Me.lblsectorial.TabIndex = 72
        '
        'txtcodsectorial
        '
        Me.txtcodsectorial.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcodsectorial.Location = New System.Drawing.Point(133, 26)
        Me.txtcodsectorial.Name = "txtcodsectorial"
        Me.txtcodsectorial.Size = New System.Drawing.Size(75, 21)
        Me.txtcodsectorial.TabIndex = 71
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(48, 191)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(33, 13)
        Me.Label28.TabIndex = 70
        Me.Label28.Text = "Titulo"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(48, 164)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(47, 13)
        Me.Label27.TabIndex = 69
        Me.Label27.Text = "Estudios"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(48, 137)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(67, 13)
        Me.Label26.TabIndex = 68
        Me.Label26.Text = "Nacionalidad"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(48, 83)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(36, 13)
        Me.Label25.TabIndex = 67
        Me.Label25.Text = "Cargo"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(48, 56)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(76, 13)
        Me.Label24.TabIndex = 66
        Me.Label24.Text = "Departamento"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(48, 110)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(38, 13)
        Me.Label23.TabIndex = 65
        Me.Label23.Text = "Sector"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(48, 29)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(70, 13)
        Me.Label22.TabIndex = 64
        Me.Label22.Text = "Cod Sectorial"
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.Controls.Add(Me.BtnModificar)
        Me.XtraTabPage3.Controls.Add(Me.GrdCargaFamiliar)
        Me.XtraTabPage3.Controls.Add(Me.BtnQuitarF)
        Me.XtraTabPage3.Controls.Add(Me.BtnAceptarF)
        Me.XtraTabPage3.Controls.Add(Me.GroupControl4)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(713, 395)
        Me.XtraTabPage3.Text = "Cargas Familiares"
        '
        'BtnModificar
        '
        Me.BtnModificar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnModificar.Location = New System.Drawing.Point(521, 348)
        Me.BtnModificar.Name = "BtnModificar"
        Me.BtnModificar.Size = New System.Drawing.Size(94, 20)
        Me.BtnModificar.TabIndex = 11
        Me.BtnModificar.Text = "Modificar"
        Me.BtnModificar.UseVisualStyleBackColor = True
        '
        'GrdCargaFamiliar
        '
        Me.GrdCargaFamiliar.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GrdCargaFamiliar.Location = New System.Drawing.Point(4, 106)
        Me.GrdCargaFamiliar.MainView = Me.GridView2
        Me.GrdCargaFamiliar.Name = "GrdCargaFamiliar"
        Me.GrdCargaFamiliar.Size = New System.Drawing.Size(705, 238)
        Me.GrdCargaFamiliar.TabIndex = 10
        Me.GrdCargaFamiliar.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView2, Me.GridView4})
        '
        'GridView2
        '
        Me.GridView2.GridControl = Me.GrdCargaFamiliar
        Me.GridView2.Name = "GridView2"
        Me.GridView2.OptionsBehavior.Editable = False
        '
        'GridView4
        '
        Me.GridView4.GridControl = Me.GrdCargaFamiliar
        Me.GridView4.Name = "GridView4"
        '
        'BtnQuitarF
        '
        Me.BtnQuitarF.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnQuitarF.Location = New System.Drawing.Point(615, 348)
        Me.BtnQuitarF.Name = "BtnQuitarF"
        Me.BtnQuitarF.Size = New System.Drawing.Size(94, 20)
        Me.BtnQuitarF.TabIndex = 9
        Me.BtnQuitarF.Text = "&Quitar"
        Me.BtnQuitarF.UseVisualStyleBackColor = True
        '
        'BtnAceptarF
        '
        Me.BtnAceptarF.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnAceptarF.Location = New System.Drawing.Point(428, 348)
        Me.BtnAceptarF.Name = "BtnAceptarF"
        Me.BtnAceptarF.Size = New System.Drawing.Size(94, 20)
        Me.BtnAceptarF.TabIndex = 8
        Me.BtnAceptarF.Text = "Agregar"
        Me.BtnAceptarF.UseVisualStyleBackColor = True
        '
        'GroupControl4
        '
        Me.GroupControl4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupControl4.Controls.Add(Me.chkemfcatastrifica)
        Me.GroupControl4.Controls.Add(Me.chkimprenta)
        Me.GroupControl4.Controls.Add(Me.chkutilidad)
        Me.GroupControl4.Controls.Add(Me.chkaporta)
        Me.GroupControl4.Controls.Add(Me.dtpfechanac)
        Me.GroupControl4.Controls.Add(Me.chkestadoFamiliar)
        Me.GroupControl4.Controls.Add(Me.cmbsexoFamiliar)
        Me.GroupControl4.Controls.Add(Me.Label4)
        Me.GroupControl4.Controls.Add(Me.TxtNombreFamiliar)
        Me.GroupControl4.Controls.Add(Me.cmbtipoFamiliar)
        Me.GroupControl4.Controls.Add(Me.Label1)
        Me.GroupControl4.Controls.Add(Me.Label2)
        Me.GroupControl4.Controls.Add(Me.Label3)
        Me.GroupControl4.Location = New System.Drawing.Point(4, 3)
        Me.GroupControl4.Name = "GroupControl4"
        Me.GroupControl4.Size = New System.Drawing.Size(705, 97)
        Me.GroupControl4.TabIndex = 7
        Me.GroupControl4.Text = "Datos del Familiar"
        '
        'chkemfcatastrifica
        '
        Me.chkemfcatastrifica.AutoSize = True
        Me.chkemfcatastrifica.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkemfcatastrifica.Location = New System.Drawing.Point(445, 74)
        Me.chkemfcatastrifica.Name = "chkemfcatastrifica"
        Me.chkemfcatastrifica.Size = New System.Drawing.Size(94, 17)
        Me.chkemfcatastrifica.TabIndex = 17
        Me.chkemfcatastrifica.Text = "A.I.Emf Catas"
        Me.chkemfcatastrifica.UseVisualStyleBackColor = True
        '
        'chkimprenta
        '
        Me.chkimprenta.AutoSize = True
        Me.chkimprenta.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkimprenta.Location = New System.Drawing.Point(343, 74)
        Me.chkimprenta.Name = "chkimprenta"
        Me.chkimprenta.Size = New System.Drawing.Size(87, 17)
        Me.chkimprenta.TabIndex = 16
        Me.chkimprenta.Text = "A.Imp Renta"
        Me.chkimprenta.UseVisualStyleBackColor = True
        '
        'chkutilidad
        '
        Me.chkutilidad.AutoSize = True
        Me.chkutilidad.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkutilidad.Location = New System.Drawing.Point(260, 74)
        Me.chkutilidad.Name = "chkutilidad"
        Me.chkutilidad.Size = New System.Drawing.Size(72, 17)
        Me.chkutilidad.TabIndex = 15
        Me.chkutilidad.Text = "A.Utilidad"
        Me.chkutilidad.UseVisualStyleBackColor = True
        Me.chkutilidad.Visible = False
        '
        'chkaporta
        '
        Me.chkaporta.AutoSize = True
        Me.chkaporta.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkaporta.Location = New System.Drawing.Point(560, 50)
        Me.chkaporta.Name = "chkaporta"
        Me.chkaporta.Size = New System.Drawing.Size(126, 17)
        Me.chkaporta.TabIndex = 11
        Me.chkaporta.Text = "Aporta Seguro Social"
        Me.chkaporta.UseVisualStyleBackColor = True
        '
        'dtpfechanac
        '
        Me.dtpfechanac.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpfechanac.Location = New System.Drawing.Point(80, 71)
        Me.dtpfechanac.Name = "dtpfechanac"
        Me.dtpfechanac.Size = New System.Drawing.Size(175, 21)
        Me.dtpfechanac.TabIndex = 10
        '
        'chkestadoFamiliar
        '
        Me.chkestadoFamiliar.AutoSize = True
        Me.chkestadoFamiliar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkestadoFamiliar.Checked = True
        Me.chkestadoFamiliar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkestadoFamiliar.Location = New System.Drawing.Point(627, 76)
        Me.chkestadoFamiliar.Name = "chkestadoFamiliar"
        Me.chkestadoFamiliar.Size = New System.Drawing.Size(59, 17)
        Me.chkestadoFamiliar.TabIndex = 9
        Me.chkestadoFamiliar.Text = "Estado"
        Me.chkestadoFamiliar.UseVisualStyleBackColor = True
        '
        'cmbsexoFamiliar
        '
        Me.cmbsexoFamiliar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbsexoFamiliar.FormattingEnabled = True
        Me.cmbsexoFamiliar.Location = New System.Drawing.Point(298, 47)
        Me.cmbsexoFamiliar.Name = "cmbsexoFamiliar"
        Me.cmbsexoFamiliar.Size = New System.Drawing.Size(175, 21)
        Me.cmbsexoFamiliar.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(261, 55)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Sexo"
        '
        'TxtNombreFamiliar
        '
        Me.TxtNombreFamiliar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtNombreFamiliar.Location = New System.Drawing.Point(80, 24)
        Me.TxtNombreFamiliar.Name = "TxtNombreFamiliar"
        Me.TxtNombreFamiliar.Size = New System.Drawing.Size(606, 21)
        Me.TxtNombreFamiliar.TabIndex = 6
        '
        'cmbtipoFamiliar
        '
        Me.cmbtipoFamiliar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtipoFamiliar.FormattingEnabled = True
        Me.cmbtipoFamiliar.Location = New System.Drawing.Point(80, 47)
        Me.cmbtipoFamiliar.Name = "cmbtipoFamiliar"
        Me.cmbtipoFamiliar.Size = New System.Drawing.Size(175, 21)
        Me.cmbtipoFamiliar.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Tipo"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nombre:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Fecha Nac."
        '
        'XtraTabPage4
        '
        Me.XtraTabPage4.Controls.Add(Me.GridControl2)
        Me.XtraTabPage4.Name = "XtraTabPage4"
        Me.XtraTabPage4.PageEnabled = False
        Me.XtraTabPage4.PageVisible = False
        Me.XtraTabPage4.Size = New System.Drawing.Size(713, 395)
        Me.XtraTabPage4.Text = "Parametros Contables"
        '
        'GridControl2
        '
        Me.GridControl2.Location = New System.Drawing.Point(3, 12)
        Me.GridControl2.MainView = Me.GridView3
        Me.GridControl2.Name = "GridControl2"
        Me.GridControl2.Size = New System.Drawing.Size(707, 356)
        Me.GridControl2.TabIndex = 0
        Me.GridControl2.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView3})
        '
        'GridView3
        '
        Me.GridView3.GridControl = Me.GridControl2
        Me.GridView3.Name = "GridView3"
        '
        'pnlfondo
        '
        Me.pnlfondo.Controls.Add(Me.GroupControl2)
        Me.pnlfondo.Location = New System.Drawing.Point(12, 97)
        Me.pnlfondo.Name = "pnlfondo"
        Me.pnlfondo.Size = New System.Drawing.Size(747, 573)
        Me.pnlfondo.TabIndex = 1
        '
        'chkInactivos
        '
        Me.chkInactivos.AutoSize = True
        Me.chkInactivos.Location = New System.Drawing.Point(502, 24)
        Me.chkInactivos.Name = "chkInactivos"
        Me.chkInactivos.Size = New System.Drawing.Size(81, 17)
        Me.chkInactivos.TabIndex = 7
        Me.chkInactivos.Text = "INACTIVOS"
        Me.chkInactivos.UseVisualStyleBackColor = True
        '
        'BtnBuscar
        '
        Me.BtnBuscar.Location = New System.Drawing.Point(608, 8)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(89, 33)
        Me.BtnBuscar.TabIndex = 6
        Me.BtnBuscar.Text = "&Aceptar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'txtbus
        '
        Me.txtbus.Location = New System.Drawing.Point(122, 24)
        Me.txtbus.Name = "txtbus"
        Me.txtbus.Size = New System.Drawing.Size(361, 21)
        Me.txtbus.TabIndex = 5
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(8, 30)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(104, 13)
        Me.Label39.TabIndex = 4
        Me.Label39.Text = "Motivo de Busqueda"
        '
        'optTodos
        '
        Me.optTodos.AutoSize = True
        Me.optTodos.Location = New System.Drawing.Point(505, 5)
        Me.optTodos.Name = "optTodos"
        Me.optTodos.Size = New System.Drawing.Size(54, 17)
        Me.optTodos.TabIndex = 3
        Me.optTodos.Text = "Todos"
        Me.optTodos.UseVisualStyleBackColor = True
        '
        'optPorNombre
        '
        Me.optPorNombre.AutoSize = True
        Me.optPorNombre.Location = New System.Drawing.Point(268, 5)
        Me.optPorNombre.Name = "optPorNombre"
        Me.optPorNombre.Size = New System.Drawing.Size(121, 17)
        Me.optPorNombre.TabIndex = 2
        Me.optPorNombre.Text = "Nombre y/o Apellido"
        Me.optPorNombre.UseVisualStyleBackColor = True
        '
        'optPorCodigo
        '
        Me.optPorCodigo.AutoSize = True
        Me.optPorCodigo.Location = New System.Drawing.Point(134, 5)
        Me.optPorCodigo.Name = "optPorCodigo"
        Me.optPorCodigo.Size = New System.Drawing.Size(58, 17)
        Me.optPorCodigo.TabIndex = 1
        Me.optPorCodigo.Text = "Código"
        Me.optPorCodigo.UseVisualStyleBackColor = True
        '
        'optPorcedula
        '
        Me.optPorcedula.AutoSize = True
        Me.optPorcedula.Checked = True
        Me.optPorcedula.Location = New System.Drawing.Point(15, 5)
        Me.optPorcedula.Name = "optPorcedula"
        Me.optPorcedula.Size = New System.Drawing.Size(80, 17)
        Me.optPorcedula.TabIndex = 0
        Me.optPorcedula.TabStop = True
        Me.optPorcedula.Text = "Cedula/Ruc"
        Me.optPorcedula.UseVisualStyleBackColor = True
        '
        'DefaultLookAndFeel1
        '
        Me.DefaultLookAndFeel1.LookAndFeel.SkinName = "Office 2013 Light Gray"
        '
        'GroupControl1
        '
        Me.GroupControl1.Controls.Add(Me.pnlfondo)
        Me.GroupControl1.Controls.Add(Me.plcfiltro)
        Me.GroupControl1.Controls.Add(Me.cmbCompania)
        Me.GroupControl1.Controls.Add(Me.lblcompania)
        Me.GroupControl1.Controls.Add(Me.pnlfrente)
        Me.GroupControl1.Location = New System.Drawing.Point(0, 27)
        Me.GroupControl1.Name = "GroupControl1"
        Me.GroupControl1.Size = New System.Drawing.Size(764, 675)
        Me.GroupControl1.TabIndex = 6
        Me.GroupControl1.Text = "Empleado"
        '
        'plcfiltro
        '
        Me.plcfiltro.Controls.Add(Me.BtnBuscar)
        Me.plcfiltro.Controls.Add(Me.chkInactivos)
        Me.plcfiltro.Controls.Add(Me.optPorcedula)
        Me.plcfiltro.Controls.Add(Me.optPorCodigo)
        Me.plcfiltro.Controls.Add(Me.optTodos)
        Me.plcfiltro.Controls.Add(Me.txtbus)
        Me.plcfiltro.Controls.Add(Me.optPorNombre)
        Me.plcfiltro.Controls.Add(Me.Label39)
        Me.plcfiltro.Location = New System.Drawing.Point(5, 42)
        Me.plcfiltro.Name = "plcfiltro"
        Me.plcfiltro.Size = New System.Drawing.Size(740, 49)
        Me.plcfiltro.TabIndex = 26
        '
        'cmbCompania
        '
        Me.cmbCompania.Location = New System.Drawing.Point(83, 18)
        Me.cmbCompania.Name = "cmbCompania"
        Me.cmbCompania.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cmbCompania.Properties.View = Me.GridLookUpEdit1View
        Me.cmbCompania.Size = New System.Drawing.Size(652, 20)
        Me.cmbCompania.TabIndex = 25
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'lblcompania
        '
        Me.lblcompania.AutoSize = True
        Me.lblcompania.Location = New System.Drawing.Point(12, 21)
        Me.lblcompania.Name = "lblcompania"
        Me.lblcompania.Size = New System.Drawing.Size(54, 13)
        Me.lblcompania.TabIndex = 24
        Me.lblcompania.Text = "Compañia"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FrmEmpleados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(860, 726)
        Me.Controls.Add(Me.GroupControl1)
        Me.Controls.Add(Me.mnsForma)
        Me.MinimumSize = New System.Drawing.Size(770, 724)
        Me.Name = "FrmEmpleados"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mantenimiento del Personal"
        Me.mnsForma.ResumeLayout(False)
        Me.mnsForma.PerformLayout()
        Me.pnlfrente.ResumeLayout(False)
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GroupControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl2.ResumeLayout(False)
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        Me.PanelControl3.PerformLayout()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        CType(Me.pbximagen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.XtraTabPage1.PerformLayout()
        CType(Me.gluccosto.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl4.ResumeLayout(False)
        Me.PanelControl4.PerformLayout()
        Me.XtraTabPage2.ResumeLayout(False)
        Me.XtraTabPage2.PerformLayout()
        CType(Me.GroupControl5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl5.ResumeLayout(False)
        Me.GroupControl5.PerformLayout()
        Me.XtraTabPage3.ResumeLayout(False)
        CType(Me.GrdCargaFamiliar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GroupControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl4.ResumeLayout(False)
        Me.GroupControl4.PerformLayout()
        Me.XtraTabPage4.ResumeLayout(False)
        CType(Me.GridControl2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfondo.ResumeLayout(False)
        CType(Me.GroupControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupControl1.ResumeLayout(False)
        Me.GroupControl1.PerformLayout()
        CType(Me.plcfiltro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.plcfiltro.ResumeLayout(False)
        Me.plcfiltro.PerformLayout()
        CType(Me.cmbCompania.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnsForma As System.Windows.Forms.MenuStrip
    Friend WithEvents mnunuevo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnumodificar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuconsultar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuanular As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnugrabar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnucancelar As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnusalir As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlfrente As System.Windows.Forms.Panel
    Friend WithEvents pnlfondo As System.Windows.Forms.Panel
    Friend WithEvents chkInactivos As System.Windows.Forms.CheckBox
    Friend WithEvents BtnBuscar As System.Windows.Forms.Button
    Friend WithEvents txtbus As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents optTodos As System.Windows.Forms.RadioButton
    Friend WithEvents optPorNombre As System.Windows.Forms.RadioButton
    Friend WithEvents optPorCodigo As System.Windows.Forms.RadioButton
    Friend WithEvents optPorcedula As System.Windows.Forms.RadioButton
    Friend WithEvents DefaultLookAndFeel1 As DevExpress.LookAndFeel.DefaultLookAndFeel
    Friend WithEvents FormAssistant1 As DevExpress.XtraBars.FormAssistant
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GroupControl2 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents TxtNombre As System.Windows.Forms.TextBox
    Friend WithEvents TxtCedula_Ruc As System.Windows.Forms.TextBox
    Friend WithEvents txtcodigo As System.Windows.Forms.TextBox
    Friend WithEvents cmbTipo As System.Windows.Forms.ComboBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents GroupControl1 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents cmbCompania As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents lblcompania As System.Windows.Forms.Label
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtctacble As System.Windows.Forms.TextBox
    Friend WithEvents txtcontacto As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtobservacion As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtpordiscapacidad As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtbiometrico As System.Windows.Forms.TextBox
    Friend WithEvents chkDiscapacidad As System.Windows.Forms.CheckBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents cmbTcalculoIR As System.Windows.Forms.ComboBox
    Friend WithEvents txtcodigo_cargo As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtMatriculaPortuaria As System.Windows.Forms.TextBox
    Friend WithEvents cmbtipoLiqui As System.Windows.Forms.ComboBox
    Friend WithEvents txtNumCta As System.Windows.Forms.TextBox
    Friend WithEvents txtCarnetIess As System.Windows.Forms.TextBox
    Friend WithEvents dtpfechaTermiContrato As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpfechaNacimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpfechaEgreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtTipoSangre As System.Windows.Forms.TextBox
    Friend WithEvents cmbestadocivil As System.Windows.Forms.ComboBox
    Friend WithEvents cmbclaseEmpleado As System.Windows.Forms.ComboBox
    Friend WithEvents cmbTipoCta As System.Windows.Forms.ComboBox
    Friend WithEvents txtcedMilitar As System.Windows.Forms.TextBox
    Friend WithEvents dtpfechaIngreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbsexo As System.Windows.Forms.ComboBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents TxtDireccion As System.Windows.Forms.TextBox
    Friend WithEvents txtlugarNaci As System.Windows.Forms.TextBox
    Friend WithEvents txtCodCiudad As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chkpagafondo As System.Windows.Forms.CheckBox
    Friend WithEvents chkPagomensualBeneficios As System.Windows.Forms.CheckBox
    Friend WithEvents chkbeneficios As System.Windows.Forms.CheckBox
    Friend WithEvents chkestado As System.Windows.Forms.CheckBox
    Friend WithEvents chkacredita As System.Windows.Forms.CheckBox
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents GroupControl5 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents txtMoviQuincenal As System.Windows.Forms.TextBox
    Friend WithEvents txtSueldoExtraMen As System.Windows.Forms.TextBox
    Friend WithEvents txtSueldoBasicoMen As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lbltitulo As System.Windows.Forms.TextBox
    Friend WithEvents txttitulo As System.Windows.Forms.TextBox
    Friend WithEvents txtestudios As System.Windows.Forms.TextBox
    Friend WithEvents lblestudios As System.Windows.Forms.TextBox
    Friend WithEvents lblnacionalidad As System.Windows.Forms.TextBox
    Friend WithEvents txtnacionalidad As System.Windows.Forms.TextBox
    Friend WithEvents lblcargo As System.Windows.Forms.TextBox
    Friend WithEvents txtcargo As System.Windows.Forms.TextBox
    Friend WithEvents lbldepartamento As System.Windows.Forms.TextBox
    Friend WithEvents txtdepartamento As System.Windows.Forms.TextBox
    Friend WithEvents lblsector As System.Windows.Forms.TextBox
    Friend WithEvents txtsector As System.Windows.Forms.TextBox
    Friend WithEvents lblsectorial As System.Windows.Forms.TextBox
    Friend WithEvents txtcodsectorial As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents GrdCargaFamiliar As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents BtnQuitarF As System.Windows.Forms.Button
    Friend WithEvents BtnAceptarF As System.Windows.Forms.Button
    Friend WithEvents GroupControl4 As DevExpress.XtraEditors.GroupControl
    Friend WithEvents chkaporta As System.Windows.Forms.CheckBox
    Friend WithEvents dtpfechanac As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkestadoFamiliar As System.Windows.Forms.CheckBox
    Friend WithEvents cmbsexoFamiliar As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtNombreFamiliar As System.Windows.Forms.TextBox
    Friend WithEvents cmbtipoFamiliar As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GridView4 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents chkbono As System.Windows.Forms.CheckBox
    Friend WithEvents chkprueba As System.Windows.Forms.CheckBox
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents pbximagen As System.Windows.Forms.PictureBox
    Friend WithEvents butfoto As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents plcfiltro As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents PanelControl4 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents chkpagootro As System.Windows.Forms.CheckBox
    Friend WithEvents BtnModificar As System.Windows.Forms.Button
    Friend WithEvents XtraTabPage4 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents GridControl2 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents txtalimentacion As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents txtcedulacta As System.Windows.Forms.TextBox
    Friend WithEvents gluccosto As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView5 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents chkempemfcatastrofica As System.Windows.Forms.CheckBox
    Friend WithEvents chkemfcatastrifica As System.Windows.Forms.CheckBox
    Friend WithEvents chkimprenta As System.Windows.Forms.CheckBox
    Friend WithEvents chkutilidad As System.Windows.Forms.CheckBox

End Class
