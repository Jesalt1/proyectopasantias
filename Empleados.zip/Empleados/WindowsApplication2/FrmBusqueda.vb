﻿Imports libreria
Imports DevExpress.XtraEditors
Imports System.Data.SqlClient

Public Class FrmBusqueda
    Dim lwiopcion As Integer
    Dim Tabla As New DataTable
    Dim lwiDepartamento As Integer
    Sub New(ByVal opcion As Integer, Optional ByVal CodDpto As Integer = 0)
        lwiopcion = opcion
        lwiDepartamento = CodDpto
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub

    Private Sub FrmBusqueda_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Call CrearTabla()
        Catch ex As Exception
            XtraMessageBox.Show("error.. " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub CrearTabla()
        Select Case lwiopcion
            Case 1
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. SECTORIAL", GetType(String)))
                Tabla.Columns.Add(New DataColumn("CONCEPTO", GetType(String)))
                Tabla.Columns.Add(New DataColumn("MONTO", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. SECTORIAL").Width = 100
                GridView1.Columns("CONCEPTO").Width = 220
                GridView1.Columns("MONTO").Width = 100

            Case 2
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. DPTO", GetType(Integer)))
                Tabla.Columns.Add(New DataColumn("DESCRIPCION", GetType(String)))
                Tabla.Columns.Add(New DataColumn("CUENTA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. DPTO").Width = 100
                GridView1.Columns("DESCRIPCION").Width = 220
                GridView1.Columns("CUENTA").Width = 100


            Case 3
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. CARGO", GetType(Integer)))
                Tabla.Columns.Add(New DataColumn("DESCRIPCION", GetType(String)))
                Tabla.Columns.Add(New DataColumn("ABREVIATURA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. CARGO").Width = 100
                GridView1.Columns("DESCRIPCION").Width = 220
                GridView1.Columns("ABREVIATURA").Width = 100

            Case 4
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. SECTOR.", GetType(String)))
                Tabla.Columns.Add(New DataColumn("SECTOR", GetType(String)))
                Tabla.Columns.Add(New DataColumn("ABREVIATURA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. SECTOR.").Width = 100
                GridView1.Columns("SECTOR").Width = 220
                GridView1.Columns("ABREVIATURA").Width = 100

            Case 5
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. NAC.", GetType(String)))
                Tabla.Columns.Add(New DataColumn("NACIONALIDAD", GetType(String)))
                Tabla.Columns.Add(New DataColumn("ABREVIATURA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. NAC.").Width = 100
                GridView1.Columns("NACIONALIDAD").Width = 220
                GridView1.Columns("ABREVIATURA").Width = 100

            Case 6
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. EST.", GetType(Integer)))
                Tabla.Columns.Add(New DataColumn("EDUCACION", GetType(String)))
                Tabla.Columns.Add(New DataColumn("ABREVIATURA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. EST.").Width = 100
                GridView1.Columns("EDUCACION").Width = 220
                GridView1.Columns("ABREVIATURA").Width = 100

            Case 7
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("COD. TITULO.", GetType(Integer)))
                Tabla.Columns.Add(New DataColumn("DESCRIPCION", GetType(String)))
                Tabla.Columns.Add(New DataColumn("ABREVIATURA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("COD. TITULO.").Width = 100
                GridView1.Columns("DESCRIPCION").Width = 220
                GridView1.Columns("ABREVIATURA").Width = 100

            Case 8
                Tabla.Columns.Clear()
                Tabla.Rows.Clear()
                Tabla.Columns.Add(New DataColumn("CODIGO", GetType(Integer)))
                Tabla.Columns.Add(New DataColumn("CIUDAD", GetType(String)))
                Tabla.Columns.Add(New DataColumn("PROVINCIA", GetType(String)))

                GridView1.Columns.Clear()
                GridView1.OptionsView.ColumnAutoWidth = False
                GridView1.OptionsPrint.AutoWidth = False
                GridView1.BestFitColumns()

                GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
                GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
                GridControl1.DataSource = Nothing

                GridView1.OptionsView.ShowGroupPanel = False
                GridControl1.DataSource = Tabla
                GridView1.Columns("CODIGO").Width = 100
                GridView1.Columns("CIUDAD").Width = 220
                GridView1.Columns("PROVINCIA").Width = 100

        End Select
    End Sub

    Sub BusquedaGeneral()
        Dim ocon As SqlConnection
        Dim ocomand As SqlCommand
        Dim ors As SqlDataReader
        Dim gconextion As gConnectionSql.gConnection

        gconextion = New gConnectionSql.gConnection
        ocon = Nothing

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            Tabla.Rows.Clear()
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub

            ocomand = New SqlCommand
            With ocomand
                Select Case lwiopcion
                    Case 1
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "sectorial")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim)
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 2
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "departamento")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim)
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 3
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "cargo")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_codDpto", lwiDepartamento)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim)
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 4
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "sector")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim)
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 5
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Nacionalidad")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim)
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 6
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Estudios")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim)
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 7
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Titulos")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim & "%")
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                    Case 8
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Ciudad")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        If IsNumeric(txtBusqueda.Text) Then
                            .Parameters.AddWithValue("@i_Tbusqueda", 1)
                            .Parameters.AddWithValue("@i_busqueda", txtBusqueda.Text.Trim & "%")
                        Else
                            .Parameters.AddWithValue("@i_Tbusqueda", 2)
                            .Parameters.AddWithValue("@i_busqueda", "%" & txtBusqueda.Text.Trim & "%")
                        End If

                End Select
            End With
            ors = ocomand.ExecuteReader()

            If ors.HasRows Then
                Select Case lwiopcion
                    Case 1
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("Monto"))
                        End While

                        GridView1.Columns("COD. SECTORIAL").OptionsColumn.AllowEdit = False
                        GridView1.Columns("CONCEPTO").OptionsColumn.AllowEdit = False
                        GridView1.Columns("MONTO").OptionsColumn.AllowEdit = False

                    Case 2
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("Cuenta"))
                        End While

                        GridView1.Columns("COD. DPTO").OptionsColumn.AllowEdit = False
                        GridView1.Columns("DESCRIPCION").OptionsColumn.AllowEdit = False
                        GridView1.Columns("CUENTA").OptionsColumn.AllowEdit = False

                    Case 3
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("abreviatura"))
                        End While

                        GridView1.Columns("COD. CARGO").OptionsColumn.AllowEdit = False
                        GridView1.Columns("DESCRIPCION").OptionsColumn.AllowEdit = False
                        GridView1.Columns("ABREVIATURA").OptionsColumn.AllowEdit = False
                    Case 4
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("abreviatura"))
                        End While

                        GridView1.Columns("COD. SECTOR.").OptionsColumn.AllowEdit = False
                        GridView1.Columns("SECTOR").OptionsColumn.AllowEdit = False
                        GridView1.Columns("ABREVIATURA").OptionsColumn.AllowEdit = False

                    Case 5
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("abreviatura"))
                        End While

                        GridView1.Columns("COD. NAC.").OptionsColumn.AllowEdit = False
                        GridView1.Columns("NACIONALIDAD").OptionsColumn.AllowEdit = False
                        GridView1.Columns("ABREVIATURA").OptionsColumn.AllowEdit = False

                    Case 6
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("abreviatura"))
                        End While

                        GridView1.Columns("COD. EST.").OptionsColumn.AllowEdit = False
                        GridView1.Columns("EDUCACION").OptionsColumn.AllowEdit = False
                        GridView1.Columns("ABREVIATURA").OptionsColumn.AllowEdit = False

                    Case 7
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("clave"), ors.Item("descripcion"), ors.Item("abreviatura"))
                        End While

                        GridView1.Columns("COD. TITULO.").OptionsColumn.AllowEdit = False
                        GridView1.Columns("DESCRIPCION").OptionsColumn.AllowEdit = False
                        GridView1.Columns("ABREVIATURA").OptionsColumn.AllowEdit = False

                    Case 8
                        While ors.Read
                            Tabla.Rows.Add(ors.Item("CODIGO"), ors.Item("NOMBRE"), ors.Item("PROVINCIA"))
                        End While

                        GridView1.Columns("CODIGO").OptionsColumn.AllowEdit = False
                        GridView1.Columns("CIUDAD").OptionsColumn.AllowEdit = False
                        GridView1.Columns("PROVINCIA").OptionsColumn.AllowEdit = False

                End Select

                ors.Close()
            End If

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        Catch ex As Exception
            Throw ex
        Finally
            If ocon.State = ConnectionState.Open Then
                ocon.Close()
            End If
            ors = Nothing
            ocon = Nothing
            ocomand = Nothing
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Call BusquedaGeneral()
        Catch ex As Exception
            XtraMessageBox.Show("error.. " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try        
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        Me.Dispose()
    End Sub

    Private Sub mnuconsultar_Click(sender As Object, e As EventArgs) Handles mnuconsultar.Click
        Try
            If Tabla.Rows.Count > 0 Then
                Select lwiopcion
                    Case 1
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. SECTORIAL")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("CONCEPTO")

                        Me.Dispose()

                    Case 2
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. DPTO")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("DESCRIPCION")

                        Me.Dispose()

                    Case 3
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. CARGO")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("DESCRIPCION")

                        Me.Dispose()

                    Case 4
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. SECTOR.")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("SECTOR")

                        Me.Dispose()

                    Case 5
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. NAC.")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("NACIONALIDAD")

                        Me.Dispose()

                    Case 6
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. EST.")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("EDUCACION")

                        Me.Dispose()

                    Case 7
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("COD. TITULO.")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("DESCRIPCION")

                        Me.Dispose()

                    Case 8
                        clsVItems.items = ""
                        clsVItems.descripcion = ""
                        clsVItems.items = GridView1.GetFocusedRowCellValue("CODIGO")
                        clsVItems.descripcion = GridView1.GetFocusedRowCellValue("CIUDAD")

                        Me.Dispose()
                End Select
            Else
                XtraMessageBox.Show("No existen registros", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub GridView1_DoubleClick(sender As Object, e As EventArgs) Handles GridView1.DoubleClick
        Call mnuconsultar.PerformClick()
    End Sub
End Class