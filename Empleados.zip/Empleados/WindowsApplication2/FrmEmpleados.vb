﻿Imports libreria
Imports DevExpress.XtraEditors
Imports System.Data.SqlClient
Imports DevExpress.XtraEditors.Repository
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraEditors.Controls

Public Class FrmEmpleados
    Dim scommand As String
    Dim Tabla As New DataTable("Empleados")
    Dim Tabla1 As New DataTable("CargaF")
    Dim Tabla_Ctble As New DataTable("Ctble")
    Dim mainStatusBar As New StatusBar()
    Dim statusPanel As New StatusBarPanel()
    Dim datetimePanel As New StatusBarPanel()
    Dim lwiTipoIdent As ClsItemsData
    Dim lwiTipoFamiliar As ClsItemsData
    Dim lwiSexofamiliar As ClsItemsData
    Dim lwiEstadocivil As ClsItemsData
    Dim lwisexo As ClsItemsData
    Dim lwiTipoCuenta As ClsItemsData
    Dim lwiTipoLiq As ClsItemsData
    Dim lwiTipoIR As ClsItemsData
    Dim lwiClaseEmpl As ClsItemsData
    Dim xmlEmpleado As XDocument
    Dim max_compania As Integer, bload As Boolean
    Dim lwifila As Integer
    Dim lwiaccion As Integer
    Dim rilproyecto As New RepositoryItemLookUpEdit()
    Dim rilsector As New RepositoryItemLookUpEdit()
    Dim rilactividad As New RepositoryItemLookUpEdit()
    Dim rilsubactividad As New RepositoryItemLookUpEdit()
    Dim Tabla_Proyecto As New DataTable("Proyecto")
    Dim Tabla_Sector As New DataTable("Sector")
    Dim Tabla_Actividad As New DataTable("Actividad")
    Dim Tabla_Subactividad As New DataTable("Subactividad")
    Dim Tabla_CCosto As New DataTable("Tabla_CCosto")
    Dim tipo_carga As Integer = 1
    Sub New()
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        scommand = Microsoft.VisualBasic.Interaction.Command()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub
    Sub New(ByVal iscommand As String)
        ' Llamada necesaria para el diseñador.
        InitializeComponent()
        scommand = iscommand
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub


    Private Sub StatusBar()
        statusPanel.BorderStyle = StatusBarPanelBorderStyle.Sunken
        statusPanel.Text = ""
        statusPanel.ToolTipText = "Mensajes de Sistemas " & NOMBRE_SISTEMA
        statusPanel.AutoSize = StatusBarPanelAutoSize.Spring
        mainStatusBar.Panels.Add(statusPanel)
        datetimePanel.BorderStyle = StatusBarPanelBorderStyle.Raised
        datetimePanel.ToolTipText = "Fecha Hora: " + System.DateTime.Today.ToString()
        datetimePanel.Text = System.DateTime.Today.ToLongDateString()
        datetimePanel.AutoSize = StatusBarPanelAutoSize.Contents
        mainStatusBar.Panels.Add(datetimePanel)
        mainStatusBar.ShowPanels = True
        Controls.Add(mainStatusBar)
    End Sub

    Sub seteo_boton(ByVal opcion As Boolean)
        Try
            mnunuevo.Enabled = Not opcion
            mnumodificar.Enabled = Not opcion
            mnuanular.Enabled = Not opcion
            mnuconsultar.Enabled = Not opcion
            mnugrabar.Enabled = opcion
            mnucancelar.Enabled = opcion
            pnlfondo.Enabled = opcion
            pnlfondo.Visible = opcion
            pnlfrente.Enabled = Not opcion
            pnlfrente.Visible = Not opcion
            plcfiltro.Enabled = Not opcion
            cmbCompania.Enabled = Not opcion
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Sub Cargar_Combos()
        Try
            cmbTipo.Items.Add(New ClsItemsData("CEDULA", 1))
            cmbTipo.Items.Add(New ClsItemsData("RUC", 2))
            cmbTipo.Items.Add(New ClsItemsData("PASAPORTE", 3))
            cmbTipo.SelectedIndex = 0

            cmbsexo.Items.Add(New ClsItemsData("MASCULINO", 1))
            cmbsexo.Items.Add(New ClsItemsData("FEMENINO", 2))
            cmbsexo.SelectedIndex = 0

            cmbsexoFamiliar.Items.Add(New ClsItemsData("MASCULINO", 1))
            cmbsexoFamiliar.Items.Add(New ClsItemsData("FEMENINO", 2))
            cmbsexoFamiliar.SelectedIndex = 0

            cmbTipoCta.Items.Add(New ClsItemsData("AHORRO", 1))
            cmbTipoCta.Items.Add(New ClsItemsData("CORRIENTE", 2))
            cmbTipoCta.Items.Add(New ClsItemsData("TARJETA PAGO", 3))
            cmbTipoCta.Items.Add(New ClsItemsData("NO TIENE", 4))
            cmbTipoCta.SelectedIndex = 0

            cmbclaseEmpleado.Items.Add(New ClsItemsData("NORMAL", 1))
            cmbclaseEmpleado.Items.Add(New ClsItemsData("COMICIONISTA", 2))
            cmbclaseEmpleado.Items.Add(New ClsItemsData("PUERTA A PUERTA", 3))
            cmbclaseEmpleado.Items.Add(New ClsItemsData("SERVICIOS PRESTADOS", 4))
            cmbclaseEmpleado.Items.Add(New ClsItemsData("PASANTE", 5))
            cmbclaseEmpleado.SelectedIndex = 0

            cmbestadocivil.Items.Add(New ClsItemsData("SOLTERO", 1))
            cmbestadocivil.Items.Add(New ClsItemsData("CASADO", 2))
            cmbestadocivil.Items.Add(New ClsItemsData("DIVORCIADO", 3))
            cmbestadocivil.Items.Add(New ClsItemsData("UNIDO", 4))
            cmbestadocivil.SelectedIndex = 0

            cmbtipoLiqui.Items.Add(New ClsItemsData("MENSUAL", 1))
            cmbtipoLiqui.Items.Add(New ClsItemsData("QUINCENAL", 2))
            cmbtipoLiqui.Items.Add(New ClsItemsData("SEMANAL", 3))
            cmbtipoLiqui.SelectedIndex = 0

            cmbtipoFamiliar.Items.Add(New ClsItemsData("CONYUGUE", 1))
            cmbtipoFamiliar.Items.Add(New ClsItemsData("HIJO", 2))
            cmbtipoFamiliar.SelectedIndex = 0

            cmbTcalculoIR.Items.Add(New ClsItemsData("A - Normal", 1))
            cmbTcalculoIR.Items.Add(New ClsItemsData("B - IESS NO Asumido IR ASUMIDO", 2))
            cmbTcalculoIR.Items.Add(New ClsItemsData("C - IR ASUMIDO", 3))
            cmbTcalculoIR.Items.Add(New ClsItemsData("D - IESS NO Asumido", 4))
            cmbTcalculoIR.SelectedIndex = 0

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Sub CrearTable()
        Try
            Tabla.Columns.Clear()
            Tabla.Rows.Clear()
            Tabla.Columns.Add(New DataColumn("CÓDIGO", GetType(Integer)))
            Tabla.Columns.Add(New DataColumn("TIPO_RUC", GetType(String)))
            Tabla.Columns.Add(New DataColumn("RUC", GetType(String)))
            Tabla.Columns.Add(New DataColumn("NOMBRE", GetType(String)))
            Tabla.Columns.Add(New DataColumn("DIRECCIÓN", GetType(String)))
            Tabla.Columns.Add(New DataColumn("ESTADO", GetType(String)))

            GridView1.Columns.Clear()
            GridView1.OptionsView.ColumnAutoWidth = False
            GridView1.OptionsPrint.AutoWidth = False
            GridView1.BestFitColumns()

            GridView1.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
            GridView1.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
            GridControl1.DataSource = Nothing

            GridView1.OptionsView.ShowGroupPanel = True
            GridControl1.DataSource = Tabla
            GridView1.Columns("CÓDIGO").Width = 60
            GridView1.Columns("TIPO_RUC").Width = 80
            GridView1.Columns("RUC").Width = 100
            GridView1.Columns("NOMBRE").Width = 230
            GridView1.Columns("DIRECCIÓN").Width = 200
            GridView1.Columns("ESTADO").Width = 60


            Tabla1.Columns.Clear()
            Tabla1.Rows.Clear()
            Tabla1.Columns.Add(New DataColumn("TIPOF", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("NOMBREF", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("FECHANACF", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("SEXOF", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("ESTADOF", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("SECUEF", GetType(Integer)))
            Tabla1.Columns.Add(New DataColumn("APORTA", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("UTILIDAD", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("IMPRENTA", GetType(String)))
            Tabla1.Columns.Add(New DataColumn("ECATASTROFICA", GetType(String)))

            GridView2.Columns.Clear()
            GridView2.OptionsView.ColumnAutoWidth = False
            GridView2.OptionsPrint.AutoWidth = False
            GridView2.BestFitColumns()

            GridView2.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
            GridView2.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
            GrdCargaFamiliar.DataSource = Nothing

            GridView2.OptionsView.ShowGroupPanel = True
            GrdCargaFamiliar.DataSource = Tabla1
            GridView2.Columns("TIPOF").Width = 80
            GridView2.Columns("NOMBREF").Width = 250
            GridView2.Columns("FECHANACF").Width = 90
            GridView2.Columns("SEXOF").Width = 80
            GridView2.Columns("ESTADOF").Width = 80
            GridView2.Columns("SECUEF").Width = 80
            GridView2.Columns("APORTA").Width = 60

            '*********************************************
            '*********************************************
            '*********************************************
            Tabla_Ctble.Columns.Clear()
            Tabla_Ctble.Rows.Clear()
            Tabla_Ctble.Columns.Add(New DataColumn("-", GetType(Boolean)))
            Tabla_Ctble.Columns.Add(New DataColumn("iddepartamento", GetType(Integer)))
            Tabla_Ctble.Columns.Add(New DataColumn("Departamento", GetType(String)))
            Tabla_Ctble.Columns.Add(New DataColumn("Cuenta", GetType(String)))
            Tabla_Ctble.Columns.Add(New DataColumn("Proyecto", GetType(String)))
            Tabla_Ctble.Columns.Add(New DataColumn("Sector", GetType(String)))
            Tabla_Ctble.Columns.Add(New DataColumn("Actividad", GetType(String)))
            Tabla_Ctble.Columns.Add(New DataColumn("Subactividad", GetType(String)))
            Tabla_Ctble.Columns.Add(New DataColumn("Porcentaje", GetType(Double)))

            GridView3.Columns.Clear()
            GridView3.OptionsView.ColumnAutoWidth = False
            GridView3.OptionsPrint.AutoWidth = False
            GridView3.BestFitColumns()

            GridView3.ScrollStyle = DevExpress.XtraGrid.Views.Grid.ScrollStyleFlags.LiveHorzScroll
            GridView3.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Always
            GridControl2.DataSource = Nothing
            GridView3.OptionsNavigation.EnterMoveNextColumn = True

            GridView3.OptionsView.ShowGroupPanel = True
            GridControl2.DataSource = Tabla_Ctble
            GridView3.Columns("-").Width = 30
            GridView3.Columns("iddepartamento").Visible = False
            GridView3.Columns("Departamento").Width = 120
            GridView3.Columns("Cuenta").Width = 80
            GridView3.Columns("Proyecto").Width = 80
            GridView3.Columns("Sector").Width = 80
            GridView3.Columns("Actividad").Width = 80
            GridView3.Columns("Subactividad").Width = 80
            GridView3.Columns("Porcentaje").Width = 80


            rilproyecto.DataSource = Tabla_Proyecto
            rilproyecto.ValueMember = "Codigo"
            rilproyecto.DisplayMember = "Descripcion"
            rilproyecto.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            rilproyecto.DropDownRows = Tabla_Proyecto.Rows.Count
            rilproyecto.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoComplete
            rilproyecto.AutoSearchColumnIndex = 1
            GridView3.Columns("Proyecto").ColumnEdit = rilproyecto
            rilproyecto.Properties.PopupFormMinSize = New Size(500, 250)

            rilsector.DataSource = Tabla_Sector
            rilsector.ValueMember = "Codigo"
            rilsector.DisplayMember = "Descripcion"
            rilsector.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            rilsector.DropDownRows = Tabla_Proyecto.Rows.Count
            rilsector.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoComplete
            rilsector.AutoSearchColumnIndex = 1
            GridView3.Columns("Sector").ColumnEdit = rilsector
            rilsector.Properties.PopupFormMinSize = New Size(500, 250)


            rilactividad.DataSource = Tabla_Actividad
            rilactividad.ValueMember = "Codigo"
            rilactividad.DisplayMember = "Descripcion"
            rilactividad.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            rilactividad.DropDownRows = Tabla_Proyecto.Rows.Count
            rilactividad.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoComplete
            rilactividad.AutoSearchColumnIndex = 1
            GridView3.Columns("Actividad").ColumnEdit = rilactividad
            rilactividad.Properties.PopupFormMinSize = New Size(500, 250)

            rilsubactividad.DataSource = Tabla_Subactividad
            rilsubactividad.ValueMember = "Codigo"
            rilsubactividad.DisplayMember = "Descripcion"
            rilsubactividad.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            rilsubactividad.DropDownRows = Tabla_Proyecto.Rows.Count
            rilsubactividad.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoComplete
            rilsubactividad.AutoSearchColumnIndex = 1
            GridView3.Columns("Subactividad").ColumnEdit = rilsubactividad
            rilsubactividad.Properties.PopupFormMinSize = New Size(500, 250)
            GridView3.OptionsBehavior.EditingMode = GridEditingMode.EditFormInplace


            Tabla_CCosto.Clear()
            Tabla_CCosto.Rows.Clear()
            Tabla_CCosto.Columns.Add(New DataColumn("CCosto", GetType(String)))
            Tabla_CCosto.Columns.Add(New DataColumn("Centro_Costo", GetType(String)))
            Tabla_CCosto.Columns.Add(New DataColumn("Padre_CCosto", GetType(String)))

            gluccosto.Properties.View.OptionsBehavior.AutoPopulateColumns = False
            gluccosto.Properties.DataSource = Tabla_CCosto
            gluccosto.Properties.DisplayMember = "Centro_Costo"
            gluccosto.Properties.ValueMember = "CCosto"
            gluccosto.Properties.View.Columns.AddField("CCosto")
            gluccosto.Properties.View.Columns.AddField("Centro_Costo")
            gluccosto.Properties.View.Columns.AddField("Padre_CCosto")
            gluccosto.Properties.View.Columns("CCosto").Caption = "Cto.Costo"
            gluccosto.Properties.View.Columns("CCosto").Visible = True
            gluccosto.Properties.View.Columns("CCosto").Width = 50
            gluccosto.Properties.View.Columns("Centro_Costo").Caption = "Des Cto.Costo"
            gluccosto.Properties.View.Columns("Centro_Costo").Visible = True
            gluccosto.Properties.View.Columns("Centro_Costo").Width = 150
            gluccosto.Properties.View.Columns("Padre_CCosto").Caption = "Padre Cto.Costo"
            gluccosto.Properties.View.Columns("Padre_CCosto").Visible = True
            gluccosto.Properties.View.Columns("Padre_CCosto").Width = 150

            gluccosto.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
            gluccosto.Properties.View.BestFitColumns(True)
            gluccosto.Properties.PopupFormWidth = 800
            gluccosto.Properties.PopupFilterMode = PopupFilterMode.StartsWith
            gluccosto.Properties.ShowFooter = True
            ' cmbempleado.EditValue = IIf(CType(cmbempleado.Properties.DataSource, DataTable).Rows.Count > 0, cmbempleado.Properties.GetKeyValue(0), cmbempleado.Properties.GetKeyValue(-1))
            gluccosto.EditValue = -1 'IIf(CType(cmbempleado.Properties.DataSource, DataTable).Rows.Count > 0, CType(cmbempleado.Properties.DataSource, DataTable).Rows(0).Item(0).ToString, cmbempleado.Properties.GetIndexByKeyValue(-1))
            gluccosto.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
            gluccosto.Properties.ImmediatePopup = True
            gluccosto.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    'Private Sub llenar_CCosto()

    '    Dim oCon As SqlConnection
    '    Dim oComand As SqlCommand
    '    Dim dt As New DataSet
    '    Dim dtadap As SqlDataAdapter
    '    Dim dats As New DataSet
    '    Dim oconexion As gConnectionSql.gConnection
    '    oconexion = New gConnectionSql.gConnection
    '    Try
    '        oCon = Nothing
    '        If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
    '        oComand = New SqlCommand
    '        dats.Clear()
    '        With oComand
    '            .CommandTimeout = 0
    '            .CommandText = "ROLSp_Mant_Personal"
    '            .Connection = oCon
    '            .CommandType = CommandType.StoredProcedure
    '            .Parameters.AddWithValue("@i_operacion", "Cons_empleado")
    '            .Parameters.AddWithValue("@i_compania", compania)

    '        End With
    '        dtadap = New SqlDataAdapter(oComand)
    '        dtadap.Fill(dats)
    '        oCon.Close()
    '        cmbempleado.Properties.DataSource = dats.Tables(0)
    '        cmbempleado.Properties.DisplayMember = "Nombre"
    '        cmbempleado.Properties.ValueMember = "Codigo"
    '        max_empleado = dats.Tables(0).Rows.Count

    '        cmbempleado.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup
    '        cmbempleado.Properties.View.BestFitColumns(True)
    '        cmbempleado.Properties.PopupFormWidth = 800
    '        cmbempleado.Properties.PopupFilterMode = PopupFilterMode.StartsWith
    '        cmbempleado.Properties.ShowFooter = True
    '        ' cmbempleado.EditValue = IIf(CType(cmbempleado.Properties.DataSource, DataTable).Rows.Count > 0, cmbempleado.Properties.GetKeyValue(0), cmbempleado.Properties.GetKeyValue(-1))
    '        cmbempleado.EditValue = -1 'IIf(CType(cmbempleado.Properties.DataSource, DataTable).Rows.Count > 0, CType(cmbempleado.Properties.DataSource, DataTable).Rows(0).Item(0).ToString, cmbempleado.Properties.GetIndexByKeyValue(-1))
    '        cmbempleado.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
    '        cmbempleado.Properties.ImmediatePopup = True
    '        cmbempleado.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard
    '        oComand = Nothing
    '        oCon.Close()
    '        oCon = Nothing




    '    Catch ex As Exception
    '        XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    End Try
    'End Sub
    Private Sub optPorcedula_CheckedChanged(sender As Object, e As EventArgs) Handles optPorcedula.CheckedChanged
        If optTodos.Checked = True Then
            txtbus.Text = ""
            txtbus.Enabled = False
        Else
            txtbus.Enabled = True
        End If
    End Sub

    Private Sub optPorCodigo_CheckedChanged(sender As Object, e As EventArgs) Handles optPorCodigo.CheckedChanged
        If optTodos.Checked = True Then
            txtbus.Text = ""
            txtbus.Enabled = False
        Else
            txtbus.Enabled = True
        End If
    End Sub

    Private Sub optPorNombre_CheckedChanged(sender As Object, e As EventArgs) Handles optPorNombre.CheckedChanged
        If optTodos.Checked = True Then
            txtbus.Text = ""
            txtbus.Enabled = False
        Else
            txtbus.Enabled = True
        End If
    End Sub

    Private Sub optTodos_CheckedChanged(sender As Object, e As EventArgs) Handles optTodos.CheckedChanged
        If optTodos.Checked = True Then
            txtbus.Text = ""
            txtbus.Enabled = False
        Else
            txtbus.Enabled = True
        End If
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        Try
            Call Cargar_Empleados()
        Catch ex As Exception
            XtraMessageBox.Show("Error al cargar empleados: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub Cargar_Empleados()
        Dim ocon As SqlConnection
        Dim ocomand As SqlCommand
        Dim ors As SqlDataReader
        Dim gconextion As New gConnectionSql.gConnection

        ocon = Nothing
        If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub
        ocomand = New SqlCommand

        Tabla.Rows.Clear()

        Try
            With ocomand
                .CommandTimeout = 0
                .CommandText = "ROLSp_MantEmpleado"
                .Connection = ocon
                .CommandType = CommandType.StoredProcedure
                If optPorcedula.Checked = True Then
                    .Parameters.AddWithValue("@i_operacion", "query_ruc")
                End If
                If optPorCodigo.Checked = True Then
                    .Parameters.AddWithValue("@i_operacion", "query_cod")
                End If
                If optPorNombre.Checked = True Then
                    .Parameters.AddWithValue("@i_operacion", "query_nom")
                End If
                If optTodos.Checked = True Then
                    .Parameters.AddWithValue("@i_operacion", "query_tod")
                End If
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                .Parameters.AddWithValue("@i_opcion", Me.txtbus.Text.Trim)
                .Parameters.AddWithValue("@i_ESTADO", IIf(Me.chkInactivos.Checked = True, "I", "A"))
            End With
            ors = ocomand.ExecuteReader()
            If ors.HasRows Then
                While ors.Read
                    Tabla.Rows.Add(ors.Item("CODIGO"), ors.Item("TIPO_RUC"), ors.Item("RUC"), ors.Item("NOMBRE"), ors.Item("DIRECCION"), ors.Item("ESTADO"))
                End While

                GridView1.Columns("CÓDIGO").OptionsColumn.AllowEdit = False
                GridView1.Columns("TIPO_RUC").OptionsColumn.AllowEdit = False
                GridView1.Columns("RUC").OptionsColumn.AllowEdit = False
                GridView1.Columns("NOMBRE").OptionsColumn.AllowEdit = False
                GridView1.Columns("DIRECCIÓN").OptionsColumn.AllowEdit = False
                GridView1.Columns("ESTADO").OptionsColumn.AllowEdit = False

                ors.Close()
            End If

        Catch ex As Exception
            Throw ex
        Finally
            If ocon.State = ConnectionState.Open Then
                ocon.Close()
            End If
            ors = Nothing
            ocon = Nothing
            ocomand = Nothing
        End Try
    End Sub

    Private Sub mnunuevo_Click(sender As Object, e As EventArgs) Handles mnunuevo.Click
        igaccion = 1
        Call mLimpiarControles()
        seteo_boton(True)
        chkestado.Checked = True
        chkestado.Enabled = False
        chkPagomensualBeneficios.Checked = False
        chkpagafondo.Checked = True
        chkprueba.Checked = True
        chkbono.Checked = False
    End Sub

    Private Sub mLimpiarControles()
        txtcodigo.Text = ""
        cmbTipo.SelectedIndex = IIf(cmbTipo.Items.Count > 0, 0, -1)
        TxtCedula_Ruc.Text = ""
        TxtNombre.Text = ""
        TxtDireccion.Text = ""
        txtTelefono.Text = ""
        dtpfechaIngreso.Value = Date.Now.Date
        dtpfechaEgreso.Value = Format(CDate("01/01/1900"), "dd/MM/yyyy")
        dtpfechaNacimiento.Value = Format(CDate("01/01/1900"), "dd/MM/yyyy")
        cmbsexo.SelectedIndex = IIf(cmbsexo.Items.Count > 0, 0, -1)
        dtpfechaTermiContrato.Value = Format(CDate("01/01/1900"), "dd/MM/yyyy")
        dtpfechaTermiContrato.Enabled = False
        txtcedMilitar.Text = ""
        txtCarnetIess.Text = ""
        txtCodCiudad.Text = ""
        txtlugarNaci.Text = ""
        cmbTipoCta.SelectedIndex = IIf(cmbTipoCta.Items.Count > 0, 0, -1)
        txtNumCta.Text = ""
        cmbclaseEmpleado.SelectedIndex = IIf(cmbclaseEmpleado.Items.Count > 0, 0, -1)
        cmbtipoLiqui.SelectedIndex = IIf(cmbsexo.Items.Count > 0, 0, -1)
        cmbestadocivil.SelectedIndex = IIf(cmbestadocivil.Items.Count > 0, 0, -1)
        txtMatriculaPortuaria.Text = ""
        txtTipoSangre.Text = ""
        chkacredita.Checked = False
        chkbeneficios.Checked = True
        chkestado.Checked = True
        chkPagomensualBeneficios.Checked = False
        chkprueba.Checked = True
        chkbono.Checked = False
        txtcodsectorial.Text = ""
        lblsectorial.Text = ""
        txtdepartamento.Text = ""
        lbldepartamento.Text = ""
        txtcargo.Text = ""
        lblcargo.Text = ""
        txtsector.Text = ""
        lblsector.Text = ""
        txtnacionalidad.Text = ""
        lblnacionalidad.Text = ""
        txtestudios.Text = ""
        lblestudios.Text = ""
        txttitulo.Text = ""
        lbltitulo.Text = ""
        txtSueldoBasicoMen.Text = "0.00"
        txtSueldoExtraMen.Text = "0.00"
        txtMoviQuincenal.Text = "0.00"
        txtalimentacion.Text = "0.00"
        TxtNombreFamiliar.Text = ""
        cmbtipoFamiliar.SelectedIndex = IIf(cmbtipoFamiliar.Items.Count > 0, 0, -1)
        cmbsexoFamiliar.SelectedIndex = IIf(cmbsexoFamiliar.Items.Count > 0, 0, -1)
        chkestadoFamiliar.Checked = True
        txtctacble.Text = ""
        txtemail.Text = ""
        txtcedulacta.Text = ""
        Call limpiar_detalle()
        Tabla1.Rows.Clear()
        pbximagen.Image = Nothing
        chkpagootro.Checked = False
        lwiaccion = 0
    End Sub

    Sub limpiar_detalle()
        TxtNombreFamiliar.Text = ""
        cmbtipoFamiliar.SelectedIndex = 0
        cmbsexoFamiliar.SelectedIndex = 0
        dtpfechanac.Value = Date.Now.Date
        chkestadoFamiliar.Checked = True
        chkaporta.Checked = False
        chkutilidad.Checked = False
        chkimprenta.Checked = False
        chkemfcatastrifica.Checked = False
    End Sub

    Private Sub mnusalir_Click(sender As Object, e As EventArgs) Handles mnusalir.Click
        Me.Dispose()
    End Sub

    Private Sub mnucancelar_Click(sender As Object, e As EventArgs) Handles mnucancelar.Click
        Call mLimpiarControles()
        seteo_boton(False)
        chkPagomensualBeneficios.Checked = False
    End Sub

    Private Sub mnumodificar_Click(sender As Object, e As EventArgs) Handles mnumodificar.Click
        Try
            igaccion = 2
            Call seleccionar("Modificar")
            If pwinumero = Nothing Then Exit Sub
            Call mLimpiarControles()
            If load_empleado(pwinumero) = False Then Exit Sub
            seteo_boton(True)
        Catch ex As Exception
            XtraMessageBox.Show("Error al buscar registro para modificar: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub seleccionar(Optional ByVal simensaje As String = "")
        Try
            If Tabla.Rows.Count > 0 Then
                pwinumero = GridView1.GetFocusedRowCellValue("CÓDIGO")
            Else
                XtraMessageBox.Show("Escoja el registro a " + simensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Function load_empleado(ByVal siclave As Double) As Boolean
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        Dim connection As New gConnectionSql.gConnection

        load_empleado = False

        oCon = Nothing
        If Not connection.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Function
        oComand = New SqlCommand

        Tabla1.Rows.Clear()

        Try
            With oComand
                .CommandText = "ROLSp_MantEmpleado"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "Query")
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                .Parameters.AddWithValue("@i_empleado", siclave)
                .Parameters.AddWithValue("@i_ESTADO", IIf(Me.chkInactivos.Checked = True, "I", "A"))
            End With
            oRs = oComand.ExecuteReader()
            If oRs.HasRows Then
                If oRs.Read Then
                    txtcodigo.Text = siclave
                    chkestado.Checked = IIf(oRs.Item("estado") = "A", True, False)
                    Select Case UCase(oRs.Item("tipo_id"))
                        Case "C" : Call ubicar_combo(cmbTipo, 1)
                        Case "R" : Call ubicar_combo(cmbTipo, 2)
                        Case "P" : Call ubicar_combo(cmbTipo, 3)
                    End Select
                    TxtCedula_Ruc.Text = oRs.Item("ruc")
                    TxtNombre.Text = oRs.Item("nombre")
                    TxtDireccion.Text = oRs.Item("direccion")
                    txtTelefono.Text = IIf(IsDBNull(oRs.Item("telefono")), 0, oRs.Item("telefono"))
                    dtpfechaIngreso.Value = Format(oRs.Item("fecha_ing"), "dd/MM/yyyy")
                    dtpfechaEgreso.Enabled = IIf(oRs.Item("estado") = "I", True, False)
                    dtpfechaEgreso.Value = Format(oRs.Item("fecha_egreso"), "dd/MM/yyyy")
                    dtpfechaNacimiento.Value = Format(oRs.Item("fecha_nac"), "dd/MM/yyyy")
                    Select Case UCase(Trim(oRs.Item("sexo")))
                        Case "M" : Call ubicar_combo(cmbsexo, 1)
                        Case "F" : Call ubicar_combo(cmbsexo, 2)
                    End Select
                    dtpfechaTermiContrato.Value = Format(oRs.Item("terminoC"), "dd/MM/yyyy")
                    txtcedMilitar.Text = IIf(IsDBNull(oRs.Item("ced_militar")), 0, oRs.Item("ced_militar"))
                    txtCarnetIess.Text = IIf(IsDBNull(oRs.Item("carnet_iess")), 0, oRs.Item("carnet_iess"))
                    Select Case UCase(Trim(oRs.Item("tipoCta")))
                        Case "A" : Call ubicar_combo(cmbTipoCta, 1)
                        Case "C" : Call ubicar_combo(cmbTipoCta, 2)
                        Case "T" : Call ubicar_combo(cmbTipoCta, 3)
                        Case "N" : Call ubicar_combo(cmbTipoCta, 4)
                    End Select
                    txtNumCta.Text = oRs.Item("cuenta")
                    Select Case UCase(Trim(oRs.Item("clase")))
                        Case "N" : Call ubicar_combo(cmbclaseEmpleado, 1)
                        Case "C" : Call ubicar_combo(cmbclaseEmpleado, 2)
                        Case "P" : Call ubicar_combo(cmbclaseEmpleado, 3)
                        Case "S" : Call ubicar_combo(cmbclaseEmpleado, 4)
                        Case "T" : Call ubicar_combo(cmbclaseEmpleado, 5)
                    End Select

                    Select Case UCase(Trim(oRs.Item("tipo_liq")))
                        Case "M" : Call ubicar_combo(cmbtipoLiqui, 1)
                        Case "Q" : Call ubicar_combo(cmbtipoLiqui, 2)
                        Case "S" : Call ubicar_combo(cmbtipoLiqui, 3)
                    End Select

                    Select Case UCase(Trim(oRs.Item("estado_civil")))
                        Case "S" : Call ubicar_combo(cmbestadocivil, 1)
                        Case "C" : Call ubicar_combo(cmbestadocivil, 2)
                        Case "D" : Call ubicar_combo(cmbestadocivil, 3)
                        Case "U" : Call ubicar_combo(cmbestadocivil, 4)
                    End Select
                    Select Case UCase(Trim(oRs.Item("tipo_ir")))
                        Case "A" : Call ubicar_combo(cmbTcalculoIR, 1)
                        Case "B" : Call ubicar_combo(cmbTcalculoIR, 2)
                        Case "C" : Call ubicar_combo(cmbTcalculoIR, 3)
                        Case "D" : Call ubicar_combo(cmbTcalculoIR, 4)
                    End Select
                    txtMatriculaPortuaria.Text = IIf(IsDBNull(oRs.Item("mat_portuaria")), 0, oRs.Item("mat_portuaria"))
                    txtTipoSangre.Text = oRs.Item("tipo_sangre")
                    chkacredita.Checked = IIf(oRs.Item("depcta") = "S", True, False)
                    chkbeneficios.Checked = IIf(oRs.Item("beneficio") = "S", True, False)
                    chkPagomensualBeneficios.Checked = IIf(oRs.Item("relacion") = "S", True, False)
                    txtcodsectorial.Text = IIf(IsDBNull(oRs.Item("sector2")), 0, oRs.Item("sector2"))
                    lblsectorial.Text = oRs.Item("sectorial")
                    txtdepartamento.Text = oRs.Item("iddepartamento")
                    lbldepartamento.Text = oRs.Item("departamento")
                    txtcargo.Text = oRs.Item("idcargo")
                    lblcargo.Text = oRs.Item("cargo")
                    txtsector.Text = IIf(IsDBNull(oRs.Item("idsector")), 0, (oRs.Item("idsector")))
                    lblsector.Text = IIf(IsDBNull(oRs.Item("sector")), 0, oRs.Item("sector"))
                    txtnacionalidad.Text = oRs.Item("idnacionalidad")
                    lblnacionalidad.Text = oRs.Item("nacionalidad")
                    txtestudios.Text = oRs.Item("idestudio")
                    lblestudios.Text = oRs.Item("estudio")
                    txttitulo.Text = oRs.Item("idtitulo")
                    lbltitulo.Text = oRs.Item("titulo")
                    txtSueldoBasicoMen.Text = Format(oRs.Item("sueldo"), "###,###,###,##0.00")
                    txtSueldoExtraMen.Text = Format(oRs.Item("extra"), "###,###,###,##0.00")
                    txtMoviQuincenal.Text = Format(oRs.Item("transporte"), "###,###,###,##0.00")
                    txtalimentacion.Text = Format(oRs.Item("alimentacion"), "###,###,###,##0.00")
                    txtCodCiudad.Text = oRs.Item("COD_CIUDAD")
                    txtlugarNaci.Text = IIf(IsDBNull(oRs.Item("lugar_nac")), "", oRs.Item("lugar_nac"))
                    chkDiscapacidad.Checked = IIf(oRs.Item("DISCAPACIDAD") = "1", True, False)
                    txtpordiscapacidad.Text = Format(oRs.Item("por_discapacidad"), "###,###,###,##0")
                    txtbiometrico.Text = oRs.Item("biometrico")
                    txtcodigo_cargo.Text = oRs.Item("cod_cargo")
                    txtcontacto.Text = oRs.Item("contacto")
                    txtobservacion.Text = oRs.Item("observacion")
                    chkpagafondo.Checked = IIf(oRs.Item("paga_fon_res") = "S", True, False)
                    txtctacble.Text = oRs.Item("ctacble")
                    chkprueba.Checked = IIf(oRs.Item("aprueba") = "S", True, False)
                    chkbono.Checked = IIf(oRs.Item("abono") = "S", True, False)
                    txtemail.Text = oRs.Item("email")
                    txtcedulacta.Text = oRs.Item("cedcta")
                    chkempemfcatastrofica.Checked = IIf(oRs.Item("emf_catastrofica") = "S", True, False)

                    'If (IIf(IsDBNull(oRs.Item("foto")), 0, 1)) = 1 Then
                    If IsDBNull(oRs.Item("foto")) = False Then

                        pbximagen.Image = (Bytes_Imagen(oRs.Item("foto")))
                    End If
                    chkpagootro.Checked = IIf(oRs.Item("pago_adicional") = "S", True, False)
                    gluccosto.EditValue = oRs.Item("ctrocto")
                End If
                oRs.Close()

                oComand = Nothing
                oComand = New SqlCommand

                With oComand
                    .CommandText = "ROLSp_MantEmpleado"
                    .Connection = oCon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "CargaF")
                    .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                    .Parameters.AddWithValue("@i_empleado", siclave)
                End With
                oRs = oComand.ExecuteReader()

                If oRs.HasRows Then
                    While oRs.Read
                        Tabla1.Rows.Add(oRs.Item("tipoF"), IIf(IsDBNull(oRs.Item("nombreF")), "", Trim(oRs.Item("nombreF"))), _
                                        Format(oRs.Item("fechanF"), "dd/MM/yyyy"), _
                                        IIf(IsDBNull(oRs.Item("sexoF")), "", Trim(oRs.Item("sexoF"))), _
                                        IIf(IsDBNull(oRs.Item("estadoF")), "", Trim(oRs.Item("estadoF"))), _
                                        IIf(IsDBNull(oRs.Item("SecueF")), 0, oRs.Item("SecueF")), oRs.Item("aporta") _
                                         , oRs.Item("utilidad"), oRs.Item("imp_renta"), oRs.Item("catastrofica")
                                        )
                    End While

                    GridView2.Columns("TIPOF").OptionsColumn.AllowEdit = False
                    GridView2.Columns("NOMBREF").OptionsColumn.AllowEdit = False
                    GridView2.Columns("FECHANACF").OptionsColumn.AllowEdit = False
                    GridView2.Columns("SEXOF").OptionsColumn.AllowEdit = False
                    GridView2.Columns("ESTADOF").OptionsColumn.AllowEdit = False
                    GridView2.Columns("SECUEF").OptionsColumn.AllowEdit = False

                    ''''''''''''''''''''''''''''''AQUI SE AGREGAN LAS NUEVAS COLUMNAS'''''''''''''''''''
                    GridView2.Columns("UTILIDAD").OptionsColumn.AllowEdit = False
                    GridView2.Columns("UTILIDAD").Visible = False
                    GridView2.Columns("IMPRENTA").OptionsColumn.AllowEdit = False
                    GridView2.Columns("ECATASTROFICA").OptionsColumn.AllowEdit = False
                    oRs.Close()
                End If

                load_empleado = True
            End If

        Catch ex As Exception
            load_empleado = False
            Throw ex
        Finally
            oRs = Nothing
            oComand = Nothing
            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oCon = Nothing
        End Try
    End Function

    Private Sub txtbus_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtbus.KeyPress
        SimulaTab(e)
    End Sub

    Sub SimulaTab(ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If

        If InStr(1, "'" & Chr(8), e.KeyChar) = 1 Then
            e.KeyChar = ""
        End If
    End Sub

    Private Sub chkestado_CheckedChanged(sender As Object, e As EventArgs) Handles chkestado.CheckedChanged
        If chkestado.Checked = True Then
            dtpfechaEgreso.Enabled = False
            dtpfechaTermiContrato.Enabled = False
        Else
            dtpfechaEgreso.Enabled = True
            dtpfechaTermiContrato.Enabled = True
            dtpfechaEgreso.Value = Date.Now.Date
            dtpfechaTermiContrato.Value = Date.Now.Date
        End If
    End Sub

    Private Sub cmbclaseEmpleado_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbclaseEmpleado.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbsexo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbsexo.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbestadocivil_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbestadocivil.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbsexoFamiliar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbsexoFamiliar.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbTipo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbTipo.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbtipoFamiliar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbtipoFamiliar.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbtipoLiqui_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbtipoLiqui.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub cmbTipoCta_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbTipoCta.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub mnuconsultar_Click(sender As Object, e As EventArgs) Handles mnuconsultar.Click
        Call mnumodificar_Click(sender, e)
        mnugrabar.Enabled = False
    End Sub

    Private Sub dtpfechaEgreso_KeyPress(sender As Object, e As KeyPressEventArgs) Handles dtpfechaEgreso.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub dtpfechaIngreso_KeyPress(sender As Object, e As KeyPressEventArgs) Handles dtpfechaIngreso.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub dtpfechaNacimiento_KeyPress(sender As Object, e As KeyPressEventArgs) Handles dtpfechaNacimiento.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub dtpfechanac_KeyPress(sender As Object, e As KeyPressEventArgs) Handles dtpfechanac.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub dtpfechaTermiContrato_KeyPress(sender As Object, e As KeyPressEventArgs) Handles dtpfechaTermiContrato.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txttitulo_GotFocus(sender As Object, e As EventArgs) Handles txttitulo.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Titulos."
    End Sub

    Private Sub txttitulo_KeyDown(sender As Object, e As KeyEventArgs) Handles txttitulo.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(7)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txttitulo.Text = clsVItems.items
                Me.lbltitulo.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txttitulo.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txttitulo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txttitulo.KeyPress
        'SimulaTab(e)
        Numeros(e)
    End Sub

    Private Sub txttitulo_LostFocus(sender As Object, e As EventArgs) Handles txttitulo.LostFocus
        statusPanel.Text = ""

        If Me.txttitulo.Text.Trim.Length > 0 Then
            Call BusquedaG(7)
        Else
            lbltitulo.Text = ""
        End If
    End Sub

    Private Sub txttitulo_TextChanged(sender As Object, e As EventArgs) Handles txttitulo.TextChanged
        lbltitulo.Text = ""
    End Sub

    Private Sub txtestudios_GotFocus(sender As Object, e As EventArgs) Handles txtestudios.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Estudios."
    End Sub

    Private Sub txtestudios_KeyDown(sender As Object, e As KeyEventArgs) Handles txtestudios.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(6)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtestudios.Text = clsVItems.items
                Me.lblestudios.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtestudios.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtestudios_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtestudios.KeyPress
        'SimulaTab(e)
        Numeros(e)
    End Sub

    Private Sub txtestudios_LostFocus(sender As Object, e As EventArgs) Handles txtestudios.LostFocus
        statusPanel.Text = ""

        If Me.txtestudios.Text.Trim.Length > 0 Then
            Call BusquedaG(6)
        Else
            lblestudios.Text = ""
        End If
    End Sub

    Private Sub txtestudios_TextChanged(sender As Object, e As EventArgs) Handles txtestudios.TextChanged
        lbltitulo.Text = ""
    End Sub

    Private Sub txtnacionalidad_GotFocus(sender As Object, e As EventArgs) Handles txtnacionalidad.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Nacionalidad."
    End Sub

    Private Sub txtnacionalidad_KeyDown(sender As Object, e As KeyEventArgs) Handles txtnacionalidad.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(5)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtnacionalidad.Text = clsVItems.items
                Me.lblnacionalidad.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtnacionalidad.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtnacionalidad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnacionalidad.KeyPress
        'SimulaTab(e)
        Numeros(e)
    End Sub

    Private Sub txtnacionalidad_LostFocus(sender As Object, e As EventArgs) Handles txtnacionalidad.LostFocus
        statusPanel.Text = ""

        If Me.txtnacionalidad.Text.Trim.Length > 0 Then
            Call BusquedaG(5)
        Else
            lblnacionalidad.Text = ""
        End If
    End Sub

    Private Sub txtnacionalidad_TextChanged(sender As Object, e As EventArgs) Handles txtnacionalidad.TextChanged
        lblnacionalidad.Text = ""
    End Sub

    Private Sub txtsector_GotFocus(sender As Object, e As EventArgs) Handles txtsector.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Sector."
    End Sub

    Private Sub txtsector_KeyDown(sender As Object, e As KeyEventArgs) Handles txtsector.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(4)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtsector.Text = clsVItems.items
                Me.lblsector.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtsector.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtsector_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsector.KeyPress
        'SimulaTab(e)
        Numeros(e)
    End Sub

    Private Sub txtsector_LostFocus(sender As Object, e As EventArgs) Handles txtsector.LostFocus
        statusPanel.Text = ""

        If Me.txtsector.Text.Trim.Length > 0 Then
            Call BusquedaG(4)
        Else
            lblsector.Text = ""
        End If
    End Sub

    Private Sub txtsector_TextChanged(sender As Object, e As EventArgs) Handles txtsector.TextChanged
        lblsector.Text = ""
    End Sub

    Private Sub txtcargo_GotFocus(sender As Object, e As EventArgs) Handles txtcargo.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Cargos."
    End Sub

    Private Sub txtcargo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtcargo.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(3, IIf(Me.txtdepartamento.Text.Trim.Length = 0, 0, Me.txtdepartamento.Text))
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtcargo.Text = clsVItems.items
                Me.lblcargo.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtcargo.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtcargo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcargo.KeyPress
        'SimulaTab(e)
        Numeros(e)
    End Sub

    Private Sub txtcargo_LostFocus(sender As Object, e As EventArgs) Handles txtcargo.LostFocus
        statusPanel.Text = ""

        If Me.txtcargo.Text.Trim.Length > 0 Then
            Call BusquedaG(3)
        Else
            lblcargo.Text = ""
        End If
    End Sub

    Private Sub txtcargo_TextChanged(sender As Object, e As EventArgs) Handles txtcargo.TextChanged
        lblcargo.Text = ""
    End Sub

    Private Sub txtdepartamento_GotFocus(sender As Object, e As EventArgs) Handles txtdepartamento.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Departamentos."
    End Sub

    Private Sub txtdepartamento_KeyDown(sender As Object, e As KeyEventArgs) Handles txtdepartamento.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(2)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtdepartamento.Text = clsVItems.items
                Me.lbldepartamento.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtdepartamento.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtdepartamento_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdepartamento.KeyPress
        'SimulaTab(e)
        Numeros(e)
    End Sub

    Private Sub txtdepartamento_LostFocus(sender As Object, e As EventArgs) Handles txtdepartamento.LostFocus
        statusPanel.Text = ""

        If Me.txtdepartamento.Text.Trim.Length > 0 Then
            Call BusquedaG(2)
        Else
            lbldepartamento.Text = ""
        End If
    End Sub

    Private Sub txtdepartamento_TextChanged(sender As Object, e As EventArgs) Handles txtdepartamento.TextChanged
        lbldepartamento.Text = ""
    End Sub

    Private Sub txtcodsectorial_GotFocus(sender As Object, e As EventArgs) Handles txtcodsectorial.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Tabla sectorial."
    End Sub

    Private Sub txtcodsectorial_KeyDown(sender As Object, e As KeyEventArgs) Handles txtcodsectorial.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(1)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtcodsectorial.Text = clsVItems.items
                Me.lblsectorial.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtcodsectorial.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtcodsectorial_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcodsectorial.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txtcodsectorial_LostFocus(sender As Object, e As EventArgs) Handles txtcodsectorial.LostFocus
        statusPanel.Text = ""

        If Me.txtcodsectorial.Text.Trim.Length > 0 Then
            Call BusquedaG(1)
        Else
            lblsectorial.Text = ""
        End If
    End Sub

    Private Sub txtcodsectorial_TextChanged(sender As Object, e As EventArgs) Handles txtcodsectorial.TextChanged
        lblsectorial.Text = ""
    End Sub

    Private Sub txtCodCiudad_GotFocus(sender As Object, e As EventArgs) Handles txtCodCiudad.GotFocus
        statusPanel.Text = "Precione F5 para pantalla de Consulta de Ciudad."
    End Sub

    Private Sub txtCodCiudad_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCodCiudad.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmBusqueda(8)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtCodCiudad.Text = clsVItems.items
                Me.txtlugarNaci.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                txtCodCiudad.Focus()
                clsVItems.items = ""
                clsVItems.descripcion = ""
            End If
        End If
    End Sub

    Private Sub txtCodCiudad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCodCiudad.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txtCodCiudad_LostFocus(sender As Object, e As EventArgs) Handles txtCodCiudad.LostFocus
        statusPanel.Text = ""

        If Me.txtCodCiudad.Text.Trim.Length > 0 Then
            Call BusquedaG(8)
        Else
            txtlugarNaci.Text = ""
        End If
    End Sub

    Private Sub txtCodCiudad_TextChanged(sender As Object, e As EventArgs) Handles txtCodCiudad.TextChanged
        txtlugarNaci.Text = ""
    End Sub

    Sub BusquedaG(ByVal lwiTipo As Integer)
        Dim ocon As SqlConnection
        Dim ocomand As SqlCommand
        Dim ors As SqlDataReader
        Dim gconextion As New gConnectionSql.gConnection

        ocon = Nothing
        If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, ocon) Then Exit Sub
        ocomand = New SqlCommand

        Try
            With ocomand
                Select Case lwiTipo
                    Case 1
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "sectorial")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtcodsectorial.Text)

                    Case 2
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "departamento")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtdepartamento.Text)

                    Case 3
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "cargo")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtcargo.Text)
                        .Parameters.AddWithValue("@i_codDpto", IIf(Me.txtdepartamento.Text.Trim.Length = 0, 0, Me.txtdepartamento.Text))

                    Case 4
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "sector")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtsector.Text)

                    Case 5
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Nacionalidad")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtnacionalidad.Text)

                    Case 6
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Estudios")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtestudios.Text)

                    Case 7
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Titulos")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txttitulo.Text)

                    Case 8
                        .CommandText = "ROLSp_BusquedaG"
                        .Connection = ocon
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@i_operacion", "Ciudad")
                        .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                        .Parameters.AddWithValue("@i_Tbusqueda", 1)
                        .Parameters.AddWithValue("@i_busqueda", Me.txtCodCiudad.Text)
                End Select
            End With
            ors = ocomand.ExecuteReader()

            Select Case lwiTipo
                Case 1
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lblsectorial.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txtcodsectorial.Text = ""
                        Me.lblsectorial.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo Sectorial", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 2
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lbldepartamento.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txtdepartamento.Text = ""
                        Me.lbldepartamento.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de departamento", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 3
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lblcargo.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txtcargo.Text = ""
                        Me.lblcargo.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de cargo", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 4
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lblsector.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txtsector.Text = ""
                        Me.lblsector.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de sector", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 5
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lblnacionalidad.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txtnacionalidad.Text = ""
                        Me.lblnacionalidad.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de nacionalidad", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 6
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lblestudios.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txtestudios.Text = ""
                        Me.lblestudios.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de Estudio", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 7
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.lbltitulo.Text = ors.Item("descripcion")
                        End If
                    Else
                        Me.txttitulo.Text = ""
                        Me.lbltitulo.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de Titulo", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If

                Case 8
                    If ors.HasRows Then
                        If ors.Read Then
                            Me.txtlugarNaci.Text = ors.Item("NOMBRE")
                        End If
                    Else
                        Me.txtCodCiudad.Text = ""
                        Me.txtlugarNaci.Text = ""
                        XtraMessageBox.Show("No hay datos con este codigo de Ciudad", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
            End Select
        Catch ex As Exception
            XtraMessageBox.Show("Error al recuperar datos: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Finally
            If ocon.State = ConnectionState.Open Then
                ocon.Close()
            End If
            ors = Nothing
            ocon = Nothing
            ocomand = Nothing
        End Try
    End Sub

    Private Sub txtcedMilitar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcedMilitar.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txtCarnetIess_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCarnetIess.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub TxtCedula_Ruc_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCedula_Ruc.KeyPress
        numero(e, sender)
    End Sub

    Private Sub TxtCedula_Ruc_LostFocus(sender As Object, e As EventArgs) Handles TxtCedula_Ruc.LostFocus
        If TxtCedula_Ruc.Text.Trim.Length <> 0 Then

            Select Case lwiTipoIdent.ItemData
                Case 1
                    If TxtCedula_Ruc.Text.Trim.Length <> 10 Or Not Digito_Verificador(TxtCedula_Ruc.Text.Trim) Then
                        TxtCedula_Ruc.Focus()
                        Exit Sub
                    End If

                Case 2
                    If TxtCedula_Ruc.Text.Trim.Length <> 13 Or Not Digito_Verificador(TxtCedula_Ruc.Text.Trim) Then
                        TxtCedula_Ruc.Focus()
                        Exit Sub
                    End If
            End Select
        End If
    End Sub

    Private Sub cmbTipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTipo.SelectedIndexChanged
        lwiTipoIdent = Me.cmbTipo.Items(Me.cmbTipo.SelectedIndex)

        Me.TxtCedula_Ruc.Text = ""

        If lwiTipoIdent.ItemData = 1 Then
            TxtCedula_Ruc.MaxLength = 10
        End If

        If lwiTipoIdent.ItemData = 2 Then
            TxtCedula_Ruc.MaxLength = 13
        End If

        If lwiTipoIdent.ItemData = 3 Then
            TxtCedula_Ruc.MaxLength = 13
        End If
    End Sub

    Private Sub txtcodigo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcodigo.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txtMatriculaPortuaria_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMatriculaPortuaria.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txtMoviQuincenal_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMoviQuincenal.KeyPress
        Numeros_Decimal(e)
    End Sub

    Private Sub txtSueldoBasicoMen_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSueldoBasicoMen.KeyPress
        Numeros_Decimal(e)
    End Sub

    Private Sub txtSueldoExtraMen_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSueldoExtraMen.KeyPress
        Numeros_Decimal(e)
    End Sub

    Private Sub txtTelefono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelefono.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub TxtNombreFamiliar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombreFamiliar.KeyPress

        ' Verificar si el carácter ingresado es una letra o un espacio
        If Char.IsDigit(e.KeyChar) OrElse Char.IsSymbol(e.KeyChar) Then
            ' Permitir el carácter ingresado
            e.Handled = True
        Else
            ' Ignorar el carácter ingresado
            e.Handled = False
        End If
        SimulaTab(e)
    End Sub

    Private Sub txtNumCta_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNumCta.KeyPress
        numero(e, sender)
    End Sub

    Private Sub TxtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre.KeyPress
        SimulaTab(e)
    End Sub

    Private Sub txtTipoSangre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTipoSangre.KeyPress
        SimulaTab(e)
    End Sub

    'Sub CargarAx()
    '    Try
    '        'Call cargar_combo(cboProyecto, "convert(int,codigo) as codigo", "descripcion", " convert(int,codigo) >= 0 ", "APPSOL..Proyectos")
    '        'Call cargar_combo(cbosector, "convert(int,codigo) as codigo", "descripcion", " convert(int,codigo) >= 0 ", "APPSOL..Sector")
    '        'Call cargar_combo(cboActividad, "convert(int,codigo) as codigo", "descripcion", " convert(int,codigo) >= 0 ", "APPSOL..Actividad")
    '        'Call cargar_combo(cboSubActividad, "convert(int,codigo) as codigo", "descripcion", " convert(int,codigo) >= 0 ", "APPSOL..SubActividad")
    '        cboProyecto.SelectedIndex = IIf(cboProyecto.Items.Count > 0, 0, -1)
    '        cbosector.SelectedIndex = IIf(cbosector.Items.Count > 0, 0, -1)
    '        cboActividad.SelectedIndex = IIf(cboActividad.Items.Count > 0, 0, -1)
    '        cboSubActividad.SelectedIndex = IIf(cboSubActividad.Items.Count > 0, 0, -1)
    '    Catch ex As Exception
    '        Throw ex
    '    End Try     
    'End Sub

    Private Sub BtnAceptarF_Click(sender As Object, e As EventArgs) Handles BtnAceptarF.Click
        Dim secuencia As Integer
        Dim Continuar As Boolean
        secuencia = 0

        If TxtNombreFamiliar.Text.Trim.Length = 0 Then
            XtraMessageBox.Show("Ingrese el Nombre del Familiar", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        If chkestadoFamiliar.Checked = False Then
            If XtraMessageBox.Show("Esta seguro de Inactivarlo...", NOMBRE_SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then
                Continuar = True
            Else
                Continuar = False
            End If
        Else
            Continuar = True
        End If

        If Continuar = True Then
            If Tabla1.Rows.Count > 0 Then
                For Each row As DataRow In Me.GridView2.DataSource.Table.Rows
                    secuencia = secuencia + 1
                Next

                secuencia = secuencia + 1
            Else
                secuencia = 1
            End If


            Dim Fila As DataRow
            Fila = Tabla1.NewRow
            Fila("TIPOF") = IIf(lwiTipoFamiliar.ItemData = 1, "C", "H")
            Fila("NOMBREF") = Me.TxtNombreFamiliar.Text.Trim
            Fila("FECHANACF") = Format(dtpfechanac.Value, "dd/MM/yyyy")
            Fila("SEXOF") = IIf(lwiSexofamiliar.ItemData = 1, "M", "F")
            Fila("ESTADOF") = IIf(chkestadoFamiliar.Checked = True, "A", "I")
            Fila("SECUEF") = secuencia
            Fila("APORTA") = IIf(chkaporta.Checked = True, "S", "N")


            ''''''''''''''''''''''''''''''AQUI SE AGREGAN LAS NUEVAS COLUMNAS'''''''''''''''''''
            Fila("UTILIDAD") = IIf(chkutilidad.Checked = True, "S", "N")
            Fila("IMPRENTA") = IIf(chkimprenta.Checked = True, "S", "N")
            Fila("ECATASTROFICA") = IIf(chkemfcatastrifica.Checked = True, "S", "N")

            'Tabla1.Rows.Add(Fila)
            If lwiaccion = 1 Then
                Tabla1.Rows(lwifila).Item(0) = IIf(lwiTipoFamiliar.ItemData = 1, "C", "H")
                Tabla1.Rows(lwifila).Item(1) = Me.TxtNombreFamiliar.Text.Trim
                Tabla1.Rows(lwifila).Item(2) = Format(dtpfechanac.Value, "dd/MM/yyyy")
                Tabla1.Rows(lwifila).Item(3) = IIf(lwiSexofamiliar.ItemData = 1, "M", "F")
                Tabla1.Rows(lwifila).Item(4) = IIf(chkestadoFamiliar.Checked = True, "A", "I")
                ' Tabla.Rows(lwifila).Item(5) = Me.txtccosto.Text.Trim

                Tabla1.Rows(lwifila).Item(6) = IIf(chkaporta.Checked = True, "S", "N")

                ''''''''''''''''''''''''''''''AQUI SE AGREGAN LOS NUEVOS CHECK'''''''''''''''''''

                Tabla1.Rows(lwifila).Item(7) = IIf(chkutilidad.Checked = True, "S", "N")
                Tabla1.Rows(lwifila).Item(8) = IIf(chkimprenta.Checked = True, "S", "N")
                Tabla1.Rows(lwifila).Item(9) = IIf(chkemfcatastrifica.Checked = True, "S", "N")
            Else
                Tabla1.Rows.Add(Fila)
            End If


            Call limpiar_detalle()

        End If
        lwiaccion = 0
    End Sub

    Private Sub cmbtipoFamiliar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbtipoFamiliar.SelectedIndexChanged
        lwiTipoFamiliar = Me.cmbtipoFamiliar.Items(Me.cmbtipoFamiliar.SelectedIndex)
    End Sub

    Private Sub cmbsexoFamiliar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbsexoFamiliar.SelectedIndexChanged
        lwiSexofamiliar = Me.cmbsexoFamiliar.Items(Me.cmbsexoFamiliar.SelectedIndex)
    End Sub

    Private Sub BtnQuitarF_Click(sender As Object, e As EventArgs) Handles BtnQuitarF.Click
        Try
            If Tabla1.Rows.Count > 0 Then
                If XtraMessageBox.Show("Está seguro de Eliminar este Detalle.... ", NOMBRE_SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    Me.Tabla1.Rows.RemoveAt(GridView2.FocusedRowHandle)
                End If
            Else
                XtraMessageBox.Show("No a Ingresado Ningun detalle de familiar", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            XtraMessageBox.Show("Error al eliminar detalle de familiar: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub mnuanular_Click(sender As Object, e As EventArgs) Handles mnuanular.Click
        pwinumero = 0

        Call seleccionar("Eliminar")

        If pwinumero = 0 Then
            Exit Sub
        End If

        Dim lwiaceptar As Integer
        lwiaceptar = XtraMessageBox.Show("¿Está seguro de Inactivar este Registro?", NOMBRE_SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If lwiaceptar = 6 Then
            Dim oComand As SqlCommand
            Dim oCon As SqlConnection
            Dim ierror As Integer, smensaje As String
            Dim connection As New gConnectionSql.gConnection
            Dim audxml As New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
            oCon = Nothing
            Dim dxmla As New XElement("AUDITORIA")
            Dim cxmla As New XElement("PARAMETROS")
            cxmla.Add(New XAttribute("compania", sgCompania))
            cxmla.Add(New XAttribute("ejecutable", My.Application.Info.AssemblyName))
            cxmla.Add(New XAttribute("usuario", sgUsuario))
            cxmla.Add(New XAttribute("maquina", sgMaquina))
            dxmla.Add(cxmla)
            audxml.Add(dxmla)

            If Not connection.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
            oComand = New SqlCommand
            Try
                With oComand
                    .CommandText = "ROLSp_MantEmpleado"
                    .Connection = oCon
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@i_operacion", "delete")
                    .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                    .Parameters.AddWithValue("@i_empleado", pwinumero)
                    .Parameters.AddWithValue("@i_xml_aud", audxml.ToString)
                    .Parameters.AddWithValue("@i_usuario", sgUsuario)
                    .Parameters.AddWithValue("@i_maquina", sgMaquina)
                    .Parameters.Add("@o_error", SqlDbType.Int)
                    .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 8000)
                    .Parameters("@o_error").Direction = ParameterDirection.Output
                    .Parameters("@o_mensaje").Direction = ParameterDirection.Output
                End With
                oComand.ExecuteScalar()
                ierror = oComand.Parameters("@o_error").Value
                smensaje = oComand.Parameters("@o_mensaje").Value

                If ierror = 1 Then
                    XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Me.BtnBuscar_Click(sender, e)
                End If
            Catch ex As Exception
                XtraMessageBox.Show("Error al eliminar registro: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                oComand = Nothing
                If oCon.State = ConnectionState.Open Then
                    oCon.Close()
                End If
                oCon = Nothing
            End Try
        Else
            pwinumero = 0
        End If
    End Sub

    Private Sub mnugrabar_Click(sender As Object, e As EventArgs) Handles mnugrabar.Click
        Try
            If validar_datos() = False Then Exit Sub

            If XtraMessageBox.Show("Está Seguro de Guardar este Registro....", NOMBRE_SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub

            If guardar_registro(igaccion) = False Then Exit Sub

            If igaccion = 2 Then
                pwinumero = 0
            End If

            igaccion = 1
            seteo_boton(False)
            Me.BtnBuscar_Click(sender, e)
        Catch ex As Exception
            XtraMessageBox.Show("Error al guardar registro: " & ex.Message, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Function validar_datos() As Boolean
        validar_datos = True

        If TxtCedula_Ruc.Text.Trim.Length = 0 Then
            XtraMessageBox.Show("Información requerida: Idebtificación de empleado", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            TxtCedula_Ruc.Focus()
            validar_datos = False
            Exit Function
        End If

        If TxtNombre.Text.Trim.Length = 0 Then
            XtraMessageBox.Show("Información requerida: Nombres de empleado", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            TxtNombre.Focus()
            validar_datos = False
            Exit Function
        End If

        If Not IsDate(dtpfechanac.Value) Then
            XtraMessageBox.Show("Información requerida: Fecha de Nacimiento", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            dtpfechanac.Focus()
            validar_datos = False
            Exit Function
        End If

        If chkacredita.Checked = True And txtNumCta.Text.Trim.Length = 0 Then
            XtraMessageBox.Show("Información requerida: Número de Cta de Banco", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtNumCta.Focus()
            validar_datos = False
            Exit Function
        End If

        If txtdepartamento.Text.Trim.Length = 0 Then
            XtraMessageBox.Show("Información requerida: Departamento de trabajo", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtdepartamento.Focus()
            validar_datos = False
            Exit Function
        End If

        If txtcargo.Text.Trim.Length = 0 Then
            XtraMessageBox.Show("Información requerida: Cargo de Trabajo", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtcargo.Focus()
            validar_datos = False
            Exit Function
        End If

        If lwiTipoIdent.ItemData = 1 Then
            If TxtCedula_Ruc.Text.Trim.Length <> 10 Or Not Digito_Verificador(TxtCedula_Ruc.Text) Then
                TxtCedula_Ruc.Focus()
                validar_datos = False
                Exit Function
            End If
        End If

        If lwiTipoIdent.ItemData = 2 Then
            If TxtCedula_Ruc.Text.Trim.Length <> 13 Or Not Digito_Verificador(TxtCedula_Ruc.Text) Then
                TxtCedula_Ruc.Focus()
                validar_datos = False
                Exit Function
            End If
        End If
        If IsNothing(gluccosto.EditValue) = True Then
            XtraMessageBox.Show("Información requerida: Centro de Costo", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            gluccosto.Focus()
            validar_datos = False
            Exit Function
        End If
    End Function

    Function guardar_registro(ByVal accion As Integer) As Boolean
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim ierror As Integer, smensaje As String, isclave As Integer = 0
        Dim connection As New gConnectionSql.gConnection
        Dim empleado As String = "", tipo_id As String = "", estado_civil As String = "", sexo As String = "", tipo_cta As String = ""
        Dim tipo_liqui As String = "", clase As String = "", sopcion As String = "", tipo_ir As String = ""
        Dim secuencia As Integer = 0
        Dim bytArray() As Byte = Nothing
        Dim audxml As New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
        guardar_registro = False

        oCon = Nothing
        If Not connection.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Function
        oComand = New SqlCommand

        Try
            Dim dxmla As New XElement("AUDITORIA")
            Dim cxmla As New XElement("PARAMETROS")
            cxmla.Add(New XAttribute("compania", sgCompaniaForm))
            cxmla.Add(New XAttribute("ejecutable", My.Application.Info.AssemblyName))
            cxmla.Add(New XAttribute("usuario", sgUsuario))
            cxmla.Add(New XAttribute("maquina", sgMaquina))
            dxmla.Add(cxmla)
            audxml.Add(dxmla)

            If accion = 1 Then
                empleado = 0
                sopcion = "insert"
            Else
                empleado = txtcodigo.Text
                sopcion = "update"
            End If

            Select Case lwiTipoIdent.ItemData
                Case 1 : tipo_id = "C"
                Case 2 : tipo_id = "R"
                Case 3 : tipo_id = "P"
            End Select

            Select Case lwiEstadocivil.ItemData
                Case 1 : estado_civil = "S"
                Case 2 : estado_civil = "C"
                Case 3 : estado_civil = "D"
                Case 4 : estado_civil = "U"
            End Select

            If lwisexo.ItemData = 1 Then
                sexo = "M"
            Else
                sexo = "F"
            End If

            Select Case lwiTipoCuenta.ItemData
                Case 1 : tipo_cta = "A"
                Case 2 : tipo_cta = "C"
                Case 3 : tipo_cta = "T"
                Case 4 : tipo_cta = "N"
            End Select

            Select Case lwiTipoLiq.ItemData
                Case 1 : tipo_liqui = "M"
                Case 2 : tipo_liqui = "Q"
                Case 3 : tipo_liqui = "S"

            End Select

            Select Case lwiClaseEmpl.ItemData
                Case 1 : clase = "N"
                Case 2 : clase = "C"
                Case 3 : clase = "P"
                Case 4 : clase = "S"
                Case 5 : clase = "T"
            End Select
            Select Case lwiTipoIR.ItemData
                Case 1 : tipo_ir = "A"
                Case 2 : tipo_ir = "B"
                Case 3 : tipo_ir = "C"
                Case 4 : tipo_ir = "D"
            End Select



            xmlEmpleado = New XDocument(New XDeclaration("1.0", "utf-8", Nothing))
            Dim dxml As New XElement("EMPLEADO")
            Dim cxml As New XElement("DATOS")
            cxml.Add(New XAttribute("idcompania", sgCompaniaForm))
            cxml.Add(New XAttribute("usuario", sgUsuario))
            cxml.Add(New XAttribute("maquina", sgMaquina))
            cxml.Add(New XAttribute("opcion", sopcion))
            cxml.Add(New XAttribute("empleado", empleado))
            cxml.Add(New XAttribute("tipo_id", tipo_id))
            cxml.Add(New XAttribute("ruc", TxtCedula_Ruc.Text.Trim))
            cxml.Add(New XAttribute("nombre", TxtNombre.Text.Trim))
            cxml.Add(New XAttribute("direccion", TxtDireccion.Text.Trim))
            cxml.Add(New XAttribute("telefono", txtTelefono.Text.Trim))
            cxml.Add(New XAttribute("estado_civil", estado_civil))
            cxml.Add(New XAttribute("sexo", sexo))
            cxml.Add(New XAttribute("lugar_nac", txtlugarNaci.Text.Trim))
            cxml.Add(New XAttribute("fecha_nac", Format(dtpfechaNacimiento.Value.Date, "yyyyMMdd")))
            cxml.Add(New XAttribute("nacionalidad", txtnacionalidad.Text.Trim))
            cxml.Add(New XAttribute("titulo", txttitulo.Text.Trim))
            cxml.Add(New XAttribute("codest", txtestudios.Text.Trim))
            cxml.Add(New XAttribute("codact", 0))
            cxml.Add(New XAttribute("carnet_iess", txtCarnetIess.Text.Trim))
            cxml.Add(New XAttribute("fecha_ing", Format(dtpfechaIngreso.Value.Date, "yyyyMMdd")))
            cxml.Add(New XAttribute("fecha_egreso", Format(dtpfechaEgreso.Value.Date, "yyyyMMdd")))
            cxml.Add(New XAttribute("cuenta", txtNumCta.Text.Trim))
            cxml.Add(New XAttribute("cedcta", txtcedulacta.Text.Trim))
            cxml.Add(New XAttribute("tipoCta", tipo_cta))
            cxml.Add(New XAttribute("depcta", IIf(chkacredita.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("departamento", txtdepartamento.Text.Trim))
            cxml.Add(New XAttribute("sector", txtsector.Text.Trim))
            cxml.Add(New XAttribute("cargo", txtcargo.Text.Trim))
            cxml.Add(New XAttribute("tipo_liq", tipo_liqui))
            cxml.Add(New XAttribute("estado", IIf(chkestado.Checked = True, "A", "I")))
            cxml.Add(New XAttribute("beneficio", IIf(chkbeneficios.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("sueldo", CDbl(txtSueldoBasicoMen.Text).ToString("#########0.00;zero")))
            cxml.Add(New XAttribute("extra", CDbl(txtSueldoExtraMen.Text).ToString("#########0.00;zero")))
            cxml.Add(New XAttribute("transporte", CDbl(txtMoviQuincenal.Text).ToString("#########0.00;zero")))
            cxml.Add(New XAttribute("alimentacion", CDbl(txtalimentacion.Text).ToString("#########0.00;zero")))
            cxml.Add(New XAttribute("sector2", txtcodsectorial.Text.Trim))
            cxml.Add(New XAttribute("clase", clase))
            cxml.Add(New XAttribute("tipo_sangre", txtTipoSangre.Text.Trim))
            cxml.Add(New XAttribute("ced_militar", txtcedMilitar.Text.Trim))
            cxml.Add(New XAttribute("mat_portuaria", txtMatriculaPortuaria.Text.Trim))
            cxml.Add(New XAttribute("relacion", IIf(chkPagomensualBeneficios.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("COD_CIUDAD", txtCodCiudad.Text.Trim))
            cxml.Add(New XAttribute("DISCAPACIDAD", IIf(chkDiscapacidad.Checked = True, 1, 0)))
            cxml.Add(New XAttribute("terminoC", Format(dtpfechaTermiContrato.Value.Date, "yyyyMMdd")))
            cxml.Add(New XAttribute("por_discapacidad", txtpordiscapacidad.Text))
            cxml.Add(New XAttribute("tipo_ir", tipo_ir))
            cxml.Add(New XAttribute("biometrico", txtbiometrico.Text))
            cxml.Add(New XAttribute("cod_cargo", txtcodigo_cargo.Text))
            cxml.Add(New XAttribute("contacto", txtcontacto.Text))
            cxml.Add(New XAttribute("observacion", txtobservacion.Text))
            cxml.Add(New XAttribute("paga_fon_res", IIf(chkpagafondo.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("ctacble", txtctacble.Text))
            cxml.Add(New XAttribute("per_prueba", IIf(chkprueba.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("aplica_bono", IIf(chkbono.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("email", txtemail.Text))
            cxml.Add(New XAttribute("pago_adicional", IIf(chkpagootro.Checked = True, "S", "N")))
            cxml.Add(New XAttribute("centro_costo", gluccosto.EditValue))
            cxml.Add(New XAttribute("login", ""))
            cxml.Add(New XAttribute("emf_catastrofica", IIf(chkempemfcatastrofica.Checked = True, "S", "N")))
            secuencia = 1
            If Tabla1.Rows.Count >= 0 Then
                For Each row As DataRow In Tabla1.Rows
                    Dim detxml As New XElement("CARGA")
                    detxml.Add(New XAttribute("secuencia", secuencia))
                    detxml.Add(New XAttribute("parentesco", row("TIPOF")))
                    detxml.Add(New XAttribute("nombre", row("NOMBREF")))
                    detxml.Add(New XAttribute("fecha", CDate(row("FECHANACF")).ToString("yyyyMMdd")))
                    detxml.Add(New XAttribute("sexo", row("SEXOF")))
                    detxml.Add(New XAttribute("estado", row("ESTADOF")))
                    detxml.Add(New XAttribute("aporta", row("APORTA")))

                    ''''''''''''''''''''''''''''''AQUI SE AGREGAN LAS NUEVAS COLUMNAS AL XML'''''''''''''''''''
                    detxml.Add(New XAttribute("utilidad", row("UTILIDAD")))
                    detxml.Add(New XAttribute("imp_retencion", row("IMPRENTA")))
                    detxml.Add(New XAttribute("catastrofica", row("ECATASTROFICA")))
                    cxml.Add(detxml)
                    secuencia = secuencia + 1
                Next
            End If
            dxml.Add(cxml)
            xmlEmpleado.Add(dxml)

            With oComand
                .CommandType = CommandType.StoredProcedure
                .CommandText = "ROLSp_MantEmpleado"
                .Connection = oCon
                .Parameters.AddWithValue("@i_operacion", sopcion)
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                .Parameters.AddWithValue("@i_empleado", empleado)
                .Parameters.AddWithValue("@i_usuario", sgUsuario)
                .Parameters.AddWithValue("@i_maquina", sgMaquina)
                .Parameters.AddWithValue("@i_xml_aud", audxml.ToString)
                .Parameters.AddWithValue("@i_xml", xmlEmpleado.ToString)
                .Parameters.Add("@o_error", SqlDbType.Int)
                .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 250)
                .Parameters.Add("@o_empleado", SqlDbType.Int)
                .Parameters("@o_error").Direction = ParameterDirection.Output
                .Parameters("@o_mensaje").Direction = ParameterDirection.Output
                .Parameters("@o_empleado").Direction = ParameterDirection.Output
            End With
            oComand.ExecuteScalar()
            ierror = oComand.Parameters("@o_error").Value
            smensaje = oComand.Parameters("@o_mensaje").Value
            isclave = oComand.Parameters("@o_empleado").Value

            If ierror = 1 Then
                guardar_registro = False
                XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                guardar_registro = True
                ' Call GrabarCargaFamiliar(isclave)
                XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            If pbximagen.Image IsNot Nothing Then
                oComand = Nothing
                bytArray = Imagen_Bytes(pbximagen.Image)
                oComand = New SqlCommand
                With oComand
                    .CommandType = CommandType.StoredProcedure
                    .CommandText = "ROLSp_MantEmpleado"
                    .Connection = oCon
                    .Parameters.AddWithValue("@i_operacion", "upd_imag")
                    .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                    .Parameters.AddWithValue("@i_empleado", empleado)
                    .Parameters.AddWithValue("@i_imagen", bytArray)
                    .Parameters.Add("@o_error", SqlDbType.Int)
                    .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 250)
                    .Parameters.Add("@o_empleado", SqlDbType.Int)
                    .Parameters("@o_error").Direction = ParameterDirection.Output
                    .Parameters("@o_mensaje").Direction = ParameterDirection.Output
                    .Parameters("@o_empleado").Direction = ParameterDirection.Output
                End With
                oComand.ExecuteScalar()
                ierror = oComand.Parameters("@o_error").Value
                smensaje = oComand.Parameters("@o_mensaje").Value
                isclave = oComand.Parameters("@o_empleado").Value
                If ierror = 1 Then

                    XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception
            guardar_registro = False
            Throw ex
        Finally
            oComand = Nothing
            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oCon = Nothing
        End Try
    End Function


    ''''''''''''''''''''''''''''''METODO SIN UTILIZAR? POR REVISAR'''''''''''''''''''

    Sub GrabarCargaFamiliar(ByVal idEmpleado As Integer)
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim ierror As Integer, smensaje As String
        Dim connection As New gConnectionSql.gConnection

        oCon = Nothing
        If Not connection.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Sub
        oComand = New SqlCommand

        Try
            With oComand
                .CommandType = CommandType.StoredProcedure
                .CommandText = "ROLSp_MantEmpleado"
                .Connection = oCon
                .Parameters.AddWithValue("@i_operacion", "deleteCF")
                .Parameters.AddWithValue("@i_compania", sgCompaniaForm)
                .Parameters.AddWithValue("@i_empleado", idEmpleado)
                .Parameters.Add("@o_error", SqlDbType.Int)
                .Parameters.Add("@o_mensaje", SqlDbType.VarChar, 250)
                .Parameters("@o_error").Direction = ParameterDirection.Output
                .Parameters("@o_mensaje").Direction = ParameterDirection.Output
            End With
            oComand.ExecuteScalar()
            ierror = oComand.Parameters("@o_error").Value
            smensaje = oComand.Parameters("@o_mensaje").Value

            If ierror = 1 Then
                XtraMessageBox.Show(smensaje, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                oComand = Nothing
                Dim iSecuencia As Integer
                Dim FNombre As String
                Dim Ffecha As String
                Dim Fsexo As String
                Dim Ftipo As String
                Dim Festado As String
                Dim Ssql As String

                For Each row As DataRow In Me.GridView2.DataSource.Table.Rows
                    iSecuencia = iSecuencia + 1
                    FNombre = row("NOMBREF")
                    Ffecha = Format(CDate(row("FECHANACF")), "yyyyMMdd")
                    Fsexo = row("SEXOF")
                    Ftipo = row("TIPOF")
                    Festado = row("ESTADOF")

                    Ssql = ""
                    Ssql = Ssql & "insert into  ROLM03 (NM03CODCIA, NM03CODEMP, NM03SECUEN, CM03NOMBRE, TM03FECNAC, CM03SEXO, CM03INDICA, CM03ESTADO)"
                    Ssql = Ssql & "values (" & sgCompaniaForm & "," & idEmpleado & "," & iSecuencia & ",'" & FNombre & "','" & Ffecha & "','" & Fsexo & "','" & Ftipo & "','" & Festado & "')"

                    oComand = Nothing
                    oComand = New SqlCommand
                    With oComand
                        .CommandType = CommandType.Text
                        .CommandTimeout = 0
                        .Connection = oCon
                        .CommandText = Ssql
                    End With

                    oComand.ExecuteNonQuery()
                Next
            End If
        Catch ex As Exception
            XtraMessageBox.Show("Error al grabar Carga Familiar: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            oComand = Nothing
            If oCon.State = ConnectionState.Open Then
                oCon.Close()
            End If
            oCon = Nothing
        End Try
    End Sub


    Private Sub cmbestadocivil_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbestadocivil.SelectedIndexChanged
        lwiEstadocivil = Me.cmbestadocivil.Items(Me.cmbestadocivil.SelectedIndex)
    End Sub

    Private Sub cmbsexo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbsexo.SelectedIndexChanged
        lwisexo = Me.cmbsexo.Items(Me.cmbsexo.SelectedIndex)
    End Sub

    Private Sub cmbTipoCta_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTipoCta.SelectedIndexChanged
        lwiTipoCuenta = Me.cmbTipoCta.Items(Me.cmbTipoCta.SelectedIndex)
    End Sub

    Private Sub cmbtipoLiqui_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbtipoLiqui.SelectedIndexChanged
        lwiTipoLiq = Me.cmbtipoLiqui.Items(Me.cmbtipoLiqui.SelectedIndex)
    End Sub

    Private Sub cmbclaseEmpleado_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbclaseEmpleado.SelectedIndexChanged
        lwiClaseEmpl = Me.cmbclaseEmpleado.Items(Me.cmbclaseEmpleado.SelectedIndex)
    End Sub

    Private Sub FrmEmpleados_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            bload = False
            If Load_Siac(Me, "ROLES", scommand) = False Then Me.Dispose()
            '  sgMaquina = My.Computer.Name
            llenar_compania()
            If max_compania > 0 Then
                cmbCompania.EditValue = cmbCompania.Properties.GetKeyValue(0)
                sgCompaniaForm = sgCompania

                If mostrar_empresa() = "N" Then
                    lblcompania.Enabled = False
                    lblcompania.Visible = False
                    cmbCompania.Enabled = False
                    cmbCompania.Visible = False
                Else
                    lblcompania.Enabled = True
                    lblcompania.Visible = True
                    cmbCompania.Enabled = True
                    cmbCompania.Visible = True

                End If
            End If
            If bloqueo_transaccion() = "S" Then
                XtraMessageBox.Show("Se esta procesando el Rol....No se puede Realizar Cambios por el momento.....", NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End
            End If

            If Tiene_Permiso(eTipoPermiso.Versueldo, sgUsuario, sgbase) = True Then
                GroupControl5.Enabled = True
                GroupControl5.Visible = True
            Else
                GroupControl5.Enabled = False
                GroupControl5.Visible = False

            End If
            lwiaccion = 0
            Call StatusBar()
            seteo_boton(False)
            txtcodigo.Enabled = False
            Call Cargar_Combos()
            sgMaquina = My.Computer.Name
            sgEjecutable = My.Application.Info.AssemblyName
            Call CrearTable()

            Dim pwoDateTable = New List(Of ClsDatetable)
            pwoDateTable.Add(New ClsDatetable(1, "dte3_ctocto", Tabla_CCosto))
            Call Cargar_Data_Table(sgCompaniaForm, sgbaseRoles, "ROLSp_MantEmpleado", "load_tabla", pwoDateTable)
            pwoDateTable.Clear()
            If tipo_carga = 1 Then
                chkimprenta.Enabled = True
                chkemfcatastrifica.Enabled = True
            Else
                chkimprenta.Enabled = False
                chkemfcatastrifica.Enabled = False
            End If
            bload = True
        Catch ex As Exception
            XtraMessageBox.Show("Error en la ejecución de la aplicación: " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
    Private Sub cargar_parametro()

        Dim oCon As SqlConnection
        Dim ocomd As New SqlCommand
        Dim ors As SqlDataReader
        Dim apiess As Double = 0
        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection

        Try
            oCon = Nothing
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            ocomd.Connection = oCon
            ocomd.CommandText = "sp_Registrar_Rubros"
            ocomd.CommandType = CommandType.StoredProcedure
            ocomd.Parameters.Add("@i_operacion", SqlDbType.NVarChar).Value = "para"
            ocomd.Parameters.Add("@i_compania", SqlDbType.Int).Value = sgCompaniaForm 'cmbCompania.EditValue
            ors = ocomd.ExecuteReader
            If ors.HasRows = False Then
                MessageBox.Show("No existe parametro impuestos...", "Mensaje del sistema " & NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
                oCon.Close()
                Exit Sub
            Else
                While ors.Read
                    tipo_carga = ors("carga_imp")
                End While
            End If

            ors.Close()
            oCon.Close()
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)
        End Try

    End Sub

#Region "FUNCIONES Y PROCEDIMIENTOS BASICOS"
    Private Sub llenar_compania()

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim dt As New DataSet
        Dim dtadap As SqlDataAdapter

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Sub
            oComand = New SqlCommand
            With oComand
                '.CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Compania"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "query_empresa")
            End With


            dtadap = New SqlDataAdapter(oComand)
            dtadap.Fill(dt)
            max_compania = dt.Tables(0).Rows.Count
            ' max_compania = max_compania - 1
            ' llenacompania = False
            cmbCompania.Properties.DataSource = dt.Tables(0)
            cmbCompania.Properties.DisplayMember = "Nombre"
            cmbCompania.Properties.ValueMember = "Codigo"
            ' llenacompania = True
            oComand = Nothing
            oCon.Close()
            oCon = Nothing
            cmbCompania.Properties.View.BestFitColumns(True)
            ' Specify the total dropdown width.
            cmbCompania.Properties.PopupFormWidth = 600
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Function mostrar_empresa() As String

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim oRs As SqlDataReader

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        mostrar_empresa = "N"
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbase, sguser, sgpw, oCon) = False Then Exit Function
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "PARMSp_Mant_Parametro_General"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "mos_emp")

            End With
            oRs = oComand.ExecuteReader()
            If oRs.HasRows = True Then
                If oRs.Read Then

                    mostrar_empresa = oRs.Item("mostrar_empresa")
                End If
            End If

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Function fecha_proceso(compania As Integer) As String
        Dim oComand As SqlCommand
        Dim oCon As SqlConnection
        Dim oRs As SqlDataReader
        'Dim ierror As Integer, smensaje As String
        Dim gconextion As gConnectionSql.gConnection
        gconextion = New gConnectionSql.gConnection
        oCon = Nothing
        Try
            fecha_proceso = ""
            If Not gconextion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) Then Exit Function
            oComand = New SqlCommand
            With oComand

                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "fec_proc")
                .Parameters.AddWithValue("@NT08CODCIA", compania)

            End With
            oRs = oComand.ExecuteReader()

            If oRs.HasRows = True Then
                If oRs.Read Then
                    fecha_proceso = Format(oRs.Item("fecha"), "dd/MM/yyyy")
                End If
            End If


            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            MsgBox("Error.." & Err.Description, vbCritical, NOMBRE_SISTEMA)

        End Try
    End Function
    Function bloqueo_transaccion() As String

        Dim oCon As SqlConnection
        Dim oComand As SqlCommand
        Dim oRs As SqlDataReader

        Dim oconexion As gConnectionSql.gConnection
        oconexion = New gConnectionSql.gConnection
        oCon = Nothing
        bloqueo_transaccion = "N"
        Try
            If oconexion.gConexion(sgtipo, sgprovider, sgservidor, sgbaseRoles, sguser, sgpw, oCon) = False Then Exit Function
            oComand = New SqlCommand
            With oComand
                .CommandTimeout = 0
                .CommandText = "ROLSp_Mant_Parametros"
                .Connection = oCon
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@i_operacion", "bloqueo_rol")
                .Parameters.AddWithValue("@NT08CODCIA", sgCompaniaForm)
            End With
            oRs = oComand.ExecuteReader()
            If oRs.HasRows = True Then
                If oRs.Read Then

                    bloqueo_transaccion = oRs.Item("bloqueo")
                End If
            End If

            oComand = Nothing
            oRs.Close()
            oRs = Nothing
            oCon.Close()
            oCon = Nothing
        Catch ex As Exception
            XtraMessageBox.Show(Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
#End Region
#Region "Otras Funciones"
    Shared Function Imagen_Bytes(ByVal Foto As Image) As Byte()
        If Not Foto Is Nothing Then
            Dim Codi As New IO.MemoryStream
            Foto.Save(Codi, Imaging.ImageFormat.Jpeg)
            Return Codi.GetBuffer
        Else
            Return Nothing
        End If
    End Function
    Shared Function Bytes_Imagen(ByVal Foto As Byte()) As Image
        If Not Foto Is Nothing Then
            Dim Codi As New IO.MemoryStream(Foto)
            Dim resultado As Image = Image.FromStream(Codi)
            Return resultado
        Else
            Return Nothing
        End If
    End Function
#End Region
    Private Sub cmbCompania_EditValueChanged(sender As Object, e As EventArgs) Handles cmbCompania.EditValueChanged
        If bload = False Then Exit Sub
        sgCompaniaForm = cmbCompania.EditValue
        Tabla.Rows.Clear()
    End Sub

    Private Sub FrmEmpleados_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label32_Click(sender As Object, e As EventArgs) Handles Label32.Click

    End Sub

    Private Sub chkDiscapacidad_CheckedChanged(sender As Object, e As EventArgs) Handles chkDiscapacidad.CheckedChanged
        If chkDiscapacidad.Checked = False Then
            txtpordiscapacidad.Text = "0"
            txtpordiscapacidad.Enabled = False
            ' txtpordiscapacidad.Locked = True
        Else
            txtpordiscapacidad.Enabled = True
            ' txtpordiscapacidad.Locked = False
        End If
    End Sub

    Private Sub cmbTcalculoIR_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTcalculoIR.SelectedIndexChanged
        lwiTipoIR = Me.cmbTcalculoIR.Items(Me.cmbTcalculoIR.SelectedIndex)
    End Sub



    Private Sub txtpordiscapacidad_RightToLeftChanged(sender As Object, e As EventArgs) Handles txtpordiscapacidad.RightToLeftChanged
        numero(e, sender)
    End Sub

    Private Sub txtpordiscapacidad_TextChanged(sender As Object, e As EventArgs) Handles txtpordiscapacidad.TextChanged

    End Sub

    Private Sub txtcodigo_cargo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcodigo_cargo.KeyPress
        numero(e, sender)
    End Sub

    Private Sub butfoto_Click(sender As Object, e As EventArgs) Handles butfoto.Click
        Try
            OpenFileDialog1.Filter = "Imagenes (JPG)|*.jpg|(PNG)|*.png"
            'en caso de que se aplaste el boton cancelar salga y no haga nada
            If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            Else
                Me.pbximagen.Image = Image.FromFile(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            XtraMessageBox.Show("Error al Cargar Imagen  " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try
    End Sub

    Private Sub txtctacble_KeyDown(sender As Object, e As KeyEventArgs) Handles txtctacble.KeyDown
        If e.KeyValue = Keys.F5 Then
            Dim forma As New FrmFindCtas(10, 1)
            forma.ShowDialog()
            If clsVItems.items.Trim.Length > 0 Then
                Me.txtctacble.Text = clsVItems.items
                ' Me.lblcuenta.Text = clsVItems.descripcion
                clsVItems.items = ""
                clsVItems.descripcion = ""
                e.Handled = True
                SendKeys.Send("{TAB}")
            Else
                clsVItems.items = ""
                clsVItems.descripcion = ""
                Me.txtctacble.Focus()
            End If
        End If
    End Sub

    Private Sub txtctacble_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtctacble.KeyPress
        numero(e, sender)
    End Sub

    Private Sub txtctacble_TextChanged(sender As Object, e As EventArgs) Handles txtctacble.TextChanged

    End Sub

    Private Sub GroupControl1_Paint(sender As Object, e As PaintEventArgs) Handles GroupControl1.Paint

    End Sub

    Private Sub Label43_Click(sender As Object, e As EventArgs) Handles Label43.Click

    End Sub

    Private Sub BtnModificar_Click(sender As Object, e As EventArgs) Handles BtnModificar.Click
        Try
            If GridView2.RowCount > 0 Then
                Me.lwifila = GridView2.FocusedRowHandle
                lwiaccion = 1 'Modificar
                Call mover_detalle()
            End If
        Catch ex As Exception
            XtraMessageBox.Show("Error al seleccionar registro: " & Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub mover_detalle()
        Try

            'Fila = Tabla1.NewRow
            'Fila("TIPOF") = IIf(lwiTipoFamiliar.ItemData = 1, "C", "H")
            'Fila("NOMBREF") = Me.TxtNombreFamiliar.Text.Trim
            'Fila("FECHANACF") = Format(dtpfechanac.Value, "dd/MM/yyyy")
            'Fila("SEXOF") = IIf(lwiSexofamiliar.ItemData = 1, "M", "F")
            'Fila("ESTADOF") = IIf(chkestadoFamiliar.Checked = True, "A", "I")
            'Fila("SECUEF") = secuencia
            'Fila("APORTA") = IIf(chkaporta.Checked = True, "S", "N")
            Call ubicar_combo(cmbtipoFamiliar, IIf(Tabla1.Rows(lwifila).Item(0) = "C", 1, 2))
            TxtNombreFamiliar.Text = Tabla1.Rows(lwifila).Item(1)
            dtpfechanac.Value = Tabla1.Rows(lwifila).Item(2)
            Call ubicar_combo(cmbsexoFamiliar, IIf(Tabla1.Rows(lwifila).Item(3) = "M", 1, 2))
            chkestadoFamiliar.Checked = IIf(Tabla1.Rows(lwifila).Item(4) = "A", True, False)
            chkaporta.Checked = IIf(Tabla1.Rows(lwifila).Item(6) = "S", True, False)
            chkutilidad.Checked = IIf(Tabla1.Rows(lwifila).Item(7) = "S", True, False)
            chkimprenta.Checked = IIf(Tabla1.Rows(lwifila).Item(8) = "S", True, False)
            chkemfcatastrifica.Checked = IIf(Tabla1.Rows(lwifila).Item(9) = "S", True, False)
        Catch ex As Exception
            XtraMessageBox.Show("Ha ocurrido un error al seleccionar registro: " + Err.Description, NOMBRE_SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
    End Sub

    Private Sub GrdCargaFamiliar_Click(sender As Object, e As EventArgs) Handles GrdCargaFamiliar.Click

    End Sub

    Private Sub GridView2_DoubleClick(sender As Object, e As EventArgs) Handles GridView2.DoubleClick
        Call BtnModificar.PerformClick()
    End Sub

    Private Sub GridView3_ShowingEditor(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles GridView3.ShowingEditor
        If New String() {"-", "Cuenta", "Proyecto", "Sector", "Actividad", "Subactividad", "Porcentaje"}.Contains(GridView3.FocusedColumn.FieldName) Then
            e.Cancel = True
        Else
            e.Cancel = False
        End If
    End Sub
    Private Sub txtalimentacion_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtalimentacion.KeyPress
        Numeros_Decimal(e)
    End Sub

    Private Sub txtSueldoBasicoMen_TextChanged(sender As Object, e As EventArgs) Handles txtSueldoBasicoMen.TextChanged

    End Sub


End Class
